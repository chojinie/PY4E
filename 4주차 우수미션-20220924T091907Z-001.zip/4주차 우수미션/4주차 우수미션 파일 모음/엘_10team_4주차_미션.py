#!/usr/bin/env python
# coding: utf-8

# In[4]:


#Q1 3자리마다 , 찍기
def make_comma(num):
    print(f"{num:,}")

num = int(input("숫자를 입력하세요 : "))
make_comma(num)


# In[22]:


#Q2 특정글자가 총 몇개?

def count_word(a, word):
    count = 0
    
    for i, c in enumerate(a):
        #print(str(i) + c)
        if c == word[0]:
            if a[i : i + len(word)] == word:
                count = count + 1
                #print(str(i) + a[i : i + len(word)])

    return count

a ="""
둘이 마주 보자 똑똑히 눈이 빨개지게
눈을 감으며 널 놓치지 않게
둘이 마주 보자 똑똑히 손을 마주 잡고
우린 나아질 거야 내 얘길 해줄 게
사실 나는 겁이 나
이렇게나 행복할 땐
내일을 무서워해 도망치려고만 해
넌 내가 어때
잡아줄래 내가 무서워 울 때
행복에 겁이 나서 그러니 날 잡아줄래
네가 그럴 때 조금 덜 도망갈 게
이기적이란 걸 알지만 계속해 널 사랑해도 돼
둘이 마주 보자 똑똑히 눈이 빨개지게
눈을 감아도 네가 보일 때쯤
그리 마주 보자 똑똑히 손을 마주 잡고
우린 나아질 거야 내 얘길 해줄 게
사실 나는 겁이 나
이렇게나 행복할 땐
내일을 무서워해 도망치려고만 해
넌 내가 어때
잡아줄래 내가 무서워 울 때
행복에 겁이 나서 그러니 날 잡아줄래
네가 그럴 때 조금 덜 도망갈 게
이기적이란 걸 알지만 계속해 널 사랑해
받아줄래 우리가 둘이 될 때
어떤 말이라도 괜찮은 그런 마음일 때
그래 그럴 때 나를 꼭 안아줄래
작고 작은 나의 바람이야
계속해 널 사랑해도 돼 접기
"""

word = input("어떤 글자의 개수를 알고싶으신가요? ")
count = count_word(a, word)
print('글 안에 "%s"(은)는 %d개있습니다.' %(word,count))


# In[25]:


#Q3 전화번호부 양식 확인
def correct_phone_number(file):
    wrong_list = []
    fhand = open(file,"r",encoding='UTF8')
    
    for line in fhand:
        print(line)
        phone_number = line.split(",")[1].strip()
        name = line.split(",")[0].strip()
        
        if not len(phone_number) == 13:
            wrong_list.append(name + ", " + phone_number)
        elif not phone_number[0:3] == "010":
            wrong_list.append(name + ", " + phone_number)
        elif phone_number[3] != "-" and phone_number[9] != "-" :
            wrong_list.append(phone_number)
        else:
            pass
    return wrong_list

file = "C:/Users/바탕 화면/visit.txt"
wrong_list = correct_phone_number(file)
print(wrong_list)
            


# In[1]:


#Q4 주민번호로 생년월일과 성별 추출
def check_id(a):
    if len(a) != 14:
        print("잘 못된 번호입니다")
        quit()
    elif a[6] != "-":
        print("잘 못된 번호입니다")
        quit()
    elif int(a[:2]) <= 21 and int(a[:2]) >= 0:
        ans = input("2000년 이후 출생자 입니까? 맞으면 o 아니면 x :")
        if ans == "o" and ans == "O" and ans == 0:
            if a[7] == '3':
                sex = "남자"
            elif a[7] == '4':
                sex = "여자"
            else:
                print("잘 못된 번호입니다")
                quit()
        else:
            print("잘 못된 번호입니다")
            quit()
    else:
        if a[7] == '1':
            sex = "남자"
        elif a[7] == '2':
            sex = "여자"
        else:
            print("잘 못된 번호입니다")
            quit()
        
    print("%s년%s월%s" %(a[:2],a[2:4],sex))


a = input("주민번호를 입력하세요")
check_id(a)


# In[ ]:




