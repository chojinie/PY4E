def check_id(a):
    while True:
        #주민등록번호 형식 체크하기
        if len(a) != 14 or a[:6].isdecimal() == False or a[7:].isdecimal() == False or a[6] != '-' or a[7] not in ['1','2', '3', '4'] :
            a = input('잘못된 주민등록번호 형식입니다.\n올바른 주민등록번호를 입력해주세요 : ')
            continue
        #생년월일 형식 체크하기
        if a[2:6] == '0229':
            if int(a[:2]) % 4 != 0: #윤달 고려
                a = input('잘못된 생년월일입니다.\n올바른 주민등록번호를 입력해주세요 : ')
                continue
        else:
            birth = {1 : 31, 2 : 28, 3 : 31, 4 : 30, 5 : 31, 6 : 30, 7 : 31, 8 : 31, 9 : 30, 10 : 31, 11 : 30, 12 : 31}
            if not int(a[2:4]) in birth.keys() or not 1 <= int(a[4:6]) <= birth[int(a[2:4])]:
                a = input('잘못된 생년월일입니다.\n올바른 주민등록번호를 입력해주세요 : ')
                continue
        #2000년 이후 출생자는 a[7]이 3 또는 4여야 함
        if 0 <= int(a[:2]) <= 21:
            b = input('2000년 이후 출생자 입니까? 맞으면 o 아니면 x : ')
            while b != 'x' and b != 'o':
                b = input('잘못 입력하셨습니다. o 또는 x 하나만 입력해주세요 : ')
            if b == 'o':
                if a[7] != '3' and a[7] != '4':
                    a = input('2000년 이후 출생자 분들의 주민등록번호 뒷자리는 3이나 4여야 합니다.\n올바른 주민등록번호를 입력해주세요 : ')
                    continue
                else:
                    return a
            else:
                if a[7] == '3' or a[7] == '4':
                    a = input('2000년 이전 출생자 분들의 주민등록번호 뒷자리는 1이나 2여야 합니다.\n올바른 주민등록번호를 입력해주세요 : ')
                    continue
        else:
            if a[7] == '3' or a[7] == '4':
                a = input('2000년 이전 출생자 분들의 주민등록번호 뒷자리는 1이나 2여야 합니다.\n올바른 주민등록번호를 입력해주세요 : ')
                continue
        return a
   
#년, 월, 성별 결정
def year_month_gender(a):
    id = check_id(a)
    month = str(int(id[2:4]))
    if id[7] == '1':
        gender = '남자'
        year = '19' + id[:2]
    elif id[7] == '2':
        gender = '여자'
        year = '19' + id[:2]
    elif id[7] == '3':
        gender = '남자'
        year = '20' + id[:2]
    else:
        gender = '여자'
        year = '20' + id[:2]
    print("------------------")    
    print(year + "년 "+ month + "월생 " + gender)
    print("------------------")  


a = input('주민등록번호를 입력해주세요 : ')
year_month_gender(a)