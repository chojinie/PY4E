def wrong_guest_book(guest_book):
    f1 = open("guest_book.txt", "w", encoding='utf8')
    f1.write(guest_book)
    f1.close()

    f2 = open("guest_book.txt", "r", encoding='utf8')
    lines = f2.readlines()
    for line in lines:
        line = line.strip()
        index = line.find(",")
        phone_number = line[index+1:]
        phone_number = phone_number.strip()
        if len(phone_number) != 13 or phone_number[3] != "-" or phone_number[8] != "-" or not phone_number.startswith("010"):
            print("잘못 쓴 사람 : " + line[:index])
            print("잘못 쓴 번호 : " + phone_number + "\n")
    f2.close()


guest_book = """김갑, 123456789
이을, 010-1234-5678
박병, 010-5678-111
 최정, 111-1111-1111
정무, 010-3333-3333"""

wrong_guest_book(guest_book)