def make_comma(number):
    number = number.strip()
    while number.isdecimal() == False:
        number = input('잘못입력하셨습니다. 숫자를 입력해주세요 : ')
    number = str(int(number))

    number_rev = number[::-1]  # 거꾸로 정렬
    answer = []
    for n in number_rev:
        answer.append(n)
        if len(answer) % 4 == 3:
            answer.append(',')

    if answer[-1] == ',':
        answer.pop()

    answer.reverse()  # 거꾸로 정렬
    print(''.join(answer))


number = input('숫자를 입력해주세요 : ')
make_comma(number)