#Jane_09team_4주차미션
#팀원이 충원되어 전보다 다양한 풀이가 많이 들어와 모두 수록했습니다.


#Q1. 우리는 큰 수를 나타낼 때 3자리마다 , 를 찍어서 구분해 줍니다. 파이썬에서는 아래와 같이 쉽게 나타낼 수 있습니다.
# f"{숫자:,}"
#print(f"{1000:,}")
#하지만 이번 미션에서는 숫자를 입력 받고 3자리마다 ,를 찍어주는
#함수를 만들어 봅시다.


#1번 문제는 팀원들이 예시 답안을 보면서 공부하는 경우가 있어서
#풀이 하나만 들어왔습니다.
#예시 풀이에서는 index를 -1로부터 해서 음수를 활용했고, 
#이 경우는 list의 reverse 기능을 활용해서 인덱스는 양수로 활용했습니다. 

def comma(num):
    num = str(num)

    if len(num)<=3:
        return num  #3자리 이하면 comma를 찍을 필요가 없어서 바로 리턴시켰습니다. 

    lis = list(num)

    lis.reverse()

    comlis = [] 
    comlis.append(lis[0]) 
    #인덱스가 3의 배수일때 comma를 추가해야하는게 목표였습니다.
    #그래서 0번째는 ZeroDivision Error 가 나오지 않기 위해 미리 하나 넣어놨습니다 

    j = 1
    while True: 
        if j%3 == 0:
            comlis.append(",")
            comlis.append(lis[j])
            j+=1
        else:
            comlis.append(lis[j])
            j+=1
        
        if j == len(lis):
            break
    #print(comlis) 
    #프린트하면 거꾸로 들어간 리스트가 출력됩니다
    comlis.reverse()
    #print(comlis)
    #다시 거꾸로 하면 comma가 삽입된 채로 숫자 하나하나 쪼개진 형태의 리스트가 나옵니다 
    result = ""
    for k in comlis:
        result += k 
    #이를 문자열로 만들었습니다 
    
    return result

print(comma(987654))
print(comma(12343256432))
print(comma(10))
print(comma(100))
print(comma(1000))

#2
#어느날 여러분이 어떤 글을 읽고 있는데, 갑자기 특정 글자가 전체 글에서 몇개 들어있는지 궁금해졌습니다. 그럼 한 번 파이썬 함수로 만들어 봅시다.
#글은 어떤 글이 좋습니다. 인터넷에서 검색해서 복사 붙여넣기로 변수에 넣어 줍니다.
#변수에 담긴 글을 함수에 넣어주면 txt 파일로 저장도 함께 되도록 해줍니다.

#2번 풀이는 3가지가 있었는데, 눈에 띄는 큰 차이는 없었고,
#대체로 문자열의 count method 를 사용하는 방법이었습니다.


def count_word(textfile,word): #함수를 실행하면 그냥 txt 파일로 저장하게 했습니다 
    file = open("newfile.txt", 'w', encoding = 'utf-8')
    file.write(textfile)
    file.close()
    xfile = open("newfile.txt")
    line = xfile.readline()
    print(f"해당 글에는 '{word}' 가 ", line.count(word), "개 들어 있습니다")

textfile = str(input("글을 입력해주세요: "))
word = str(input("찾고 싶은 단어를 입력해주세요: "))
print(count_word(textfile,word))


def count_word(a, b): #문자열에서 찾는 문자의 개수를 찾는 함수입니다.
    ahand = open("a.txt")
    count = a.count(b)
    print("찾는 글자:",b,". 개수:",count)
print("글 속 특정 글자 개수를 세는 프로그램입니다.")
a = input("글을 입력해주세요: ")
file = open("a.txt", "w")
file.write(a)
file.close()
b = input("찾는 글자: ")
count_word(a, b)


def count_word(text, find_word): #위 함수와 거의 비슷한 방식입니다.
    fhand = open('exam.txt',encoding = 'UTF-8')
    count = text.count(find_word)
    print("찾는 글자: ",find_word)
    print("찾는 글자 개수: ",count)
text = input('글을 입력해주세요 : ')
fhand = open('exam.txt','w')
fhand.write(text)
fhand.close()
find_word = input('찾는 글자를 입력해주세요 : ')
count_word(text,find_word)


#3

#요즘 식당에 들어가면 방명록을 적게 되어있습니다.
#어느 식당의 사장님이 여러분에게 방명록을 주면서 전화번호를 제대로 적었는지 검사해달라는 부탁을 했습니다.
#아래와 같은 방명록이 있을 때 방명록을 잘 못쓴 사람의 이름과 잘 못된 번호를 출력하는 함수를 만들어 봅시다.

#3개의 코드가 들어와서 모두 설명해보겠습니다 

#첫번째 함수

def gb_wrong(guestbook):
    ghand = open('guestbook.txt')
    for line in ghand: #for루프 안에서 입력한 guestbook 정보중 잘못된 경우를 모두 프린트하는 방식의 함수입니다 
        line = line.rstrip()
        comma =  line.find(',')  #comma의 위치를 아예 찾은 후에 
        per = line[: comma]   #그 자리까지를 사람 이름으로 하고 
        num = line[comma+1:]  #그 이후부터를 전화번호로 따로 변수에 부여하는 방식이었습니다 
        if not num.startswith('010'):
            print("\n잘못 쓴 사람:",per)
            print("잘못 쓴 번호:",num) 
        elif num[3 and 8] != int:
            print("\n잘못 쓴 사람:",per)
            print("잘못 쓴 번호:",num)
        elif len(num) != 13:
            print("\n잘못 쓴 사람:",per)
            print("잘못 쓴 번호:",num)
        else:
            for line in ghand:
                print("모두 잘 입력했습니다.") 
guestbook = """김갑,123456789
이을,010-1234-5678
박병,010-5678-111
최정,111-1111-1111
정무,010-3333-3333"""
file = open("guestbook.txt", "w")
file.write(guestbook)
file.close()

gb_wrong(guestbook) 


#두번째 함수

def wrong_guest_book(num):
  ipos = num.find("-") #"-"가 있는 곳을 위치로 설정해서 
  a = num[:ipos]  # "-" 이전에 010이 아니거나 3번쨰, 8번째가 "-"가 아닌 경우를 프린트하는 함수입니다.
  if(a != '010' or num[3] != '-' or num[8] != '-'):
    print('잘못 쓴 사람: ',book_name[i])
    print('잘못 쓴 번호: ',num)

#함수 자체는 간단하고, 대신 하나 하나 인원의 이름과 번호를 입력하는 곳에서 루프를 활용했습니다.
#실시간으로 인원의 이름과 번호를 입력해야 한다면 이 편이 좋겠습니다 
book_name = list()
book_num = list()
person = int(input('방명록에 적을 인원 수를 입력하세요: '))
for i in range(person):
    name = input('이름을 입력하세요: ')
    book_name.append(name)
    print("번호 입력 예시: 010-1234-5678")
    num = input('번호를 입력하세요: ')
    if (len(num) < 14):
        book_num.append(num)
        wrong_guest_book(num)
    else:
        print("번호를 잘못 입력하셨습니다.")
print("=============================")
print("       방      명     록      ")
print("=============================")
for i in range(person):
  print(book_name[i],",",book_num[i])
  fhand = open('exam.txt','w')
  fhand.write(book_name[i])
  fhand.write(book_num[i])
  fhand.close()


#세번째 함수
#잘못 입력한 사람의 이름과 번호를 딕셔너리로 각각 저장해서 key와 value 로 각각 프린트하는 함수입니다

def wrong_guest_book(guest_book):

    file = open("guestbook.txt", 'w', encoding = 'utf-8')
    file.write(guest_book)
    file.close()

    xfile = open("guestbook.txt")

    wrong = []
    for line in xfile:
        line = line.rstrip()
        if ",010-" not in line: wrong.append(line)
        elif len(line[3:]) != 13: wrong.append(line)
        elif line[6] and line[11] != '-': wrong.append(line)
    
    result = dict(j.split(',') for j in wrong) 
    # ","를 기준으로 두개 나누고 이를 각각 딕셔너리의 key, value 로 나눠서 딕셔너리에 저장하는 과정 

    for key, value in result.items():
        print("잘못 쓴 사람:", key, "\n잘못 쓴 번호:", value, "\n")
    #key 와 value 를 이렇게 프린트하고 가독성을 위해 줄바꿈 이스케이프 코드를 활용했습니다 


guest_book = """김갑,123456789
이을,010-1234-5678
박병,010-5678-111
최정,111-1111-1111
정무,010-3333-3333"""
wrong_guest_book(guest_book)



#4
# 주민등록번호의 앞 6자리는 생년월일이고 뒷자리의 시작번호는 성별을 나타냅니다. 주민등록번호를 입력하면 몇년 몇월 생인지 그리고 남자인지 여자인지 출력하는 함수를 만들어 봅시다.
#주민등록번호는 6자리 이후에 -로 구분되어야 하고 길이는 -포함 14임
#뒷자리는 1,3 은 남자 2,4는 여자
#00 ~ 21로 시작할 경우 2000년 이후 출생자인지 물어 볼 것 (맞으면 o 틀리면 x)
#뒷자리 3, 4를 가질 수 있는 사람은 00년생 이후 출생자 밖에 없음
#주민등록번호 조건을 만족하지 않는 수가 입력되면 "잘 못된 번호입니다"를 출력해주세요.

#4번의 경우 예시에 약간 오류가 있었다고 판단되었는데, 
#2000년 이후 출생자인것을 o/x로 사용자에게 직접 프롬프트로 물어본 후의 뒷자리 번호를 판단하기에
#마지막 예시가 주민번호 자체가 오류인 것 같아 팀원들이 미션을 풀면서 혼동이 좀 있었습니다. 
#따라서 판단 기준이 약간 다를 수 있음을 감안해주셨으면 합니다. 

#첫번째 함수
#a,b,c,d,e 변수 각각은 
#전체 주민번호, 주민번호 앞자리 7자 , 주민번호 뒷자리 7자, 앞자리중 태어난 해를 나타낸 부분, 뒷자리 맨 앞자리(성별)
#을 의미합니다.
#주민번호를 입력하면 4가지 추가적인 정보로 쪼개져서 그것을 기준으로 판단하는 함수입니다. 

def check_id(b,c):
    d = int(b[0:2])
    e = int(c[0])
    if(d < 21):
        answer = input('2000년 이후 출생자입니까? 맞으면 o 아니면 x: ')
        if(answer == 'o' and (e == 3 or e ==4)):
            print('맞습니다.')
        elif(answer == 'x' and (e == 3 or e ==4)):
            print('2000년 이후 출생자입니다.')
        else:
            print('잘못된 번호입니다.')
            print('올바른 번호를 넣어주세요')
    else:
        if(e == 1 or e == 3):
            print(d,'년',b[2:4],'월','남자')
        elif(e == 2 or e == 4):
            print(d,'년',b[2:4],'월','여자')
print('주민등록번호 입력 예시: 123456-1234567')
a = input('주민등록번호를 입력해주세요 : ')
ipos = a.find("-")
b = a[:ipos]
c = a[ipos+1:]
if (len(a) < 15):
    check_id(b,c)
else:
    print('올바른 번호를 입력해주세요')



#두번째 함수
#변수는 yy, mm, gen 등 비교적 이해하기 쉬운 변수로 설정하셨습니다.
#위에서 말한 예시의 오류때문에 그 부분을 정확하게 판단이 안 되신다고 하셨는데, 
#다른 팀원들도 그 부분에 대해서는 동의하셔서 굳이 디버깅을 요구하진 않았습니다. 

id = input("주민등록번호 : ")

def check_id(id):
  yy = int(id[0:2])
  mm = int(id[2:4])
  gen = int(id[7:8])
  after_2000 = "x"

  if 0 <= yy and yy <= 21:
    after_2000 = input("2000년 이후 출생자 입니까? 맞으면 o 아니면 x : ")

  if gen == 1 or gen == 3:
    gen = "남자"
  elif gen == 2 or gen == 4:
    gen = "여자"

  if after_2000 == "x" and (gen == 3 or gen == 4):
    print("잘못된 번호입니다")
  elif len(id) != 14:
    print("잘못된 번호입니다")
  else:
    print("%d년 %d월 %s" %(yy, mm, gen))

check_id(id)