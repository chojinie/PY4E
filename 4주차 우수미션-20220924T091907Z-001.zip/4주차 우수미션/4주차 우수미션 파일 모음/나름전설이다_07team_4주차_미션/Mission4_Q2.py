def count_word(t, l):
    # 앞뒤 중간 공백은 싹 지우자
    word = t.replace(' ', '')
    # 찾을 문자열의 길이
    flen = len(l)
    # 찾은 문자열을 담을 변수
    xletter = ''
    for letter in word:
        for i in range(flen):
            # 문자마다 비교해서 같으면 준비된 변수에 차곡차곡 병합
            if letter == l[i:i+1]:
                xletter += letter

    # 병합한 문자열의 길이
    xlen = len(xletter)
    # 문자열 길이와 병합한 문자열을 나누면 끝
    # 이걸로 끝내도 되지만 한번 더 비교를 해보자
    rlen = int(xlen/flen)
    # 찾고자 하는 문자열이 어느 위치에 있는지 담을 변수
    n = 0
    count = 0
    # 찾은 문자열의 위치 찾기
    n = xletter.find(l)
    s = n
    e = flen
    for j in range(rlen):
        # 루프가 한번 돌 때 마다 문자 위치도 증가
        # 습니다 0 3
        # 습니다 3 6
        # 습니다 6 9
        # 습니다 9 12
        # 습니다 12 15
        if j > 0:
            s = e
            e = s + flen
        # 찾고자 하는 문자열과 찾은 문자열 비교
        # print(xletter[s:e], s, e)
        if l == xletter[s:e]:
            count = count + 1
    
    # encoding error 가 발생해서 'UTF-8' 고정
    f = open('word.txt', 'w', encoding='UTF-8')
    f.write(t)
    # 썼으면 닫아주자
    f.close()

    print(count)

t = "반갑습니다. 파이썬 공부는 정말 재밌습니다. 어렵습니다. 그렇습니다. 네 맞습니다."
l = "습니다"
count_word(t, l)