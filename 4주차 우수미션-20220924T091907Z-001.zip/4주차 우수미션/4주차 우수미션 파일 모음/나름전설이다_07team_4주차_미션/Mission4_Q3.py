def save_quest_book(data):
    f = open('guest_book.txt', 'w', encoding='UTF-8')
    f.write(data)
    # 썼으면 닫아주자
    f.close()

def wrong_number(n):
    # print(n[0][0],n[0][1],n[0][2])
    if int(len(n[0][0])) < 3 or int(len(n[0][0])) > 3:
        return False
    elif n[0][0] != '010':
        return False
    elif int(len(n[0][1])) < 4 or int(len(n[0][1])) > 4:
        return False
    elif int(len(n[0][2])) < 4 or int(len(n[0][0])) > 4:
        return False
    else:
        return True

def wrong_guest_book(guests):
    try:
        save_quest_book(guest_book)
    except:
        print("파일 저장 실패")

    data = []
    data.append(guests.split("\n"))
    # print(data[0])
    # print(range(len(data[0])))
    for i in range(len(data[0])):
        p = []
        p.append(data[0][i].split(","))
        if int(len(p[0][1])) < 13 or int(len(p[0][1]) > 13):
            print("잘못 쓴 사람: ", p[0][0])
            print("잘못 쓴 번호: ", p[0][1])
        else:
            pn = []
            pn.append(p[0][1].split("-"))
            re = wrong_number(pn)
            if re is False:
                print("잘못 쓴 사람: ", p[0][0])
                print("잘못 쓴 번호: ", p[0][1])

guest_book = """김갑,123456789
이을,010-1234-5678
박병,010-5678-111
최정,111-1111-1111
정무,01-43333-3333
돌김,011-1234-5678"""
wrong_guest_book(guest_book)