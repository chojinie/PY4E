def make_comma():
    try:
        num=int(input("숫자를 입력하세요. :"))
        num=str(num)
        a=len(num)
        number=[]
        while a>0:
            if a%3==0:
                number.append(",")
            number.append(num[-a])
            a=a-1
        number="".join(number[:])
        if number.startswith(","):
            print(number[1:])
        else:
            print(number[:])
    except:
        print("다시 입력하세요.")

make_comma()