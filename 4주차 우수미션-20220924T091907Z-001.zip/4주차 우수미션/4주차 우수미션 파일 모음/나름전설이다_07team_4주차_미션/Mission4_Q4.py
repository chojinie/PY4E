def check_id(id):
    if len(id) == 14:
        # 주민등록번호를 "-" 구분으로 둘로 나눈다
        ids = id.split("-")
        birth = ids[0]
        serial = ids[1]
        sex = ""
        if serial[0:1] == "1" or serial[0:1] == "3":
            sex = "남자"
        elif serial[0:1] == "2" or serial[0:1] == "4":
            sex = "여자"
        else:
            print("잘못된 번호입니다.\n올바른 번호를 넣어주세요")
        
        if int(birth[0:2]) >= 0 and int(birth[0:2]) <= 21:
            y2k = input("2000년 이후 출생자 입니까? 맞으면 o 아니면 x : ")
            if y2k == "o":
                print(birth[0:2] + "년" + birth[2:4] + "월", sex)
            else:
                print("잘못된 번호입니다.\n올바른 번호를 넣어주세요")
        # 시작 년도를 30년부터로 99년도까지 설정
        elif int(birth[0:2]) >= 30 and int(birth[0:2]) <= 99:
            print(birth[0:2] + "년" + birth[2:4] + "월", sex)
        else:
            print("잘못된 번호입니다.\n올바른 번호를 넣어주세요")

    else:
        print("잘못된 번호입니다.\n올바른 번호를 넣어주세요")

# a = "500629-2222222"
a = "000629-2222222"
check_id(a)