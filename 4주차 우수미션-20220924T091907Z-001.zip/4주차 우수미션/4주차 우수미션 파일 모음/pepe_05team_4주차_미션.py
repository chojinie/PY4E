#!/usr/bin/env python
# coding: utf-8

# In[3]:


import re
def make_comma():
    while True:
        try:
            num = int(input("(4자리 이상) 숫자를 입력하세요. :"))
            num_str = str(num)
        except:
            print("다시 정수를 입력해주세요.")
            continue
        result = re.sub('(?<=\\d)(?=(\\d{3})+(?!\\d))',',', num_str)
        print(result)
        break
make_comma()
# re.sub(정규표현식, 바꿀문자열, 대상 문자열)
# 정규표현식 : (?<=\\d)(?=(\\d{3})+(?!\\d))
    # (?<=\\d) : 0~9까지의 숫자 보다 작거나 같은 값이 하나 있거나 없거나
        # () : 그룹을 만들어 주는 메타 문자
        # ? : {0, 1}을 의미
        # \\d : 숫자와 매치, [0-9]와 동일한 표현식
    # (?=(\\d{3})+(?!\\d))
        # {} 메타 문자를 사용하여 반복횟수 지정 => {3} : 반드시 3번 반복 => \\d{3} : 0-9의 숫자를 3번 반복
        # (\\d{3})+ : 0~9사이의 숫자가 세번 반복되는 것이 하나 이상이어야 함
        # (?!\\d) : 숫자가 아닌 것이 한번 있거나 없거나
# 바꿀문자열 : 콤마','
# 대상문자열 : str(num)
    # str(num) : '콤마(,)'를 붙이기 때문에 문자열 처리


# In[8]:


# [test data] "안 촉촉한 초코칩 나라에 살던 안 촉촉한 초코칩이 촉촉한 초코칩 나라의\n 촉촉한 초코칩을 보고 촉촉한 초코칩이 되고 싶어서 촉촉한 초코칩 나라에\n 갔는데, 촉촉한 초코칩 나라의 촉촉한 문지기가 "넌 촉촉한 초코칩이 아니고\n 안 촉촉한 초코칩이니까 안 촉촉한 초코칩 나라에서 살아"라고 해서 안 촉촉한\n 초코칩은 촉촉한 초코칩이 되는 것을 포기하고 안 촉촉한 눈물을 흘리며 안\n 촉촉한 초코칩 나라로 돌아갔다."
def count_word():
    text_save = open("text.txt", "wt", encoding="utf-8")
    text = input("테스트할 전체 글을 입력해주세요. : ")
    word = input("개수를 셀 특정 글자를 입력해주세요 : ")
    text_save.write(text)
    text_save.close()

    
    with open("text.txt", encoding="utf-8") as f:
        data = f.read()
        print(data.count(word))

count_word()


# In[9]:


#[test data] """김갑,123456789 이을수,010-1234-5678 박병,010-5678-111 최정,111-1111-1111 정무,010-3333-3333 대한민국,010-4312-0213"""
def wrong_guest_book(guest_book):
	# text 파일 저장
    text_save = open("guest_book.txt","w", encoding="UTF8")
    text_save.write(guest_book)
    text_save.close()
	# 파일 불러오기
    file = open("guest_book.txt", "r", encoding="UTF8")
    for line in file: # 이름과 전화번호 구분
        istr = line.find(',')
        # 이름 : 글자의 갯수에 따라 다른 값이 들어가야함
        if istr == 3: # 3글자
            name = line[:3]
            phone_number = line[4:].strip()
        elif istr == 4: # 4글자
            name = line[:4]
            phone_number = line[5:].strip()
        else:
            name = line[:2] # 2글자
            phone_number = line[3:].strip()
        # 조건을 만족하면 continue 아니면 출력
        if len(phone_number) == 13 and phone_number.find("-") != -1 and phone_number.startswith("010") == True:
            continue
        else:
            print(f"잘못 쓴 사람: {name}")
            print(f"잘못 쓴 번호: {phone_number}")
            print()
guest_book = """김갑,123456789
이을수,010-1234-5678
박병,010-5678-111
최정,111-1111-1111
정무,010-3333-3333"""
wrong_guest_book(guest_book)


# In[6]:


def check_id(id_number):
    while True:
        if len(id_number) != 14 or id_number.find("-") == -1:
            print("잘못된 번호입니다.")
            break
        
        # 21 이하의 숫자로 시작하면 2000년 이후 출생인지 물어보기
        if int(id_number[:2]) <=21:
            q = input("2000년 이후 출생자 입니까? 맞으면 o 아니면 x : ")
            # 2000년 이후 출생일 때
            if q == "o":
                if id_number[7] not in ["3" ,"4"]:
                    print("잘못된 번호입니다.")
                else:
                    if id_number[7] == "3":
                        gender = "남자"
                    else:
                        gender = "여자"
            # 아닐때 1900년 ~ 1921년 사이 출생일 때
            elif q == "x":
                if id_number[7] == "1":
                    gender = "남자"
                else:
                    gender = "여자"
            else:
                continue
        # 1922년 ~ 1999년 사이 출생일 때
        else:
            if id_number[7] not in ["1" , "2"]:
                print("잘못된 번호입니다.")
            else:
                if id_number[7] == "1":
                    gender = "남자"
                else:
                    gender = "여자"
        year = id_number[:2]
        mon = id_number[2:4]
        try:
            print(f"{year}년{mon}월 {gender}")
        except:
            print("올바른 번호를 넣어주세요")
        break

id_number = str(input('주민등록번호를 넣어주세요.(-도 써 주세요.) :'))

check_id(id_number)


# In[ ]:




