# 4주차 미션 Q3. 방명록 검사
def wrong_guest_book(guest):
    print(f"{guest}\nwrong_guest_book(guest_book)\n")
    file = open('Mission4-3.txt', 'w')
    file.write(guest)
    g_list = []
    i, j = 0, 0
    while True:     # 줄바꿈 기준으로 리스트 만들기
        if guest.find('\n', j) == -1 and len(guest) == i:
            break
        elif guest.find('\n', j) == -1 and len(guest) != i:
            g_list.append(guest[i:])
            i = len(guest)
        else:
            j = guest.find('\n', i) +1
            g_list.append(guest[i:j-1])
            i = j
    print(g_list)

    numbers = '0123456789'
    for a in g_list:    # 하나씩 입력값 검사
        comma = a.find(',')
        if a[comma+1:comma+4] == '010' and len(a[comma+1:]) == 13:
            for b in range(comma+4, len(a)):
                if a[b] in numbers:
                    continue
                elif a[b] not in numbers and a[b] == '-' and (b == comma+4 or b == comma+9):
                    continue
                else:
                    print(f"잘못쓴 사람: {a[:2]}\n잘못쓴 번호: {a[comma + 1:]}\n")
                    break
        else:
            print(f"잘못쓴 사람: {a[:2]}\n잘못쓴 번호: {a[comma+1:]}\n")

guest_book = """김갑,123456789
이을,010-1234-5678
박병,010-5678-111
최정,111-1111-1111
정무,010-3333-3333
손흥,010--234-6543"""

wrong_guest_book(guest_book)
