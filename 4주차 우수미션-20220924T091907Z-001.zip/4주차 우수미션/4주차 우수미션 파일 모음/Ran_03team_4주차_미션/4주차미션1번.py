##숫자 넣으면 세자리마다 콤마 붙여주는 함수만들기
def make_comma(num):
    cnt=0
    ##3으로 나눈 나머지를 이용해서 나머지만큼 가서 쉽표를 찍고
    ##이후에는 3개씩 건너뛰며 쉼표 찍자
    remainer=len(num)%3
    for s in num:
        print(s,end='')
        cnt=cnt+1
        if cnt==remainer:
            print(',',end='')
        elif cnt==len(num):
            break
        elif cnt%3==remainer:
            print(',',end='')

num=str(input('enter number: '))

make_comma(num)
