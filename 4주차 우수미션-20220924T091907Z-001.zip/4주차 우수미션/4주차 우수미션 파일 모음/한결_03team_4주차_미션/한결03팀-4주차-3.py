guest_book = """
김갑,123456789
이을,010-1234-5678
박병,010-5678-111
최정,111-1111-1111
정무,010-3333-3333
"""


def write_file(content):
    fhand = open("방명록.txt", 'w', encoding="UTF-8")
    fhand.write(content)
    fhand.close()


def check_number(number):
    if len(number) == 13:
        if number.count('-') == 2:
            div = number.split('-')
            if div[0] == '010':
                if div[1].isdigit() and div[2].isdigit():
                    return True
    return False


def wrong_guest_book(value):
    write_file(value)

    logs = value.strip().split('\n')
    for i in logs:
        name, number = i.split(',')
        if not check_number(number):
            print(f'\n잘못 쓴 사람 : {name}\n잘못 쓴 번호 : {number}')


wrong_guest_book(guest_book)
