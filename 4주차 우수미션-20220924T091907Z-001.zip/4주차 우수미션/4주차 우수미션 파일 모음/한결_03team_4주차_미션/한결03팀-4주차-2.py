#미션2

a="""행복을 불러들이는 방법

행복은 구한다고 얻어지는 것이 아닌다.
항상 기쁜 마음을 가지고 살아가는 것,
이것이 행복을 불러들인다.

불행은 피한다고 해서 피해지는 것이 아니다.
항상 남의 마음을 아프게 하지 않도록
노력하는것, 이것이 불행을 멀리하게 한다.

즐거운 마음으로 착한 일을 많이 함으로써
복을 부르는 근본으로 삼고,

남을 해치려는 마음을 버림으로써
화를 멀리하는 근본으로 삼아야한다."""

def make_file(text):
    fhand = open("새파일.txt", 'w', encoding="UTF-8")   # 한글이 깨지므로 인코딩 설정
    fhand.write(text) 
    fhand.close()

def find_word(content, word):
    y = content.count(word)
    print(f'글에서 {word}를 {y}개 찾았습니다.')
    return

make_file(a) 
print(a)
print('-'*30)

find_word(a, "행복")
find_word(a, "불행")

print("\n행복 승리!")