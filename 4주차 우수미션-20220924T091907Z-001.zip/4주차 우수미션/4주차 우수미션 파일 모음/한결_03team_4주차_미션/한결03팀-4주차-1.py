n = input('정수를 입력해주세요 : ')


def make_comma(num):
    num = num[::-1]
    result = ''
    for idx, val in enumerate(num):
        if idx % 3 == 0:
            result += ','
        result += val

    return result[:0:-1]


print(make_comma(n))
