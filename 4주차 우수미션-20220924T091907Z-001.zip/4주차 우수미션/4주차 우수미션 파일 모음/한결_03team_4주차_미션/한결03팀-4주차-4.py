# 주민등록번호

def check_gender(x):  # 성별 확인 함수
    if(int(x[7]) == 1 or int(x[7]) == 3):
        gender = "남자"
        return gender
    if(int(x[7]) == 2 or int(x[7]) == 4):
        gender = "여자"
        return gender


def check_id(y):  # 2000년 이전/이후 판별 후 출력하는 함수
    if(0 <= int(y[0]) <= 2):
        answer = int(input("2000년 이후 출생자입니까? 맞으면 0, 아니면 1 : "))
        if answer == 0:  # 2000년 이후 출생 맞다.
            if(int(y[7]) == 3 or int(y[7]) == 4):
                print(f'{y[0:2]}년 {y[2:4]}월 {check_gender(y)}')
            else:  # 근데 아니었다.
                print("{0:=^45}".format("오류"))
                print("""잘못된 번호입니다. 올바른 번호를 입력해주세요.""")
                print("{0:=^45}".format("="))

        if (answer == 1):  # 2000년 이전 출생이다.
            print("2000년 이전 출생자입니다.")
            print(f'{y[0:2]}년 {y[2:4]}월 {check_gender(y)}')
    elif(2 < int(y[0]) <= 9):
        print(f'{y[0:2]}년 {y[2:4]}월 {check_gender(y)}')


id = input("주민등록번호를 입력해주세요(-포함 14자리): ")

if(id.count("-") == 1 and len(id) == 14):
    check_id(id)
else:
    print("다시 입력해주세요.")
