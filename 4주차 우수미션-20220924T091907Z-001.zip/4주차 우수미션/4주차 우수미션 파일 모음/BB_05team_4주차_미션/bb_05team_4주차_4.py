# 주민등록번호
def jnumber():
    number = input("주민등록 번호를\n000000-0000000\n같은 형식으로 입력해하고 엔터키를 눌러주세요.\n")
    try:
        number = str(number)
        print(number)
    except:
        print("1 2 3 4 5 6 7 8 9숫자와 -으로 입력하고 엔터를 눌려 주세요.\n")
        quit()
        
    anum = number[:2]
    bnum = number[2:4]
    cnum = number[7:8]
    cnum = int(cnum)
    if cnum%2 == 0:
​
        sex = "여자"
    else :
        sex = "남자"
    print(anum,"년",bnum,"월",sex)
​
jnumber()