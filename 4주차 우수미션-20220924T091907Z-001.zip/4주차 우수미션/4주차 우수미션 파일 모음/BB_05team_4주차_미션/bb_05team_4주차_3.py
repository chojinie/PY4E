# 전화번호 검사 
​
# 방명록을 txt파일로 만드는 함수
def book(a):
    print("방명록")
    print(a)
    fw = open('book.txt','w')
    fw.write(a)
    fw.close()
​
# 방명록에서 잘못된 전화번호 찾는 함수
def findwrong(a):
​
    # txt파일 열기
    infor = open('book.txt')
    # 한줄씩 반복하여 실행
    for line in infor:
        
        # '-'이 없는 번호 찾기
        if not line.find('-'):
            print("wrong person : %s" % (line[:2]))
            print("wrong number : %s" % (line[3:]))
        
        # 전화번호 숫자가 부족한 번호 찾기
        elif not len(line[3:]) == 14:
            print("wrong person : %s" % (line[:2]))
            print("wrong number : %s" % (line[3:]))
        
        # 시작을 '010'으로 하지 않는 번호 찾기
        elif not line[3:].startswith('010'):
            print("wrong person : %s" % (line[:2]))
            print("wrong number : %s" % (line[3:]))
        
​
# 방명록 입력
guest_book = """김갑,123456789
이을,010-1234-5678
박병,010-5678-111
최정,111-1111-1111
정무,010-3333-3333 """
​
book(guest_book)
​
findwrong(guest_book)
​