###Soltion_01
n = int(input("첫 번째 수 입력: "))
m = int(input("두 번째 수 입력: "))

number_list = []
even_number_list = []

def find_even_number(a, b):
    for h in range(a, b + 1):
        number_list.append(h)
        if h % 2 == 0:
            even_number_list.append(h)
    
    if b % 2 == 0:
        for i in range(len(even_number_list)):
            print(even_number_list[i], "짝수")
    else:
        median_value = int(sum(number_list) / len(number_list))
        if median_value % 2 == 0:   
            for j in range(even_number_list.index(median_value) + 1):
                print(even_number_list[j], "짝수")
            print(median_value, "중앙값")
            for k in range(even_number_list.index(median_value) + 1, len(even_number_list)):
                print(even_number_list[k], "짝수")
        else:
            for l in even_number_list:
                print(l, "짝수")

find_even_number(n, m)



###Solution_02
def find_even_number(n, m):
    numbers = [ i for i in range(n,m+1)]
    sizenum = len(numbers)#배열의 전체길이 
    center = int(sizenum/2) #중앙값 
    for i in range (0,sizenum):
        if numbers[i] % 2 == 0:
            print(numbers[i]," 짝수")
            if i == center:
                if (sizenum+1) % 2 == 0:
                    print(numbers[int(sizenum/2)], "중앙값")


n = int(input("첫 번째 수 입력 : "))
m = int(input("두 번째 수 입력 : "))
find_even_number(n, m)