###Soltion_01
import random

pass_list = ["0", "1", "2", "가위", "바위", "보"]

my_record = []
computer_record = []

games = int(input("몇 판을 진행하시겠습니까? : "))
print()

def rsp_advanced(number):
    for i in range(number):
        j = str(i + 1)
           
        print(j, "번째 판을 진행합니다.")
        
        while True:
            my_rsp = input("가위 바위 보: ")
            if my_rsp in pass_list:
                break
            else:
                print("0, 1, 2, 가위, 바위, 보 이외의 입력은 불가능합니다. 다시 입력해주세요.\n")
                print(j, "번째 판을 다시 진행합니다.")
                continue

        def rsp(my_choice):  
            if my_choice == "가위":
                my_rsp = 0
                print("나: 가위")
            elif my_choice == "0":
                my_rsp = 0
                print("나: 가위")
            elif my_choice == "바위":
                my_rsp = 1
                print("나: 바위")
            elif my_choice == "1":
                my_rsp = 1
                print("나: 바위")
            elif my_choice == "보":
                my_rsp = 2
                print("나: 보")
            elif my_choice == "2":
                my_rsp = 2
                print("나: 보")
                
            computer_rsp = random.randint(0, 2)
            if computer_rsp == 0:
                computer = str("가위")
            elif computer_rsp == 1:
                computer = str("바위")
            elif computer_rsp == 2:
                computer = str("보")
            print("컴퓨터:", computer)
            
            remainder = my_rsp - computer_rsp
            
            if remainder == 0:
                result = str("무승부!\n")
                my_record.append("tie")
                computer_record.append("tie")
            elif remainder == -1:
                result = str("컴퓨터의 승리!\n")
                my_record.append("lose")
                computer_record.append("win")
            elif remainder == -2:
                result = str("나의 승리!\n")
                my_record.append("win")
                computer_record.append("lose")
            elif remainder == 1:
                result = str("나의 승리!\n")
                my_record.append("win")
                computer_record.append("lose")
            elif remainder == 2:
                result = str("컴퓨터의 승리!\n")
                my_record.append("lose")
                computer_record.append("win")
            return result

        R = rsp(my_rsp)

        print(j, "번째 판:", R)

rsp_advanced(games)

print("나의 전적: ", str(my_record.count("win")) + "승", str(my_record.count("tie")) + "무", str(my_record.count("lose")) + "패")
print("컴퓨터의 전적: ", str(computer_record.count("win")) + "승", str(computer_record.count("tie")) + "무", str(computer_record.count("lose")) + "패")



###Soltuion_02
import random as rm

def whowin(myrsp,computer): #승부판정
    if (myrsp == 0 and computer == 2):
        return "당신의 승리입니다."
    elif (myrsp == 0 and computer == 1):
        return "컴퓨터의 승리입니다."
    elif (myrsp == 0 and computer == 0):
        return "무승부 입니다."
    elif (myrsp == 1 and computer == 2):
        return "컴퓨터의 승리입니다."
    elif (myrsp == 1 and computer == 1):
        return "무승부 입니다."
    elif (myrsp == 1 and computer == 0):
        return "당신의 승리입니다."
    elif (myrsp == 2 and computer == 2):
        return "무승부 입니다."
    elif (myrsp == 2 and computer == 1):
        return "당신의 승리입니다."
    elif (myrsp == 2 and computer == 0):
        return "컴퓨터의 승리입니다."
    else:
        return "ERROR"
def rspdef(rsp): #입력받은 값을 판정을위해 바꿔줌
    if (rsp == "가위" or rsp == "0"):
        rsp = 0
    elif(rsp == "바위" or rsp == "1"):
        rsp = 1
    elif(rsp == "보" or rsp == "2"):
        rsp = 2
    else:#입력값이 잘못되었을경우 재귀함수로 재호출
        re = input("다시 입력해주세요 : ")
        return rspdef(re)
    return rsp
def prsp(rsp): #변환했던 입력값을 출력을위해 재변환
    if rsp == 0:
        return "가위"
    elif rsp == 1:
        return  "바위"
    elif rsp == 2:
        return  "보"
def rsp_advanced(games):
    cnt = 1
    result=[0,0,0,0,0]#mywin,mylose,draw,comwin,comlose
    while games+1 > cnt:
        result_size=len(result)
        rsp = input("가위(0), 바위(1), 보(2) 중에 하나를 입력해주세요.\n")
        computer = rm.randint(0,2)
        myrsp = rspdef(rsp)
        score = whowin(myrsp,computer)
        savescore = cntscore(result,score)
        print("당신 :",prsp(myrsp))
        print("컴퓨터 :",prsp(computer))
        print(cnt ,"번째 게임은 ",score ,"\n")
        cnt += 1
    pscore(result)

def cntscore(result,score):#전적 카운팅s
    if (score == "당신의 승리입니다."):
        result[0] += 1
        result[4] += 1
        return result
    elif (score == "컴퓨터의 승리입니다."):
        result[1] += 1
        result[3] += 1
        return result
    elif (score == "무승부 입니다."):
        result[2] += 1
        return result

def pscore(result):#최종 스코어 출력
    print("나의 전적 : ",result[0],"승",result[2],"무",result[1],"패")
    print("컴퓨터의 전적 : ",result[3],"승",result[2],"무",result[4],"패")

try:
    print("가위바위보 프로그램입니다.")
    games = int(input("몆판을 진행하시겠습니까? : "))
    rsp_advanced(games)
except:
    print("올바른 값을 입력해주세요.")