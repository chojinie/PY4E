###Solution_01
def count_prime_number(prime,num):
    for i in range(2, num+1):
        if check_prime(i)==True:
            prime.append(i)
            cnt = len(prime)
    return cnt

def check_prime(n):
    for i in prime:
        if n % i == 0:
            return False
    return True


prime=[]
print("두 수 사이의 소수의 개수를 구하는 프로그램 입니다.")
n = int(input("첫 번째 수 입력(작은수) : "))
m = int(input("두 번째 수 입력(큰수) : "))
Prime_A = count_prime_number(prime,n)#첫번째 수의 소수 개수
Prime_B = count_prime_number(prime,m)#두번째 수의 소수 개수
result = Prime_B-Prime_A # 두 수 사이의 소수의 개수 
print("두 수 사이의 소수의 개수는 " ,result, " 개 입니다.")



###Solution_02
num1 = int(input("첫 번째 수 입력: "))
num2 = int(input("두 번째 수 입력: "))

def count_prime_number(a, b):
    prime_number_list = []
    for number in range(a, b + 1):
        prime_or_not = 'O'
        for i in range(2, number):
            if number % i == 0:
                prime_or_not = 'X'
        if prime_or_not == 'O':
            prime_number_list.append(number)
    prime_number_list.remove(1)
    return str(len(prime_number_list))

num1_str = str(num1)
num2_str = str(num2)

print(num1_str + "과", num2_str, "사이의 소수의 개수는", count_prime_number(num1, num2) + "개 입니다.")