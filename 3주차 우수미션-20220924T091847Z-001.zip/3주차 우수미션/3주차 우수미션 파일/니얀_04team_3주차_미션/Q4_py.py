############################## 버전 1 #################################

# Q4.2개의 숫자를 입력하여 그 사이에 소수가 몇 개인지 출력하는 함수
# 소수: 1과 자기 자신만을 약수로 가지는 수

import math

# 함수 정의
def count_prime_number(n, m):

    # 첫번째 숫자가 더 큰게 들어왔을 경우
    if n > m:
        n, m = m, n # 서로 바꿔서 넣어줌
    # 2부터 소수를 구할 수 있기 때문에 2보다 작으면 2를 넣어 줌
    if n < 2:
        n = 2

    # 숫자 리스트 만듬
    prime_number = [i for i in range(n, m+1)]
    multiple = 0
    # 에라토스테네스의 체 알고리즘으로 구현
    # 사이에 있는 모든 자연수 중 m의 제곱근까지의 모든 수를 확인
    for i in range(2, int(math.sqrt(m)) + 1):
        
        multiple = 2
        # 그 사이의 정수 값의 배수가 되는 값을 배열에서 제거
        while i * multiple <= m:
            multiple_value = i * multiple
            if multiple_value in prime_number:
                prime_number.remove(multiple_value)
            multiple += 1

    return len(prime_number)
                
# 입력
while True:
    try:
        n = int(input("첫 번째 수 입력 : "))
        m = int(input("두 번째 수 입력 : "))
        break
    except ValueError:
        print("숫자가 아닌 값이 들어왔습니다.")

counter = count_prime_number(n, m)

# 출력
print("소수개수 : %d" % counter)


############################## 버전 2 #################################

def count_prime_number(n, m):
    prime_count = 0
    for i in range(n, m+1):
        prime = True
        for j in range(2, i):
            if i % j == 0:
                prime = False
                break
        if prime:
            prime_count += 1
    return prime_count


n = int(input("첫 번째 수 입력 : "))
m = int(input("두 번째 수 입력 : "))
count = count_prime_number(n, m)

# 출력
print(f'소수개수 {count}')


