def print_gugudan(number):
    multiples = [1, 3, 5, 7, 9]
    for mul in multiples:
        result = number * mul
        if result > 50:
            break
        print(f'{number} X {mul} = {result}')

while True:
    try:
        number = int(input("몇 단을 출력할까요? ex: 3: "))
        break
    except ValueError:
        print("숫자가 아닌 값을 입력하셨습니다.")
print_gugudan(number)
