def find_even_number(n, m):
    numbers = [i for i in range(n, m + 1)]

    center_index = len(numbers) // 2
    center_value = (numbers[center_index] + numbers[-center_index - 1]) / 2

    for num in numbers:
        if num & 1 == 0:
            print(f'{num} 짝수')
        if num == center_value:
            print(f'{num} 중앙값')

while True:
    try:
        n = int(input("범위의 시작 숫자를 입력해 주세요 : "))
        m = int(input("범위의 끝 숫자를 입력해 주세요 : "))
        break
    except ValueError:
        print("숫자가 아닌 값을 입력하셨습니다. 다시 입력해 주세요.")

find_even_number(n, m)
