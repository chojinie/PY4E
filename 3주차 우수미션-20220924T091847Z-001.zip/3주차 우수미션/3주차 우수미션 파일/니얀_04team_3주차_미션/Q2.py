# Q2. 가위바위보 업그레이드 버젼
# 조건 1: 게임을 몇 판을 진행할 것인지 입력을 받아주기
# 조건 2: 0, 1, 2, "가위", "바위", "보" 이외에 다른 입력을 받으면 재입력 받기
# 조건 3: 게임종료 후 나와 컴퓨터의 총 전적 출력하기
import random

def rsp_advanced(games):

    my_win, my_lose, my_tie, computer_win, computer_lose, computer_tie = 0, 0, 0, 0, 0, 0

    for rsp_games in range(0, games):
  
        # 입력값 받기
        while True:
            my = input("가위(0), 바위(1), 보(2) 중 하나를 내주세요.  :  ")
            if not (my =="0" or my == "1" or my == "2" or my == "가위" or my == "바위" or my == "보"):
                print("잘못된 입력 값입니다. 다시 입력해주세요.")
            else:
                if my == '가위':
                    my = 0 
                elif my == '바위':
                    my = 1      
                elif my == '보':
                    my = 2
                    my = int(my)
                
                break
        # 컴퓨터는 랜덤 값
        my = int(my)    
        computer = random.randint(0, 2) 

# my가 0(가위)이면 컴퓨터가 2(보)일 때 이기고, 1(바위)일 때 짐
# my가 1(바위)이면 컴퓨터가 0(가위)일 때 이기고, 2(보)일 때 짐
# my가 2(보)이면 컴퓨터가 1(바위)일 때 이기고, 0(가위)일 때 짐
# 무승부 => (0,0)/(1,1)/(2,2)
# 승리   => (0,2)/(1,0)/(2,1)
# 패배   => (0.1)/(1,2)/(2,0)
        rsp = [my, computer]
        win_or_lose = 0
        if my == computer: # 무승부
            my_tie += 1
            computer_tie += 1
            win_or_lose = 2
        elif rsp == [0, 2] or rsp == [1, 0] or rsp == [2, 1]: # 승리
            my_win += 1
            computer_lose += 1   
            win_or_lose = 0      
        elif rsp == [0, 1] or rsp == [1, 2] or rsp == [2, 0]: # 패배
            my_lose += 1
            computer_win += 1
            win_or_lose = 1           

        rsp_str = {0: "가위", 1: "바위", 2: "보"}
        win_or_lose_str = {0: "승리", 1: "패배", 2: "무승부"}
        
        sequence = rsp_games  + 1

        print("%d 판" % sequence)
        print("나 : %s" % rsp_str.get(my))
        print("컴퓨터 : %s" % rsp_str.get(computer))
        print("%d판 나의 %s" %(sequence, win_or_lose_str.get(win_or_lose)))

        if sequence == games:
            print("나의 전적: %d승 %d무 %d패" %(my_win, my_tie, my_lose))
            print("컴퓨터의 전적: %d승 %d무 %d패" %(computer_win, computer_tie, computer_lose))

while True:
    try:
        games = int(input("몇 판을 진행하시겠습니까? ex)4  : "))
        break
    except ValueError:
        print("숫자가 아닌 값이 들어왔습니다.")

rsp_advanced(games)
