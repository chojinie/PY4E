# 3주차 Q4 - lovesom2
#Q4. 2개의 숫자를 입력하여 그 사이에 소수가 몇 개인지 출력하는 함수를 만들어 봅시다.
#소수: 1과 자기 자신만을 약수로 가지는 수

def count_prime_number(n, m) :
    prime_number = count = 0
    prime_list = []
    for k in range (n, m+1):
        for i in range(1, k+1):
            if k % i == 0 :
                count += 1
        if count == 2 :
            prime_number += 1
            prime_list.append(k)
            count = 0
        else : 
            count = 0
    print("소수개수", prime_number)
    print("소수", prime_list)

n = int(input("첫 번째 수 입력 : "))
m = int(input("두 번째 수 입력 : "))
count_prime_number(n, m)