# 부스트코스, 모두를 위한 파이썬 <PY4E 2022>
# 3주차 미션 목적 - 반복문, 조건문 함수 익히기
# Q2. 가위바위보 업그레이드
# boka코치 4팀, 부스터 - 데이다과학자

import random

def rps_advanced(games):
    win = 0
    draw = 0
    lose = 0
    rpstonum = {'바위':0, '보':1, '가위':2}
    numtorps = {'0':'바위', '1':'보', '2':'가위'}
    for i in range(games):
        com_rps = random.choice(['바위', '보', '가위'])
        com_num = rpstonum[com_rps]

        while True:
            my = input("바위(0)? 보(1)? 가위(2)?: ")
            if my not in ['0', '1', '2', '바위', '보', '가위']:
                print("다시 입력해주세요.")
                continue
            break
            
        if my in ['바위', '보', '가위']:
            my_num = rpstonum[my]
            my_rps = my

        elif my in ['0', '1', '2']:
            my_num = int(my)
            my_rps = numtorps[my]

        print(f'나: {my_rps}')
        print(f'컴퓨터: {com_rps}')

        if (my_num - com_num) in [-2, 1]:
            win += 1
            print(f'{i+1} 번째 판 나의 승리!')
        elif (my_num - com_num) in [0]:
            draw += 1
            print(f'{i+1} 번째 판 무승부!')
        elif (my_num - com_num) in [2, -1]:
            lose += 1
            print(f'{i+1} 번째 판 나의 패배!')

    print(f'나의 전적: {win}승 {draw}무 {lose}패')
    print(f'컴퓨터의 전적: {lose}승 {draw}무 {win}패')

games = int(input("몇 판을 진행하시겠습니까? : "))
rps_advanced(games)