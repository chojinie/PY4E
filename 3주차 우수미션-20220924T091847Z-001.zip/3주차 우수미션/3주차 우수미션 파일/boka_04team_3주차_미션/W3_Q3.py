# 부스트코스, 모두를 위한 파이썬 <PY4E 2022>
# 3주차 미션 목적 - 반복문, 조건문 함수 익히기
# Q3. 짝수 찾기
# boka코치 4팀, 부스터 - 데이다과학자

import statistics

def find_even_number(n, m):
    if m >= n:
        numbers = [i for i in range(n, m + 1) if i % 2 == 0]
    else:
        numbers = [i for i in range(m, n + 1) if i % 2 == 0]
    
    for number in numbers:
        print(f'{number} 짝수')
        if number == statistics.median(numbers):
            print(f'{number} 중앙값')

n = int(input("첫 번째 수 입력 : "))
m = int(input("두 번째 수 입력 : "))
find_even_number(n, m)