# 3주차 Q1 - lovesom2
#Q1. 숫자를 입력 받고 그 숫자의 구구단을 출력하는 함수를 만들어 봅시다. 다만 아래의 조건을 만족해 주세요.
#조건 1: 홀 수 번째만 출력하기
#조건 2: 값이 50이하인 것만 출력하기

def gugudan(num) :
    print(num,"단")
    for k in range (1,10,2) :
        if num * k <= 50 :
            print(num, "X", k, "=", num * k)

number = int(input("몇 단? : "))
gugudan(number)
