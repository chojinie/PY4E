#Q1. 숫자를 입력 받고 그 숫자의 구구단을 출력하는 함수를 만들어 봅시다.
#조건 1: 홀수 번째만 출력하기
#조건 2: 값이 50이하인 것만 출력하기

def gugudan(number) :
    if number < 2 or number > 9 :
        return print("숫자 2~9 사이의 값을 입력하세요.")
    num = 1
    while number * num < 50 :
        result = number * num
        print(number, "X", num, "=", result)
        num = num + 2
        if num > 10 :
            break

number = input("몇 단? : ")
print(number, "단")
try:
    number = int(number)
    gugudan(number)
except:
    print("숫자 2~9 사이의 값을 입력하세요.")
