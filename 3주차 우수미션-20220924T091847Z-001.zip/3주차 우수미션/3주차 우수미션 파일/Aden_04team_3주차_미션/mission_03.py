n = int(input("첫 수"))
m = int(input("끝 수"))

def find_even_number(n,m):
    numbers = [ i for i in range(n,m+1)]
    cnt = 1
    for i in numbers:
        if cnt == len(numbers) / 2 + 1 :
            print(i)

        if i % 2 == 0:
            print(i)

        cnt += 1


find_even_number(n,m)
