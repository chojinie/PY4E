# 함수 정의
def count_prime_number(n, m):
    cnt = 0  # 개수 초기화
    is_prime = True  # 판단하고자 하는 숫자에 대한 참 거짓
    for i in range(n, m+1):  # 입력받은 숫자사이의 소수 판단
        for j in range(2, i):  # 범위 내의 숫자가 소수인지 아닌지 판단
            is_prime = True  # 초기화
            if i % j != 0:  # 나머지가 존재하면 건너뛰기
                continue
            else:
                is_prime = False  # 거짓
                break  # 이중 for문 중 안쪽 반복문만 break
        if is_prime:
            cnt += 1   # 안쪽 반복문이 끝나면 True 면 카운트
    print("소수개수", cnt)


# 변수입력
n, m = map(int, input().split())

# 함수 호출
count_prime_number(n, m)
