import random

# 가위 바위 보 , 0, 1, 2

def hangul(input):
    if input == 0:
        return "가위"
    elif input == 1:
        return "바위"
    elif input == 2:
        return "보"


def rsp_advanced(games):
    games_cnt = 0
    wins_value = 0
    defeat_value = 0
    tie_value = 0
    while games > games_cnt:

        stack = input("가위(0) 바위(1) 보(2) : ")
        if (stack == '가위'):
            stack = 0
        elif (stack == '바위'):
            stack = 1
        elif (stack == '보'):
            stack = 2
        elif stack.isdigit() and 3 > int(stack) >= 0:
            pass
        else:
            print("입력 값을 정확하게 입력하세요")
            return 0

        computer = random.randint(0,2)
        print("나:{0}".format(hangul(int(stack))))
        print("컴퓨터:{0}".format(hangul(computer)))

        stack_int = int(stack)
        games_cnt = games_cnt + 1

        if stack_int == computer:
            print("{0}번째 판 비겼습니다".format(games_cnt))
            tie_value = tie_value + 1
        elif (stack_int == 0 and computer == 2) or \
            (stack_int == 1 and computer == 0) or \
            (stack_int == 2 and computer == 1):
            print("{0}번째 판 나의 승리!!".format(games_cnt))
            wins_value = wins_value + 1
        else:
            print("{0}번째 판 컴퓨터의 승리!!".format(games_cnt))
            defeat_value = defeat_value + 1
# 나의 전적: 2승 0무 0패
# 컴퓨터의 전적: 0승 0무 2패
    print("나의 전적: {0}승 {1}무 {2}패".format(wins_value, tie_value, defeat_value))
    print("컴퓨터의 전적: {0}승 {1}무 {2}패".format(defeat_value, tie_value, wins_value))


try:
    games = int(input("몇 판을 진행하시겠습니까? : "))
    rsp_advanced(games)

except:
    print("숫자를 입력하세요")


