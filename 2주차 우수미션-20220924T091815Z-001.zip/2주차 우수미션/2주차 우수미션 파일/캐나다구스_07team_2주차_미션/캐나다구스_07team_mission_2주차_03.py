def grader(name,score):
    grade = ''
    if score<60:
        grade = 'F'
    elif score<65:
        grade = 'D'
    elif score<70:
        grade = 'D+'
    elif score<75:
        grade = 'C'
    elif score<80:
        grade = 'C+'
    elif score<85:
        grade = 'B'
    elif score<90:
        grade = 'B+'
    elif score<95:
        grade = 'A'
    else:
        grade = 'A+'
        
    return grade

while True:
    
        name = input('학생 이름 입력: ')
        
        while True:
            try:
                score = input('점수 입력 : ')
                score = int(score)
                grade = grader(name,score)
                print('------------------------------------------------------')
                print('학생 이름 : '+ name)
                print('점수 : '+ str(score))
                print('학점 : '+ grade)
                print('------------------------------------------------------')
                break
            except:
                print('점수는 정수를 숫자로 입력해주세요.')
