import random

def numchange (num):
    if num == 1:
        kor = '가위'
    elif num == 2:
        kor = '바위'
    else:
        kor = '보'

    return kor

def rcp (user) :

    
    computer = numchange(random.randint(1,3))       
    print('컴퓨터의 선택: ' + computer)
    if user == '가위':
        if computer == '보':
            result = 'win'
        elif computer == '바위':
            result = 'lose'
        else:
            result = 'draw'
    elif user == '바위':
        if computer == '가위':
            result = 'win'
        elif computer == '보':
            result = 'lose'
        else:
            result = 'draw'
    else:
        if computer == '바위':
            result = 'win'
        elif computer == '가위':
            result = 'lose'
        else:
            result = 'draw'

    return result
                
     
while True:
    my = input('숫자(1=가위, 2= 바위, 3=보)나 가위바위보를 입력하세요: ')
    rcpval = ['가위','바위','보']
    rcpint = [1,2,3]
   
    if my not in rcpval and int(my) not in rcpint:
        print('잘못 입력하셨습니다.')
        continue
    
    else:
        if type(my) == int:
            my = numchange(my)
        print('-----------------------------------------')
        print('나의 선택:'+ my)
        result = rcp(my)
        print('결과 : ' + result)
        print('-----------------------------------------')
