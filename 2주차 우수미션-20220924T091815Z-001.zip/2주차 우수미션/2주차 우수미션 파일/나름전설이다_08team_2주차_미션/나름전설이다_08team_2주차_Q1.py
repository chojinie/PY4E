import random

com = random.randint(0,2)
if com == 0:
    com_letter = "가위"
elif com == 1:
    com_letter = "바위"
else:
    com_letter = "보"

def rcp(my):
    try:
        my_num = int(my)
    except:
        if my == '가위':
            my_num = 0
        elif my == '바위':
            my_num = 1
        elif my == '보':
            my_num = 2
        else:
            print("잘못된 값을 입력 하셨습니다.")
    result = com - my_num

    if result == 0:
        return '비김'
    elif result == 1 or result == -2:
        return '패'
    elif result == -1 or result == 2:
        return '승'

my = input("가위 바위 보 : ")

if my == '0':
    my_letter = '가위'
elif my == '1':
    my_letter = '바위'
elif my == '2':
    my_letter = '보'

print("나:", my_letter)
print("컴퓨터:", com_letter)
print("결과:", rcp(my))