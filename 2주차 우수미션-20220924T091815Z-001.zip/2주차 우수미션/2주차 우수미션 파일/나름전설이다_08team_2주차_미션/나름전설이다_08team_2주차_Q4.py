def bus_fare(age, payment):

    #예외처리
    try:
        int(age)
        str(payment)
    except:
        print("잘못된 입력!")
        return

    #계산을 위한 형변환
    age = int(age)

    #예외처리2
    if age < 0:
        print("0 이상의 나이 입력!")
        return

    #비용계산
    if payment == "카드":
        if age < 8 or age >= 75:
            fare = 0

        elif age >= 8 and age < 14:
            fare = 450

        elif age >= 14 and age < 20:
            fare = 720

        elif age >= 20 and age < 75:
            fare = 1200
        
    elif payment == "현금":
        if age < 8 or age >= 75:
            fare = 0

        elif age >= 8 and age < 14:
            fare = 450

        elif age >= 14 and age < 20:
            fare = 1000

        elif age >= 20 and age < 75:
            fare = 1300
    
    #예외처리3
    else:
        print("지불유형은 카드와 현금!")
        return

    #출력
    print("나이 :", age, "세")
    print("지불유형 :", payment)
    print("버스요금 :", fare, "원")

        
#입력
age, payment = input("나이와 지불유형(카드, 현금)을 입력 (ex) 30,현금) : ").split(',')
payment = payment.replace(" ", "")
bus_fare(age, payment)