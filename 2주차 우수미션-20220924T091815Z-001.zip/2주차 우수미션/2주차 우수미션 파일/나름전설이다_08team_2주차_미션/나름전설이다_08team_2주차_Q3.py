def grader(name,score):
    if score<=100 and score>94:
        mark='A+'
    elif score>89:
        mark='A'
    elif score>84:
        mark='B+'
    elif score>79:
        mark='B'
    elif score>74:
        mark='C+'
    elif score>69:
        mark='C'
    elif score>64:
        mark='D+'
    elif score>59:
        mark='D'
    else:
        mark='F'
    print('학생이름:',name)
    print('점수:',score,'점')
    print('학점:',mark)

name=input('이름: ')
score=int(input('점수: '))
grader(name,score   )
