# 카드와 현금으로 먼저 조건을 나누고, 그 이후 나이 조건을 적용시킨 함수
def bus_fare(age, pay):
    if pay == "카드":
        if age < 8 or age >= 75:
            fee = "무료"
            detail_print(age, pay, fee)
        elif 8 <= age < 14:
            fee = "450원"
            detail_print(age, pay, fee)
        elif 14 <= age < 20:
            fee = "720원"
            detail_print(age, pay, fee)
        elif age >= 20:
            fee = "1200원"
            detail_print(age, pay, fee)
    else:
        if age < 8 or age >= 75:
            fee = "무료"
            detail_print(age, pay, fee)
        elif 8 <= age < 14:
            fee = "450원"
            detail_print(age, pay, fee)
        elif 14 <= age < 20:
            fee = "1000원"
            detail_print(age, pay, fee)
        elif age >= 20:
            fee = "1300원"
            detail_print(age, pay, fee)

# 출력하는 부분이 공통적으로 사용되기에, 출력하는 함수를 따로 만들어 사용
def detail_print(age, pay, fee):
    print("\n나이 : " + str(age) + "세")
    print("지불유형 :", pay)
    print("버스요금 :", fee)


customage = int(input("나이를 입력하세요: "))
payment = input("지불방법을 선택하세요(카드/현금): ")

bus_fare(customage, payment)