# 학생이름과 점수 입력
name = input("학생 이름을 입력하세요: ")
score = int(input('점수: '))

# 학점 계산 함수
def grader(s):
    if s <60:
        return 'F'
    elif s < 65:
        return 'D'
    elif s < 70:
        return 'D+'
    elif s < 75:
        return 'C'
    elif s < 80:
        return 'C+'
    elif s < 85:
        return 'B'
    elif s < 90:
        return 'B+'
    elif s < 95:
        return 'A'
    elif s <= 100:
        return 'A+'
    else:
        print('올바른 점수를 입력해주세요')
        return '학점오류'


print("\n학생 이름 :", name)
print("점수 : " + str(score) + "점")
print("학점 :", grader(score))