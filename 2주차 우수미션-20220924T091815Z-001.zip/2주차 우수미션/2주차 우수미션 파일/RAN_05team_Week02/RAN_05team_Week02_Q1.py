import random

# 가위바위보 문자를 입력받았을 경우 숫자로 변환
def rsp_toint(a):
    try:
        a = int(a)
        if a == 0 or a == 1 or a == 2:
            return a
        print("숫자로 입력 시 0(가위), 1(바위), 2(보)로 입력해주세요.")
        return -1
    except ValueError:
        if a == '가위':
            return 0
        elif a == '바위':
            return 1
        elif a == '보':
            return 2
        else:
            print('문자로 입력시 가위, 바위, 보 로 입력해주세요.')
            return -1


# 가위바위보 숫자를 문자로 변환
def rsp_tostr(a):
    if a == 0:
        return '가위'
    elif a == 1:
        return '바위'
    else:
        return '보'


# 승자를 정하는 함수
def winner(my, com):
    if com - my == -2 or com - my == 1:
        print('컴퓨터 승리!')
    elif com - my == -1 or com - my == 2:
        print('나 승리!')
    elif com - my == 0:
        print('무승부!')
    else:
        print('에러')


# 사용자가 낼 것을 입력받음
mynum = -1
while mynum == -1:
    myrsp = input("가위(0) 바위(1) 보(2)")
    mynum = rsp_toint(myrsp)

# 컴퓨터가 낼 것을 0~2 숫자 중 랜덤으로 저장
comnum = random.randint(0, 2)

# 나와 컴퓨터가 낸 것을 출력할 때는 문자(가위, 바위, 보)로 출력
print("나 :", rsp_tostr(mynum))
print("컴퓨터 :", rsp_tostr(comnum))

# 승자를 계산할 때는 숫자를 넘겨준 함수를 이용
winner(mynum ,comnum)
