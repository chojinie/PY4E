# 월급을 입력하면 세후 연봉을 계산해주는 함수
def yearly_payment(monthly_payment):
    if monthly_payment * 12 <= 1200 :
        return monthly_payment * 12 * (100 - 6) / 100
    elif monthly_payment * 12 <= 4600 :
        return monthly_payment * 12 * (100 - 15) / 100
    elif monthly_payment * 12 <= 8800 :
        return monthly_payment * 12 * (100 - 24) / 100
    elif monthly_payment * 12 <= 15000 :
        return monthly_payment * 12 * (100 -35) / 100
    elif monthly_payment * 12 <= 30000 :
        return monthly_payment * 12 * (100 - 38) / 100
    elif monthly_payment * 12 <= 50000 :
        return monthly_payment * 12 * (100 - 40) / 100
    else :
        return monthly_payment * 12 * (100 - 42) / 100


monthly = int(input('월급을 입력하세요(만 단위): '))
print('세전 연봉: ' + str(monthly*12) + '만원')
print('세후 연봉: ' + str(int(yearly_payment(monthly))) + '만원')