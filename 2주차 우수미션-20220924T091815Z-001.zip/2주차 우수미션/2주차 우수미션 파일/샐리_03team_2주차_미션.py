# Q1

# "가위,바위,보"를 출력하기 위한 함수

def RSP(num):
	if num == 0:
		return "가위"	

	if num == 1:
		return "바위"	

	if num == 2:
		return "보"	


def rcp(my):
	try:
		import random as rd
		com = rd.randint(0,2)	# 컴퓨터 가위바위보 선택

		# 내 가위바위보 입력을 숫자로 변환
		if my == 0 or my == "가위":
			my = 0	
		elif my == 1 or my == "바위":
			my = 1		
		elif my == 2 or my == "보":
			my = 2
		else:			# 적절하지 않은 함수 인자 입력시 
			raise Exception("가위바위보 선택을 제대로 입력해 주세요")	
	
		par = my - com		# 가위바위보 승자를 나누기 위한 임의의 변수 par 설정		

		#누가 승리했는지 출력
		if par == 0:			#비기는 경우의 수
			res = "비김!"

		elif par == 1 or par == -2:	#내가 이기는 경우의 수
			res = "나 승리!"
		else:
			res = "컴퓨터 승리!"
	
		print("나: ", RSP(my))
		print("컴퓨터: ", RSP(com))
		print(res)

	except Exception as e:		#사용사 설정 예외처리
		print(e)


# Q2

def yearly_payment(pay):

	try:

		pay = int(pay)		#함수 인자 확인
		pay = pay * 12		#연봉을 저장

		if pay <= 1200:
			rate = 0.06
		elif pay <= 4600:
			rate = 0.15
		elif pay <= 8800:
			rate = 0.24
		elif pay <= 15000:
			rate = 0.35
		elif pay <= 30000:
			rate = 0.38
		elif pay <= 50000:
			rate = 0.40
		else:
			rate = 0.42

		bef = pay 		#세전연봉
		af = bef - bef * rate	#세후연봉

		print("세전 연봉: ", bef, "만원")
		print("세후 연봉: ", af, "만원")

	except ValueError:		#적절하지 않은 함수 인자
		print("정수형 숫자를 입력해주세요")

#pay = input("월급? ")
#yearly_payment(pay)	

		
#Q3

def grader(name, score):

	try:
		score = int(score)		# 적절한 점수 입력 여부 확인		

		if score > 100 or score < 0:
			raise Exception("0과 100사이의 정수형을 입력해주세요")
		
		elif score >= 95:
			grade = "A+"
		elif score >= 90:
			grade = "A"
		elif score >= 85:
			grade = "B+"
		elif score >= 80:
			grade = "B"
		elif score >= 75:
			grade = "C+"
		elif score >= 70:
			grade = "C"
		elif score >= 65:
			grade = "D+"
		elif score >= 60:
			grade = "D"
		else:
			grade = "F"

		print("학생이름: ", name)
		print("점수: ", score, "점")
		print("학점: ", grade)

	except ValueError:			# 점수 잘못 입력 시
		print("점수는 정수형으로 입력해주세요")
	except Exception as e:			# 사용자 설정 예외처리
		print(e)

#name = input("이름? ")
#score = input("점수? ")
#grader(name, score)


#Q4

def bus_fare(age, pay):

	try:
		age = int(age)		# 적절한 나이 입력인지 확인	
		if age < 0:
			raise Exception("0 이상의 숫자를 입력해 주세요")	

		if pay == "카드":
			if age < 8:
				fee = 0
			elif age < 14:
				fee = 450
			elif age < 20:
				fee = 720
			elif age < 75:
				fee = 1200
			else:
				fee = 0	

		elif pay == "현금":
	
			if age < 8:
                	        fee = 0
			elif age < 14:
                        	fee = 450
			elif age < 20:
                	        fee = 1000
			elif age < 75:
                	        fee = 1300
			else:
                        	fee = 0 
		else:			# 지불유형 잘못 입력시 
			raise Exception("지불유형을 카드와 현금 중 하나를 입력해 주세요")
	
		print("나이:", age, "세")
		print("지불유형:", pay)
		print("버스요금:", fee, "원")
	
	except ValueError:		# 나이 잘못 입력시
		print("나이를 숫자로 입력해 주세요")

	except Exception as e:		# 사용자 설정 예외처리
		print(e)
		
#age = input("나이? ")
#pay = input("지불유형? ")
#bus_fare(age, pay)

