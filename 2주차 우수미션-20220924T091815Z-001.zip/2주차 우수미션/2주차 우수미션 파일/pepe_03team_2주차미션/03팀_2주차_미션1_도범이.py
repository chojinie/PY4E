#시작메시지
print('''가위바위보 게임을 시작합니다.
다음 입력값을 입력하세요.
(가위 or 0 / 바위 or 1 / 보 or 2)
''')

#가위바위보 값 불러들이기
my = input("가위 바위 보: ")

#숫자(0 등)로 입력한 값을 문자(가위 등)로 변환
if my == str(0):
    my = '가위'
elif my == str(1):
    my = '바위'
elif my == str(2):
    my = '보'

#가위=0 바위=1 보=2 숫자값 반환
def rcp(my):
    if my == '가위':
        return 0
    elif my == '바위':
        return 1
    elif my == '보':
        return 2
    else:
        return -1

#컴퓨터 랜덤값 추출
import random
computer = random.randint(0, 2)

#랜덤으로 뽑힌 숫자를 문자로 변환
def c_rcp(computer):
    if computer == 0:
        return '가위'
    elif computer == 1:
        return '바위'
    else:
        return '보'

#내가 이겼을 경우 출력
def win():
    print("나:",my)
    print("컴퓨터:",c_rcp(computer))
    print("나의 승리!")

#컴퓨터가 이겼을 경우 출력
def lose():
    print("나:",my)
    print("컴퓨터:",c_rcp(computer))
    print("컴퓨터 승리!")

#잘못 입력한 경우 출력
if rcp(my) == -1:
    print("잘못 입력하였습니다.")

#비겼을 경우 출력
elif rcp(my) == computer:
    print("나:",my)
    print("컴퓨터:",c_rcp(computer))
    print("비겼습니다.")

#가위를 낸 경우 출력
elif rcp(my) == 0:
    if computer == 1:
        lose()
    else:
        win()

#바위를 낸 경우 출력
elif rcp(my) == 1:
    if computer == 2:
        lose()
    else:
        win()

#보를 낸 경우 출력
elif rcp(my) == 2:
    if computer == 0:
        lose()
    else:
        win()
