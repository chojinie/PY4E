#시작메시지
print('학점 변환기를 실행합니다.')

#이름 입력
name = input('이름을 입력하세요: ')

#점수 입력
score = input('점수를 입력하세요: ')
try:
    point = int(score)
except:
    point = -1

# 함수 정의
def grader(name, point):
    print('학생이름:', name)
    print('점수:', str(point)+'점')
    print('학점:', grade)

#학점 계산
if point < 0:
    print('점수를 잘못 입력하였습니다.')
elif point < 60:
    grade = 'F'
    grader(name, point)
elif point < 65:
    grade = 'D'
    grader(name, point)
elif point < 70:
    grade = 'D+'
    grader(name, point)
elif point < 75:
    grade = 'C'
    grader(name, point)
elif point < 80:
    grade = 'C+'
    grader(name, point)
elif point < 85:
    grade = 'B'
    grader(name, point)
elif point < 90:
    grade = 'B+'
    grader(name, point)
elif point < 95:
    grade = 'A'
    grader(name, point)
else:
    grade = 'A+'
    grader(name, point)
