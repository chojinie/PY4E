#!/usr/bin/env python
# coding: utf-8

# In[8]:


#Q3

#학점 변환 함수
def grader(score):
    grade = ''
    
    if (score >= 95) : grade = 'A+'
    elif (score >= 90) : grade = 'A'
    elif (score >= 85) : grade = 'B+'
    elif (score >= 80) : grade = 'B'
    elif (score >= 75) : grade = 'C+'
    elif (score >= 70) : grade = 'C'
    elif (score >= 65) : grade = 'D+'
    elif (score >= 60) : grade = 'D'
    else : grade = 'F'
    
    return grade

# 이름 입력
name = input('이름을 입력해주세요! → ')

# 점수 입력
while True:
    try:
        score = int(input('점수를 입력해주세요(0~100) → '))
    except:
        score = -1
    
    if 0 <= score <= 100 : break
        
    if not(0 <= score <= 100):
        print('0과 100사이의 숫자를 입력해주세요!')

# 학점
grade = grader(score)

# 결과 출력
print('--------------------------------------')
print('학생이름 :', name, '\n점수 :', score, '\n학점 :', grade)
#1


# In[ ]:




