#시작메시지
print('연봉 계산기를 실행합니다.')

#월급을 입력
monthly_payment = input('월급을 입력하세요: ')

#월급을 연봉으로 변환
def yearly_payment(monthly_payment):
    try:
        return int(monthly_payment) * 12
    except:
        return -1

#세율표에 따른 연봉 출력
if int(yearly_payment(monthly_payment)) < 0:
    print('잘못 입력하였습니다.')
elif int(yearly_payment(monthly_payment)) <= 1200:
    print('세전 연봉:',str(yearly_payment(monthly_payment))+'만원')
    print('세후 연봉:',str(int(yearly_payment(monthly_payment)*(1-0.06)))+'만원')
elif int(yearly_payment(monthly_payment)) <= 4600:
    print('세전 연봉:',str(yearly_payment(monthly_payment))+'만원')
    print('세후 연봉:',str(int(yearly_payment(monthly_payment)*(1-0.15)))+'만원')
elif int(yearly_payment(monthly_payment)) <= 8800:
    print('세전 연봉:',str(yearly_payment(monthly_payment))+'만원')
    print('세후 연봉:',str(int(yearly_payment(monthly_payment)*(1-0.24)))+'만원')
elif int(yearly_payment(monthly_payment)) <= 15000:
    print('세전 연봉:',str(yearly_payment(monthly_payment))+'만원')
    print('세후 연봉:',str(int(yearly_payment(monthly_payment)*(1-0.35)))+'만원')
elif int(yearly_payment(monthly_payment)) <= 30000:
    print('세전 연봉:',str(yearly_payment(monthly_payment))+'만원')
    print('세후 연봉:',str(int(yearly_payment(monthly_payment)*(1-0.38)))+'만원')
elif int(yearly_payment(monthly_payment)) <= 50000:
    print('세전 연봉:',str(yearly_payment(monthly_payment))+'만원')
    print('세후 연봉:',str(int(yearly_payment(monthly_payment)*(1-0.40)))+'만원')
else:
    print('세전 연봉:',str(yearly_payment(monthly_payment))+'만원')
    print('세후 연봉:',str(int(yearly_payment(monthly_payment)*(1-0.42)))+'만원')



