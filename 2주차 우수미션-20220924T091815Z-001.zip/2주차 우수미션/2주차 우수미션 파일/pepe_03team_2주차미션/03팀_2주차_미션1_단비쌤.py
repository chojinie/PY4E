import random
user=input('"가위, 바위, 보" 중에서 하나를 입력 하세요 : ')
if user=='가위':
    if random.choice(['가위','바위','보'])=='가위':
        print('나 : 가위')
        print('컴퓨터 : 가위')
        print('무승부~ 우리는 마음이 통했군요!')
    elif random.choice(['가위','바위','보'])=='바위':
        print('나 : 가위')
        print('컴퓨터 : 바위')
        print('컴퓨터가 이겼네요~ ㅠㅠ')
    else:
        print('나 : 가위')
        print('컴퓨터 : 보')
        print('내가 이겼어요~ ^^')
if user=='바위':
    if random.choice(['가위','바위','보'])=='가위':
        print('나 : 바위')
        print('컴퓨터 : 가위')
        print("내가 이겼어요~ ^^")
    elif random.choice(['가위','바위','보'])=='바위':
        print('나 : 바위')
        print('컴퓨터 : 바위')
        print('무승부~ 우리는 마음이 통했군요!')
    else:
        print('나 : 바위')
        print('컴퓨터 : 보')
        print('컴퓨터가 이겼네요~ ㅠㅠ')
if user=='보':
    if random.choice(['가위','바위','보'])=='가위':
        print('나 : 보')
        print('컴퓨터 : 가위')
        print('컴퓨터가 이겼네요~ ㅠㅠ')
    elif random.choice(['가위','바위','보'])=='바위':
        print('나 : 보')
        print('컴퓨터 : 바위')
        print('내가 이겼어요~ ^^')
    else:
        print('나 : 보')
        print('컴퓨터 : 보')
        print('무승부~ 우리는 마음이 통했군요!')
