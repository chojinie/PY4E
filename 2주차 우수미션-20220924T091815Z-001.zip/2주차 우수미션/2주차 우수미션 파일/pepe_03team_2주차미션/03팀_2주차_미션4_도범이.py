#시작메시지
print('버스 요금 계산기를 실행합니다.')

#나이 입력
str_age = input('나이를 입력하세요: ')
try:
    age = int(str_age)
except:
    age = -1

#지불유형 입력
payment = input('''지불유형에는 '카드'와 '현금'이 있습니다.
지불유형을 입력하세요: ''')

#함수 정의
def bus_fare(age, payment):
    print('나이:',str(age)+'세')
    print('지불유형:',payment)
    print('버스요금:',fare)

#버스 요금 계산
if age < 0:
    print('나이를 잘못 입력하였습니다.')
elif age < 8:
    if payment == '카드' or payment == '현금':
        fare = '무료'
        bus_fare(age, payment)
    else:
        print('지불유형을 잘못 입력하였습니다.')
elif age < 14:
    if payment == '카드' or payment == '현금':
        fare = '450원'
        bus_fare(age, payment)
    else:
        print('지불유형을 잘못 입력하였습니다.')
elif age < 20:
    if payment == '카드':
        fare = '720원'
        bus_fare(age, payment)
    elif payment == '현금':
        fare = '1000원'
        bus_fare(age, payment)
    else:
        print('지불유형을 잘못 입력하였습니다.')
elif age < 75:
    if payment == '카드':
        fare = '1200원'
        bus_fare(age, payment)
    elif payment == '현금':
        fare = '1300원'
        bus_fare(age, payment)
    else:
        print('지불유형을 잘못 입력하였습니다.')
else:
    if payment == '카드' or payment == '현금':
        fare = '무료'
        bus_fare(age, payment)
    else:
        print('지불유형을 잘못 입력하였습니다.')


