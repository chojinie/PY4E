# 📌Q1. 컴퓨터와 함께하는 가위바위보 게임을 만들어봅시다!

# 조건1 : 함수의 인자로는 나의 가위바위보 선택이 들어감
#           (0, 1 ,2 혹은 "가위", "바위", "보" 로 입력할 수 있습니다. - 총 6가지 방법으로 넣을 수 있음)

# 조건2 : 누가 무엇을 냈고, 누가 승리 했는지 출력이 되어야 함

import random as rd

while True:
    choice = input("가위, 바위, 보, 혹은 0(가위), 1(바위), 2(보)를 입력해주세요 : ")
    my_choice = ""
    if choice == "가위" or choice == "0":
        my_choice = 0
        break
    elif choice == "바위" or choice == "1":
        my_choice = 1
        break
    elif choice == "보" or choice == "2":
        my_choice = 2
        break
    else:
        print("잘못된 값을 입력했습니다.")
    
choice_list = ["가위", "바위", "보"]
computer_choice = rd.randint(0, 2)
    
if my_choice - computer_choice == 0:
    print("나의 선택: {}".format(choice_list[my_choice]))
    print("컴퓨터의 선택: {}".format(choice_list[computer_choice]))
    print("무승부!")
elif my_choice - computer_choice == 1 or my_choice - computer_choice == -2:
    print("나의 선택: {}".format(choice_list[my_choice]))
    print("컴퓨터의 선택: {}".format(choice_list[computer_choice]))
    print("나의 승리!")
elif my_choice - computer_choice == -1 or my_choice - computer_choice == 2:
    print("나의 선택: {}".format(choice_list[my_choice]))
    print("컴퓨터의 선택: {}".format(choice_list[computer_choice]))
    print("컴퓨터의 승리!")