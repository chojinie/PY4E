#!/usr/bin/env python
# coding: utf-8

# In[8]:


#Q1 

import random

# '가위, 바위, 보'를 '0, 1, 2'로 변환
def rsp(select_rsp) :
    if select_rsp == '가위':
        return 0
    elif select_rsp == '바위':
        return 1
    else:
        return 2
    
# 가위바위보 결과 출력
def result(res):
    if res == 0:
        print('무승부!')
    elif res == 1:
        print('나의 승리!')
    else:
        print('컴퓨터 승리!')
        
# 컴퓨터의 선택
computer = random.randint(0,2)
sel = ['가위', '바위', '보']

# 사용자의 선택
while True:    
    my = input('가위, 바위, 보 중 하나를 선택해주세요! \n→ ') 
    if my in sel: 
        break 
        
# 입력 받은 가위바위보를 정수로 변환
myInt = rsp(my)


# 결과 출력
print('--------------------------------------')
print('나:', my, '\n컴퓨터:', sel[computer])
result((myInt - computer) % 3)


# In[ ]:




