#!/usr/bin/env python
# coding: utf-8

# In[8]:


#Q4

# 버스 요금 계산 함수
def bus_fare(age, type) :
    if age < 8 or age >= 75:
        cost = '무료'
    else:
        if age >= 8 and age < 14:
            cost = '450원'
        elif age >= 14 and age < 20 and type == '카드':
            cost = '720원'
        elif age >= 14 and age < 20 and type == '현금':
            cost = '1000원'
        elif age >= 20 and type == '카드':
            cost = '1200원'
        elif age >= 20 and type == '현금':
            cost = '1300원'
             
    return cost

# 나이, 지불 유형 입력
while True:
    try:
        age = int(input('나이를 입력해주세요 : '))
    except:
        print('\n정수로 나이를 입력해주세요')
        age = -1
        
    if age>0:
        break

while True:
    pay_type = input('버스 요금 지불 방식 (카드/현금) : ')
    
    if pay_type == '현금' or pay_type == '카드' :
        break

cost = bus_fare(age, pay_type)

print('--------------------------------------')
print('나이 :', age,'세', '\n지불유형 :', pay_type, '\n버스요금 :', cost)


# In[ ]:




