# 📌Q3. 학생 이름과 점수를 입력하면 학점을 출력하는 학점 변환기를 만들어 봅시다.

# 이름과 점수, 학점 모두 출력하도록 해봅니다.

name = input("학생의 이름을 입력하세요 : ")
while True:
    score = input("점수를 입력하세요 : ")
    try:
        score = int(score)
        if score > 100 or score < 0:
            print("오류: 0 이상, 100 이하의 정수를 입력해주세요.")
        else:
            break
    except:
        print("오류: 0 이상, 100 이하의 정수를 입력해주세요")
score_list = ["A+", "A", "B+", "B", "C+", "C", "D+", "D", "F"]

if score >= 95:
    score_index = 0
elif score >= 90:
    score_index = 1
elif score >= 85:
    score_index = 2
elif score >= 80:
    score_index = 3
elif score >= 75:
    score_index = 4
elif score >= 70:
    score_index = 5
elif score >= 65:
    score_index = 6
elif score >= 60:
    score_index = 7
else:
    score_index = 8

print("학생 이름: {}".format(name))
print("점수: {}점".format(score))
print("학점: {}".format(score_list[score_index]))