# 📌Q2. 월급을 입력하면 연봉을 계산해주는 계산기를 만들어 봅시다. 세전 연봉과 세후 연봉을 함께 출력하도록 해봅니다.

tax_rate_list = [0.06, 0.15, 0.24, 0.35, 0.38, 0.4, 0.42]
monthly_pay = int(input("월급을 입력해주세요 (단위: 만원) : "))
yearly_pay = monthly_pay * 12

if yearly_pay <= 1200:
    section = 0
elif yearly_pay <= 4600:
    section = 1
elif yearly_pay <= 8800:
    section = 2
elif yearly_pay <= 15000:
    section = 3
elif yearly_pay <= 30000:
    section = 4
elif yearly_pay <= 50000:
    section = 5
else:
    section = 6

taxed_yearly_pay = int(yearly_pay * (1-tax_rate_list[section]))

print("세전 연봉: {0:,}만원".format(yearly_pay))
print("세후 연봉: {0:,}만원".format(taxed_yearly_pay))