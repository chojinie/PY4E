#!/usr/bin/env python
# coding: utf-8

# In[8]:


#Q2

# 연봉 계산 함수
def yearly_payment(monthly_payment):
    yearly_payment = 12 * monthly_payment
    
    if yearly_payment == 1200:
        tax_rate = 6
    elif yearly_payment <= 4600:
        tax_rate = 15
    elif yearly_payment <= 8800:
        tax_rate = 24
    elif yearly_payment <= 15000:
        tax_rate = 35
    elif yearly_payment <= 30000:
        tax_rate = 38
    elif yearly_payment <= 50000:
        tax_rate = 40
    else:
        tax_rate = 42
        
    return int(yearly_payment * (100 - tax_rate) / 100)


# 세전/세후 연봉 출력
while True:
    try:
        monthly_payment = int(input('월급 입력[단위:만원] : '))

        if monthly_payment >= 0:
            print('세전 연봉:', monthly_payment*12, '만원 \n세후 연봉:', yearly_payment(monthly_payment), '만원')
        else:
            monthly_payment = -1
    except:
        monthy_payment = -1
        print('월급 입력[단위:만원] : ')
    
    if monthly_payment >= 0:
              break


# In[ ]:




