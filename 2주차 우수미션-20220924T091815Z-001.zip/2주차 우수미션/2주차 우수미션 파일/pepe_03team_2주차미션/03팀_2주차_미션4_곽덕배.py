# 📌Q4. 나이와 현금 또는 카드를 입력하면 버스 요금이 출력되는 버스 요금 계산기를 만들어봅시다. 

while True:
    age = int(input("나이를 입력하세요 : "))
    if age < 0:
        print("0세 이상의 나이를 입력하세요.")
    else:
        break

while True:
    pay_method = input("결제 수단을 입력하세요 : ")
    if pay_method not in ["현금", "카드"]:
        print("현금, 또는 카드만 입력 가능합니다.")
    else:
        break

card_price_list = ["무료", "450원", "720원", "1,200원"]
cash_price_list = ["무료", "450원", "1,000원", "1,300원"]

if age < 8 or age >= 75:
    age_index = 0
elif age < 14:
    age_index = 1
elif age < 20:
    age_index = 2
elif age < 75:
    age_index = 3

if pay_method == "카드":
    charge = card_price_list[age_index]
elif pay_method == "현금":
    charge = cash_price_list[age_index]

print("나이: {}세".format(age))
print("지불유형: {}".format(pay_method))
print("버스요금: {}".format(charge))