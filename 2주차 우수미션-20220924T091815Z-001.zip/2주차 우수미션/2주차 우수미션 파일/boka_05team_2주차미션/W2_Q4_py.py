######## 풀이타입 A #########
def bus_fare(age, payType):
    if age < 8:
        price = 0
    elif age < 14:
        price = 450
    elif age < 20:
        if payType == '카드':
            price = 720
        elif payType == '현금':
            price = 1000
        else:
            print("지불유형을 '카드' 혹은 '현금'으로 입력했는지 확인해주세요")
    elif age < 75:
        if payType == '카드':
            price = 1200
        elif payType == '현금':
            price = 1300
        else:
            print("지불 유형을 '카드' 혹은 '현금'으로 입력했는지 확인해주세요")
    elif age >= 75:
        price = 0
    else:
        print('나이를 숫자로 입력했는지 확인해주세요.')

    print('나이: %d세' % age)
    print('지불유형: ', payType)
    print('버스요금: %d원' %price)

# 버스 요금 입력
A = int(input('나이를 입력해주세요 : '))
P = input("지불유형을 '카드' 혹은 '현금'으로 입력해주세요 : ")
bus_fare(A, P)
