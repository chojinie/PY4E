############ 풀이 타입 A ############

def yearlyPayment(monthlySalary):
    annualSalary_before = monthlySalary * 12
    if annualSalary_before <= 1200:
        tariff = 0.06
    elif annualSalary_before <= 4600:
        tariff = 0.15
    elif annualSalary_before <= 8800:
        tariff = 0.24
    elif annualSalary_before <= 15000:
        tariff = 0.35
    elif annualSalary_before <= 30000:
        tariff = 0.38
    elif annualSalary_before <= 50000:
        tariff = 0.40
    else:
        tariff = 0.42
    annualSalary_after = annualSalary_before * (1 - tariff)
    print('세전 연봉: %0.f만원' % annualSalary_before)
    print('세후 연봉: %0.f만원' % annualSalary_after)

# 월급 입력
monthlyPayment = float(input('월급을 만원 단위로 입력해주세요: '))
yearlyPayment(monthlyPayment)



############ 풀이 타입 B ############
# if else or 관련하여 더욱 간단하게 표현하고자 고민한 결과 range 및 list를 활용했습니다

# 소득 분위 기준
tax_var = [0, 1200, 4600, 8800, 15000, 30000, 50000]

# 구간별 세율
tax_rate = [6, 15, 24, 35, 38, 40, 42]

# 누진 공제액
tax_discount = [0, 108, 522, 1490, 1940, 2540, 3540]


# 구간 계산
def calc_layer(salary: int):
    for i in range(len(tax_var)):
        if salary in range(tax_var[i] + 1, tax_var[i + 1] + 1):
            return i + 1


# 세액 산출
def salary_to_tax(tax_layer: int, y_payment: int):
    return y_payment * tax_rate[tax_layer - 1] / 100 - tax_discount[tax_layer - 1]


while True:
    try:
        i = int(input("세전연봉(만원)을 입력해 주세요 : "))
    except ValueError:
        print("숫자만 입력해주세요.")
        continue

    print(
        f"세전연봉 {i} / 세후연봉 {i - int(salary_to_tax(calc_layer(i), i))} (소득세: {int(salary_to_tax(calc_layer(i), i))}만원 / 소득구간 : {calc_layer(i)})")
