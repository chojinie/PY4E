def stock_profit(stocks, sells):
    stocks = [s.split('/') for s in stocks.split(',')] # [종목, 수량, 매수가] 리스트로 stock_list에 정렬

    # 수익률 계산 = (판매가-매수가)/매수가*100 
    profits = []
    for i in range(len(sells)):
        profit = (sells[i] - int(stocks[i][2])) / int(stocks[i][2]) * 100
        profits.append(profit)

    answer_dict = dict()
    for idx, profit in enumerate(profits):
        if int(stocks[idx][1]) != 0: # 수량이 있으면 딕셔너리로 추가
            answer_dict[profit] = stocks[idx][0].strip() # key값은 수익률, value값은 종목 이름

    # 수익률 값에 따라 내림차순 정렬        
    stk_profit = sorted(answer_dict.items(), reverse=True) 
    print(">>> 보유주식 종목별 수익률 <<<")
    for i, p in enumerate(stk_profit): # 수익률 기준으로 내림차순 정렬했으므로 stk_profit의 (인덱스+1)값이 순위
        print(f"{i+1}. {p[1]}의 수익률 : {p[0]:.3}")


stocks = "삼성전자/10/85000, 카카오/15/130000, LG화학/3/820000, NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]
stock_profit(stocks, sells)