def king_dict(korea, chosun):
    king_dict = dict()
    kor_king = [k.strip() for k in korea.split(',')]
    chosun_king = [c.strip() for c in chosun.split(',')]
    king_cnt = 0

    for king_name in kor_king:
        king_dict[king_name] = 1

    for king_name2 in chosun_king:
        if king_dict.get(king_name2, 0) >= 1: # king_dict에 이미 있는 key 값이라면 value 값에 1씩 더해줌
            king_dict[king_name2] = king_dict[king_name2] + 1
        else:
            continue

    for (name,cnt) in king_dict.items():
        if cnt > 1: # 조선과 고려에 모두 있는 이름이라면 value값이 2 이상
            king_cnt += 1
            print(f"조선과 고려에 모두 있는 왕 이름:{name}")
    print(f"조선과 고려에 모두 있는 왕 이름은 총 {king_cnt}개 입니다.")



korea_king = "태조, 혜종, 정종,광종,경종, 성종,목종,현종,덕종,정종,문종,순종,선종,헌종,숙종,예종,인종,의종,명종,신종,희종,강종,고종,원조,충렬왕,충선왕,충숙왕,충혜왕,충목왕,충정왕,공민왕,우왕,창왕,공양왕"
chosun_king = "태조,정종,태종, 세종,문종,단종, 세조, 예종,성종,연산군,중종,인종,명종,선조,광해군,인조,효종,현종,숙종,경종,영조,정조,순조,헌종,철종,고종,순종"
king_dict(korea_king, chosun_king)