def sales_management(member_names, member_records):
    mem_dict = {}
    for i, m in enumerate(member_names):
        mem_dict[m] = sum(member_records[i]) / len(member_records[i]) # 이름을 key값에 평균실적을 value값에 지정

    mem_lst = sorted([(v,k) for k,v in mem_dict.items()], reverse=True) # 평균실적값 기준으로 리스트 내림차순 정렬
    
    print("*** 보너스 대상자 명단 ***")
    for (point, name) in mem_lst[:2]: # 실적 1등, 2등 중에 평균 실적이 5점을 안 넘으면 제외
        if point >= 5 :
            # 실적값 기준으로 내림차순 정렬했으므로 mem_lst의 (인덱스+1)값이 등수
            print(f"이름: {name}, 실적: {point:.3}점 {mem_lst.index((point,name))+1}등")

    print("\n*** 면담 대상자 명단 ***")
    for (point, name) in mem_lst[-2:]: # 실적 5등, 6등 중에 평균 실적이 3점을 넘으면 제외
        if point <= 3 :
            print(f"이름: {name}, 실적: {point:.3}점 {mem_lst.index((point,name))+1}등")


member_names = ["갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이"]
member_records = [[4,5,3,5,6,5,3,4,1,3,4,5],[2,3,4,3,1,2,0,3,2,5,7,2], [1,3,0,3,3,4,5,6,7,2,2,1],[3,2,9,2,3,5,6,6,4,6,9,9], [8,7,7,5,6,7,5,8,8,6,10,9],[7,8,4,9,5,10,3,3,2,2,1,3]]
sales_management(member_names, member_records)