def good_customer(info):
    info = [i.strip() for i in info.split(',')]
    name = ['ID','AGE','PHONE','GENDER','ZONE','BUY']

    info_dict = dict()
    for i in range(len(info)):
        # 인덱스를 6으로 나눠준 나머지 값을 k로 저장
        # info[i]에 대해 k=0이면 ID, k=1이면 AGE, k=2이면 PHONE, k=3이면 GENDER, k=4이면 ZONE, k=5이면 BUY
        k = i % 6

        # key 값은 name[k], value값은 리스트로 만들어서 info[i] 추가

        # info_dict에 없는 key값인 경우 추가하기
        if info_dict.get(name[k], "") == "": 
            if k == 2 and info[i] == 'x': # 전화번호가 없는 경우 000-0000-0000으로 넣어줌
                info_dict[name[k]] = ['000-0000-0000']
            else:
                info_dict[name[k]] = [info[i]]

        # info_dict에 있는 key값인 경우 value값인 리스트에 info[i]값 추가
        else:
            if k == 2 and info[i] == 'x': # 전화번호가 없는 경우 000-0000-0000으로 넣어줌
                info_dict[name[k]].append('000-0000-0000')
            else:
                info_dict[name[k]].append(info[i])

    # 회원정보 출력
    print(f"***** 회원정보 *****\n{info_dict}")
    
    # 할인 쿠폰을 받을 회원정보 출력
    print("\n*** 할인 쿠폰을 받을 회원정보 ***")
    for i in range(len(info_dict)):
        if int(info_dict["BUY"][i]) >= 8 and info_dict["PHONE"][i] != '000-0000-0000': # 전화번호가 있고 구매횟수가 8이상인 회원
            print(f"{name[0]}: {info_dict['ID'][i]}, {name[1]}: {info_dict['AGE'][i]}, {name[2]}: {info_dict['PHONE'][i]}, {name[3]}: {info_dict['GENDER'][i]}, {name[4]}: {info_dict['ZONE'][i]}, {name[5]}: {info_dict['BUY'][i]}")


# 6명의 회원이고 "아이디,나이,전화번호,성별,지역,구매횟수" 순서로 입력되어 있음
info = "abc, 21세,010-1234-5678, 남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"
good_customer(info)