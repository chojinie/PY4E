# 📌Q3. 예금 금리가 너무 낮아서 주식을 시작했습니다. 아래와 같이 매수한 종목 이름, 수량, 매수 평균 금액이 있습니다. 판매가는 따로 주어집니다. 종목과 수익률만 출력하시고 종목별 수익률이 높은 순서대로 출력해주세요. (소수 둘째자리까지 출력)

stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]

temp = stocks.split(',')                            # temp라는 임시 변수에 stocks를 쉼표로 split 한 리스트를 선언
stock_list = []                                     # 주식의 이름, 수량, 수익률을 저장할 빈 리스트 생성
profit_temp = []                                    # 주식의 이름과 수익률을 임시로 저장할 빈 리스트 생성

for i in temp:                                      # temp 리스트 안에 있는 아이템들을 '/'로 다시 split해서 stock_list에 넣어주는 loop문
    stock_list.append(i.split('/'))

for i in stock_list:                                # stock_list 안에 있는 주식들의 수익률을 계산하고 주식의 이름과 함께 tuple로 묶어 임시 리스트에 저장하는 loop문
    stock_name = i[0]
    stock_price = int(i[2])
    profit_ratio = (sells[stock_list.index(i)] - stock_price) / stock_price * 100
    profit_temp.append((profit_ratio, stock_name))  # 수익률 순으로 sort 할 것이기 때문에 수익률을 튜플의 첫 번째로 가져온다

total_profit = sorted(profit_temp, reverse=True)    # profit_temp 안에 있는 값들을 수익률의 내림차순으로 정렬

for profit, name in total_profit:                   # total_profit 안에 있는 주식의 이름과 수익률을 출력하는 loop문
    print(f"{name}의 수익률: {profit:.3}%")