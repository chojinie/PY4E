# 📌Q4. 여러분은 어떤 상품을 판매하고 있습니다. 매월 상품을 많이 구매해준 VIP회원에게 할인 쿠폰을 제공해주려고 합니다. 아래와 같은 회원 정보가 있을 때 회원 정보를 출력하고 할인 쿠폰을 받을 회원이 누구인지 출력하는 함수를 만들어 주세요.

# 😲조건1 - 8회 이상 구매한 회원이 VIP대상
# 😲조건2 - 전화번호가 없으면 쿠폰을 받을 수 없음
# 😲조건3 - 전화번호가 없으면 000-0000-0000으로 출력할 것

# 6명의 회원이고 "아이디, 나이, 전화번호, 성별, 지역, 구매횟수" 순서로 입력되어 있음
info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"

info_lst = info.split(',')                                      # info를 쉼표 단위로 나누어 리스트에 저장
spt_lst = [info_lst[i * 6:(i + 1) * 6] for i in range(6)]       # info_lst 안에 있는 값들을 6개씩 나누어 리스트로 묶어서 또다른 리스트에 저장

# 아이디, 나이, 전화번호, 성별, 지역, 구매횟수를 저장할 빈 리스트들 생성
id_lst = []
age_lst = []
num_lst = []
gender_lst = []
address_lst = []
purchase_lst = []

# 각각의 리스트들에 해당하는 값들을 저장
for i in spt_lst:
    id_lst.append(i[0])
    age_lst.append(i[1])
    gender_lst.append(i[3])
    address_lst.append(i[4])
    purchase_lst.append(i[5])
    if i[2] == "x":                         # 전화번호가 "x"로 기입돼있으면 010-0000-0000을 대신 저장
        num_lst.append("010-0000-0000")
    else:
        num_lst.append(i[2])

user_info_dict = {}                         # 아이디, 나이, 전화번호, 성별, 지역, 구매횟수를 key로 하고 해당하는 값들을 value로 가질 빈 딕셔너리 생성

# 딕셔너리에 key와 value를 할당해 값들을 저장
user_info_dict["아이디"] = id_lst
user_info_dict["나이"] = age_lst
user_info_dict["전화번호"] = num_lst
user_info_dict["성별"] = gender_lst
user_info_dict["지역"] = address_lst
user_info_dict["구매횟수"] = purchase_lst

temp_lst = []                               # 구매횟수 조건에 맞는 값들의 인덱스 넘버를 저장할 빈 리스트 생성
for i in purchase_lst:                      # 구매횟수가 8 이상이면 그 값의 인덱스 넘버를 temp_lst에 저장
    if int(i) >= 8:
        temp_lst.append(int(purchase_lst.index(i)))

vip_index = []                              # 전화번호 조건에 맞는 인덱스 넘버를 저장할 빈 리스트 생성
for i in temp_lst:                          # 전화번호가 010-0000-0000이 아니면 리스트에 인덱스 넘버를 저장
    if num_lst[i] != "010-0000-0000":
        vip_index.append(i)

vip_dict = {}                               # VIP의 정보를 저장할 빈 딕셔너리 생성
for i in vip_index:                         # 딕셔너리에 key와 value를 할당
    vip_dict["아이디"] = user_info_dict["아이디"][i]
    vip_dict["나이"] = user_info_dict["나이"][i]
    vip_dict["전화번호"] = user_info_dict["전화번호"][i]
    vip_dict["성별"] = user_info_dict["성별"][i]
    vip_dict["지역"] = user_info_dict["지역"][i]
    vip_dict["구매횟수"] = user_info_dict["구매횟수"][i]

# print문을 통해 VIP 고객의 정보를 출력
print(f"""할인 쿠폰을 받을 회원정보
아이디: {vip_dict["아이디"]}
나이: {vip_dict["나이"]}세
전화번호: {vip_dict["전화번호"]}
성별: {vip_dict["성별"]}
구매횟수: {vip_dict["구매횟수"]}회""")