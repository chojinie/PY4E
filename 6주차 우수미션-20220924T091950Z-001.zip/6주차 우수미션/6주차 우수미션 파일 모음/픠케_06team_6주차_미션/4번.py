# Q4. 여러분은 어떤 상품을 판매하고 있습니다. 
# 매월 상품을 많이 구매해준 VIP회원에게 할인 쿠폰을 제공해주려고 합니다. 
# 아래와 같은 회원 정보가 있을 때 회원 정보를 출력하고 할인 쿠폰을 받을 회원이 누구인지 출력하는 함수를 만들어 주세요.

# 😲조건1 - 8회 이상 구매한 회원이 VIP대상
# 😲조건2 - 전화번호가 없으면 쿠폰을 받을 수 없음
# 😲조건3 - 전화번호가 없으면 000-0000-0000으로 출력할 것

#출력예시
# {'아이디': ['abc', 'cdb', 'bbc', 'ccb', 'dab', 'aab'], '나이': ['21세', '25세', '30세', '29세', '26세', '23세'], '전화번호': ['010-1234-5678', '000-0000-0000', '010-2222-3333', '000-0000-0000', '000-0000-0000', '010-3333-1111'], '성별': ['남자', '남자', '여자', '여자', '남자', '여자'], '지역': ['서울', '서울', '서울', '경기', '인천', '경기'], '구매횟수': [5, 4, 3, 9, 8, 10]}
# 할인 쿠폰을 받을 회원정보 아이디:aab, 나이:23세, 전화번호:010-3333-1111, 성별:여자, 지역:경기, 구매횟수: 10

# 6명의 회원이고 "아이디,나이,전화번호,성별,지역,구매횟수" 순서로 입력되어 있음
info = '''abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10'''
info_list=info.split(',')
ID=[]
age=[]
phone=[]
sex=[]
loc=[]
num=[]
for i in range(36):
    if (i+1)%6==1:
        ID.append(info_list[i])
    if (i+1)%6==2:
        age.append(info_list[i])
    if (i+1)%6==3:
        if info_list[i]=='x':
            info_list[i]=='000-0000-0000'
        phone.append(info_list[i])
    if (i+1)%6==4:
        sex.append(info_list[i])
    if (i+1)%6==5:
        loc.append(info_list[i])
    if (i+1)%6==0:
        num.append(info_list[i])


key=['아이디','나이','전화번호','성별','지역','구매횟수']
val=[ID, age, phone, sex, loc, num]
dict_member=dict(zip(key, val))
print(dict_member)
count=0
for i in dict_member['구매횟수']:
    if int(i)>=8:
       if not dict_member['전화번호'][count]=='x':
           print(f"할인 쿠폰을 받을 회원정보 아이디:{dict_member['아이디'][count]}, 나이:{dict_member['나이'][count]}, 전화번호:{dict_member['전화번호'][count]}, 성별:{dict_member['성별'][count]}, 지역:{dict_member['지역'][count]}, 구매횟수:{dict_member['구매횟수'][count]}")
    count+=1 
    


#못난 코드 읽어주시느라 그동안 감사했습니다