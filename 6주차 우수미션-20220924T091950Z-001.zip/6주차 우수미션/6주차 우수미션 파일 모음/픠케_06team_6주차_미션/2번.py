# Q2.  여러분은 6명의 멤버를 거느리는 영업팀의 영업관리자 입니다. 
# 각 멤버별로 올해 실적을 보고 잘한 멤버는 보너스를 주고 못한 멤버는 면담을 하려고 합니다. 
# 파이썬을 이용하여 함수를 만들어 보너스 대상자와 면담 대상자를 골라주세요.

# 😲조건 1 - 예비 보너스 대상자는 평균 실적 1등 2등 입니다.
# 😲조건 2 - 예비 면담 대상자는 평균 실적 5등 6등 입니다.
# 😲조건 3 - 보너스 대상자의 평균 실적이 5보다 크지 않으면 보너스 대상자에서 제외 됩니다.
# 😲조건 4 - 면담 대상자의 평균 실적이 3보다 크면 면담 대상자에서 제외 됩니다.

# 이름, 실적
member_names = ["갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이"]
member_records = [[4,5,3,5,6,5,3,4,1,3,4,5],[2,3,4,3,1,2,0,3,2,5,7,2], 
           [1,3,0,3,3,4,5,6,7,2,2,1],[3,2,9,2,3,5,6,6,4,6,9,9],
           [8,7,7,5,6,7,5,8,8,6,10,9],[7,8,4,9,5,10,3,3,2,2,1,3]]

def avg(arr):
# 합계 구하기
    result = sum(arr)
# 평균 구하기 둘째 자리에서 반올림
    avg=round(result / len(arr),2)
    return avg


def sales_management(member_names, member_records):
    member_avg=[]
    for i in member_records:
        member_avg.append(avg(i))
    dict_member=dict(zip(member_names,member_avg))
    sorted_member = sorted(dict_member.items(), key = lambda item: item[1], reverse=True)
    if sorted_member[1][1]>5:
        print(f"보너스 대상자 {sorted_member[0][0]}")
        print(f"보너스 대상자 {sorted_member[1][0]}")
    elif sorted_member[0][1]>5:
        print(f"보너스 대상자 {sorted_member[0][0]}")
    else:
        print("보너스 대상자 없습니다")
    
    print("\n")
    
    if sorted_member[4][1]<=3:
        print(f"면담 대상자 {sorted_member[4][0]}")
        print(f"면담 대상자 {sorted_member[5][0]}")
    elif sorted_member[5][1]<=3:
        print(f"면담 대상자 {sorted_member[5][0]}")
    else:
        print("면담 대상자 없습니다")
        
sales_management(member_names, member_records)