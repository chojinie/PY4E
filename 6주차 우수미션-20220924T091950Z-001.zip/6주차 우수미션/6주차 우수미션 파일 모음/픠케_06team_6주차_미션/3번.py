# 📌Q3. 예금 금리가 너무 낮아서 주식을 시작했습니다. 
# 아래와 같이 매수한 종목 이름, 수량, 매수 평균 금액이 있습니다. 
# 판매가는 따로 주어집니다. 
# 종목과 수익률만 출력하시고 종목별 수익률이 높은 순서대로 출력해주세요. (소수 둘째자리까지 출력)

stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]
stocks_split=stocks.split(',')

stocks_split2=[]
for i in stocks_split:
    stocks_split2.append(i.split('/'))
    
name=[]
for i in stocks_split2:
    name.append(i[0])
for i in range(4):
    stocks_split2[i][2]=int(stocks_split2[i][2])

yyield=[]
for i in range(4):
    yyield.append(((sells[i]-stocks_split2[i][2])/stocks_split2[i][2])*100)


dict_stocks=dict(zip(name,yyield))
dict_stocks = sorted(dict_stocks.items(), key = lambda item: item[1], reverse=True)
for i in dict_stocks:
    print(f"{i[0]}의 수익률 {i[1]:.3}")
