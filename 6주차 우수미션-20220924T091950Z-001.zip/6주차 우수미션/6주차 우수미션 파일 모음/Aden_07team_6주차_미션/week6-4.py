info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"

"""
info 문자열에서 x를 미리 000-0000-0000 꼴로 변환 후 , 기준으로 쪼개어 하나의 배열로 만듦
그 이후 해당 배열을 6칸씩 뛰어가며 슬라이싱하여 keys와 함께 zip으로 묶어 딕셔너리로 만듦
각 키 별로 데이터가 뿔뿔히 흩어져 져장되어 있기 때문에 모든 values를 다시 zip으로 묶어 완성된 데이터 화 한 다음
전화번호가 000-0000-0000이 아니고 구입 횟수가 8 이상인 값을 찾아 출력
"""


tmp = info.replace("x", "000-0000-0000").split(",")

keys = ["아이디", "나이", "전화번호", "성별", "지역", "구매횟수"]
dict = {key: [] for key in keys}

for i in range(0, len(tmp), 6):
    data = tmp[i : i + 6]

    for key, value in zip(keys, data):
        dict[key].append(value)


for i in zip(*dict.values()):
    tmp = [*i]
    if tmp[2] != "000-0000-0000" and int(tmp[-1]) >= 8:
        print(*tmp)
