korea_king = "태조,혜종,정종,광종,경종,성종,목종,현종,덕종,정종,문종,순종,선종,헌종,숙종,예종,인종,의종,명종,신종,희종,강종,고종,원조,충렬왕,충선왕,충숙왕,충혜왕,충목왕,충정왕,공민왕,우왕,창왕,공양왕"
chosun_king = (
    "태조,정종,태종,세종,문종,단종,세조,예종,성종,연산군,중종,인종,명종,선조,광해군,인조,효종,현종,숙종,경종,영조,정조,순조,헌종,철종,고종,순종"
)


def king(str1, str2):

    """
    입력받은 배열들을 , 기준으로 전부 쪼갠 후 교집합을 저장
    그 후 교집합 값들이 저장된 is_duplicated 배열을 순회하며 이름 출력 후
    len(is_duplicated) 출력하여 갯수 출력
    """
    list_1 = str1.split(",")
    list_2 = str2.split(",")
    is_duplicated = list(set(list_1) & set(list_2))

    for i in is_duplicated:
        print(f"조선과 고려에 모두 있는 왕 이름 : {i}")
    print(f"조선과 고려에 모두 있는 왕 이름은 총 {len(is_duplicated)} 개 입니다.")


king(korea_king, chosun_king)
