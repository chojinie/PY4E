stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]

"""
주식목록을 / 를 기준으로 전부 쪼갠 후  stocks와 sells를 zip으로 묶은 다음
이름, 갯수, 구매했던 가격, 현재 가격을 각각 name, ea, price, sell 변수에 할당
그 후 수익률 변수 ror에 수익률을 계산하여 저장한 후 
tmp 배열에 [주식회사명, 수익률] 형식으로 데이터 삽입 후 수익률 기준으로 내림차순 정렬
마지막으로 tmp 배열을 순회하면서 이름과 수익률 출력
"""


purchased = [x.split("/") for x in stocks.split(",")]
tmp = []

for (name, ea, price), sell in zip(purchased, sells):
    ror = round(((sell - int(price)) / int(price)) * 100, 2)
    tmp.append([name, ror])

tmp = sorted(tmp, key=lambda x: -x[1])

for name, ror in tmp:
    print(f"{name}의 수익률 : {ror}")
