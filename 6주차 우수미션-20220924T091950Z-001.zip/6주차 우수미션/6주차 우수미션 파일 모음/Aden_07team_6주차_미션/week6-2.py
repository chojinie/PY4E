member_names = ["갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이"]
member_records = [
    [4, 5, 3, 5, 6, 5, 3, 4, 1, 3, 4, 5],
    [2, 3, 4, 3, 1, 2, 0, 3, 2, 5, 7, 2],
    [1, 3, 0, 3, 3, 4, 5, 6, 7, 2, 2, 1],
    [3, 2, 9, 2, 3, 5, 6, 6, 4, 6, 9, 9],
    [8, 7, 7, 5, 6, 7, 5, 8, 8, 6, 10, 9],
    [7, 8, 4, 9, 5, 10, 3, 3, 2, 2, 1, 3],
]

tmp = []

"""
member_names와 member_records는 서로 짝지어 있기 때문에 zip 함수로 요소들을 뽑아와서
tmp 라는 빈 배열에 [이름, 평균 점수]를 저장함
그 후 평균점수를 기준으로 내림차순 정렬 후

고득점자 2명을 slice로 뽑아온 후 점수가 5가 넘는지 확인한 후 넘는다면 보너스 대상자를 출력
저득점자 2명을 slice로 뽑아온 후 점수가 3 이하이면 면담 대상자를 출력
"""


for name, score in zip(member_names, member_records):
    tmp.append([name, sum(score) / len(score)])


tmp = sorted(tmp, key=lambda x: -x[1])

for name, score in tmp[:2]:
    if score > 5:
        print(f"보너스 대상자 {name}")

for name, score in tmp[-2:]:
    if score <= 3:
        print(f"면담 대상자 {name}")
