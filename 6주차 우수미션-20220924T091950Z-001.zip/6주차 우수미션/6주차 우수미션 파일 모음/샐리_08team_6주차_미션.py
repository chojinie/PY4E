# Q1
# 왕 이름
korea_king = "태조,혜종,정종,광종,경종,성종,목종,현종,덕종,정종,문종,순종,선종,헌종,숙종,예종,인종,의종,명종,신종,희종,강종,고종,원조,충렬왕,충선왕,충숙왕,충혜왕,충목왕,충정왕,공민왕,우왕,창왕,공양왕"
chosun_king = "태조,정종,태종,세종,문종,단종,세조,예종,성종,연산군,중종,인종,명종,선조,광해군,인조,효종,현종,숙종,경종,영조,정조,순조,헌종,철종,고종,순종"


def king(korea_king,chosun_king):
    # 왕 이름을 담은 하나의 딕셔너리 생성하기
    # 딕셔너리 내부의 '키 = 왕 이름', '값 = 나온 수'로 설정
    counts = dict()
    kor = korea_king.split(',')
    cho = chosun_king.split(',')
    for name1 in kor :
        counts[name1] = counts.get(name1,0) + 1
    for name2 in cho :
        counts[name2] = counts.get(name2,0) + 1

    # 값을 기준으로 정렬
    new_counts = list()
    for k,v in counts.items() :
        newtup = (v,k)
        new_counts.append(newtup)

    # 고려와 조선에 공통적으로 있는 왕 이름 뽑아내기
    common = list()
    for value,key in new_counts :
        if value > 1 :
            re = (key,value)
            common.append(re)

    # 출력
    cnt = 0
    for name,number in common:
        cnt += 1
        print('조선과 고려에 모두 있는 왕 이름:',name)
    print('조선과 고려에 모두 있는 왕 이름은 총',cnt,'개 입니다.')

#--------------------------------------------------------------------------------

# Q2
# 이름, 실적
member_names = ["갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이"]
member_records = [[4,5,3,5,6,5,3,4,1,3,4,5],[2,3,4,3,1,2,0,3,2,5,7,2],
           [1,3,0,3,3,4,5,6,7,2,2,1],[3,2,9,2,3,5,6,6,4,6,9,9],
           [8,7,7,5,6,7,5,8,8,6,10,9],[7,8,4,9,5,10,3,3,2,2,1,3]]

def sales_management(member_names,member_records):
    # 각 멤버의 평균 실적 계산하기
    avg_result = list()
    for result in member_records:
        avg = sum(result) / len(result)
        avg_result.append(avg)

    # 예비 보너스 및 면담 대상자 뽑기
    mem_rst = list()
    for num in range(len(member_names)) :
        (x,y) = (avg_result[num],member_names[num])
        mem_rst.append( (x,y) ) # (값,키) 형태의 튜플
    mem_rst = sorted(mem_rst, reverse=True)

    # 실제 보너스 및 면담 대상자 뽑기
    bonus = list()
    for value in mem_rst[:2] :
        if value >= (5,'comparison') :
            bonus.append(value)
    interview = list()
    for val in mem_rst[4:] :
        if val < (3,'comparison') :
            interview.append(val)

    # 출력
    for v,k in bonus:
        print('보너스 대상자',k)
    print('\n')
    for V,K in interview:
        print('면담 대상자',K)

#--------------------------------------------------------------------------------

# Q3
# 매수한 주식, 판매가
stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]


def stock_profit(stocks,sells):
    # 매수한 금액 리스트, 주식 종목 이름 리스트 만들기
    stocks = stocks.split(',')
    payments = list()
    stockname = list()
    for num in range(len(stocks)) :
        stock = stocks[num].split('/')
        payments.append(stock[-1])
        stockname.append(stock[0])

    # 수익률 계산하기
    # 수익률 = (판매금액 - 매수금액)/매수금액 * 100 [%]
    profits = list()
    for number in range(len(payments)) :
        profit = (sells[number] - int(payments[number]))/int(payments[number]) * 100
        profit = f"{profit:.3}"
        profits.append(profit)

    # 수익률과 주식 종목 이름 쌍의 튜플 생성하기
    name_profit = list()
    for n in range(len(profits)) :
        (x,y) = (profits[n],stockname[n])
        name_profit.append( (x,y) )
    name_profit = sorted(name_profit, reverse=True)
    ## 삼성전자와 NAVER의 자리를 어떻게 바꿔야 할 지 모르겠습니다....

    # 출력
    for val,key in name_profit :
        print(key,'의 수익률:',val)

#--------------------------------------------------------------------------------

# Q4
# 6명의 회원이고 "아이디,나이,전화번호,성별,지역,구매횟수" 순서로 입력되어 있음
info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"

def good_customer(info):
    # 각 회원별로 나눈 리스트 만들기
    info = info.split(',')
    members = list()
    for n in range(0,6) :
        if info[n*6 + 2] == 'x' :
            info[n*6 + 2] = '000-0000-0000'
        member = info[n*6:(n+1)*6]
        members.append(member)

    # 아이디, 나이, 전화번호, 성별, 지역, 구매횟수 리스트
    a = ['아이디','나이','전화번호','성별','지역','구매횟수']
    ids = list()
    ages = list()
    phones = list()
    genders = list()
    regions = list()
    buys = list()
    for m in members:
        ids.append(m[0])
        ages.append(m[1])
        phones.append(m[2])
        genders.append(m[3])
        regions.append(m[4])
        buys.append(m[5])
    arr = [ids,ages,phones,genders,regions,buys]
    arr_tuple = list()
    for n in range(len(a)) :
        arr_tuple.append( (a[n],arr[n]) )


    # vip 회원 중 쿠폰을 받을 회원 리스트 만들기
    coupon = list()
    for mem in members:
        if (int(mem[5]) >= 8) and (mem[2] != '000-0000-0000') :
            coupon.append(mem)

    # 출력
    print(arr_tuple)
    for get in coupon:
        print('할인 쿠폰을 받을 회원정보 아이디:',get[0],',','나이:',get[1],',','전화번호:',get[2],',','성별:',get[3],',','지역:',get[4],',','구매횟수:',get[5])
