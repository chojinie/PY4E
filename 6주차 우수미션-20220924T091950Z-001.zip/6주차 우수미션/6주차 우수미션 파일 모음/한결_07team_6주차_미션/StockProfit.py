# 가지고 있는 주식에 따른 수익률을 높은 순서대로 프로그램
# 수익률(%) = (판매가 - 매수평균금액) / 매수평균금액 * 100

def stock_profit(stocks, sells):
    stocks_info_list = stocks.split(',')
    stocks_info = {}

    for i in range(len(stocks_info_list)):
        stock_info = stocks_info_list[i].split('/')
        stock_name = stock_info[0]
        stock_avg_price = float(stock_info[2])
        profit = round((sells[i] - stock_avg_price) / stock_avg_price * 100, 2)     # round 함수를 사용해 소수 셋째 자리에서 반올림

        stocks_info[stock_name] = profit

    # 수익률이 높은 순으로 dictionary의 정보를 정렬 후 (key, value)를 list로 저장
    sorted_stocks_info = sorted(stocks_info.items(), key = lambda x: x[1], reverse = True)

    for i in range(len(sorted_stocks_info)):
        print(f'NAME: {sorted_stocks_info[i][0]}, PROFIT: {sorted_stocks_info[i][1]}')

my_stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
my_sells = [82000, 160000, 835000, 410000]
stock_profit(my_stocks, my_sells)