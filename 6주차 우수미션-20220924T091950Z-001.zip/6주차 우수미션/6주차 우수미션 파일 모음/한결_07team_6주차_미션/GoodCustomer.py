# 고객들의 정보를 입력받아 구매횟수가 가장 많은 고객(쿠폰을 받은 고객)의 정보를 출력하는 프로그램

def good_customer(information):
    # 입력받은 정보에 따라 아이디, 나이, 전화번호, 성별, 지역, 구매횟수를 저장
    # 각기 다른 리스트에 정보를 저장하고 하나의 딕셔너리에 모든 리스트를 저장
    # 구매 횟수가 가장 많은 고객의 정보를 출력

    sliced_info = information.split(',')

    for i in range(len(sliced_info)):
        if sliced_info[i] == 'x': sliced_info[i] = '000-0000-0000'      # 전화번호가 없으면 000-0000-0000으로 저장

    # index를 활용해 list에 따라 원하는 정보를 저장
    id_info = [sliced_info[x] for x in range(0, len(sliced_info), 6)]
    age_info = [sliced_info[x + 1] for x in range(0, len(sliced_info), 6)]
    number_info = [sliced_info[x + 2] for x in range(0, len(sliced_info), 6)]
    gender_info = [sliced_info[x + 3] for x in range(0, len(sliced_info), 6)]
    loc_info = [sliced_info[x + 4] for x in range(0, len(sliced_info), 6)]
    cnt_info = [int(sliced_info[x + 5]) for x in range(0, len(sliced_info), 6)]

    # 모든 data를 취합해 하나의 dictionary에 저장
    info_dict = {'아이디': id_info,
                 '나이': age_info,
                 '전화번호': number_info,
                 '성별': gender_info,
                 '지역': loc_info,
                 '구매횟수': cnt_info}

    # 8회 이상 구매한 회원이 VIP 대상
    # 전화번호가 없으면 쿠폰을 받을 수 없음(000-0000-0000)
    # 조건에 맞는 값의 index를 찾아 dictionary에서 key 별로 index에 대응되는 값을 선택해 출력
    print('할인쿠폰을 받을 고객의 정보')

    for i in range(len(cnt_info)):
        if cnt_info[i] >= 8 and number_info[i] != '000-0000-0000':
            print(info_dict['아이디'][i],
                  info_dict['나이'][i],
                  info_dict['전화번호'][i],
                  info_dict['성별'][i],
                  info_dict['지역'][i],
                  info_dict['구매횟수'][i])

info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"
good_customer(info)
