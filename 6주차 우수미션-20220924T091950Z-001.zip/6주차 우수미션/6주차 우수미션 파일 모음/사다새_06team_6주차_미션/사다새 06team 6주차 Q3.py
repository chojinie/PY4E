stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]

def stock_profit(stocks, sells):
    #['삼성전자/10/85000',''] 형태로 저장
    stocks = stocks.split(",")

    #[['삼성전자',10,85000],[]] 형태로 저장
    stocks_list = []

    for com_num_prices in stocks:
        com_num_prices = com_num_prices.split("/")
        stocks_list.append(com_num_prices)

    수익률 = []

    #수익률 계산과 동시에 [수익률] 리스트에 추가
    for company in stocks_list:
        수익률.append((round(sells[stocks_list.index(company)]/int(company[2])*100 - 100,2),company[0]))

    수익률 = sorted(수익률,reverse=True)
    for profit,company in 수익률:
        print(company + "의 수익률",profit)

stock_profit(stocks, sells)