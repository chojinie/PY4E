member_names = ("갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이")
member_records = ((4,5,3,5,6,5,3,4,1,3,4,5),(2,3,4,3,1,2,0,3,2,5,7,2),(1,3,0,3,3,4,5,6,7,2,2,1),(3,2,9,2,3,5,6,6,4,6,9,9),(8,7,7,5,6,7,5,8,8,6,10,9),(7,8,4,9,5,10,3,3,2,2,1,3))

#위의 정보를 딕셔너리로 짝을 맞춰주는 메서드
member_dic = {}
for name in member_names:
    member_dic[name]=member_records[member_names.index(name)]

#회사원들 성적 순위 리스트, 구성원소는 튜플형태 [(average,name),(평균점수,회사원명), ...]
순위 = []

for name,record in member_dic.items():
    sum = 0
    for i in record:
        sum += i
    average = sum / 12
    # 회사원 순위를 매기기 위해 average가 튜플 안에서 앞쪽에 위치함.
    순위.append((average,name))

순위 = sorted(순위, reverse=True)

#[순위]라는 list에서 데이터 추출
#보너스 대상자 선정
보너스_대상자 = []
# 1,2등
for i in range(2):
    if 순위[i][0] > 5:
        보너스_대상자.append(순위[i][1])

#면접 대상자 선정
면접_대상자 = []
# 5,6등
for i in range(4,6):
    if 순위[i][0] <= 3:
        면접_대상자.append(순위[i][1])

for i in 보너스_대상자:
    print("보너스 대상자",i)

#줄바꿈
print("")

for i in 면접_대상자:
    print("면담 대상자",i)
