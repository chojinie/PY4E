# 6명의 회원이고 "아이디,나이,전화번호,성별,지역,구매횟수" 순서로 입력되어 있음
info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"

def good_customer(info):

    #잘못된 길이의 info가 입력되었는지 확인; split(",") 했을 때 리시트형의 info의 길이가 6의 배수여야함.
    info_All = info.split(",")
    if len(info_All) % 6 != 0:
        print("잘못된 info 입력 감지")
    else:
        사람수 = int(len(info_All)/6)

    id = []
    age = []
    tel = []
    gender = []
    area = []
    buy = []

    # 정보 추출
    # i+1 번째 사람 정보 차례로 입력
    for i in range(사람수):
        id.append(info_All[i*6])
        age.append(info_All[i*6+1])
        #올바른 전화번호를 적지 않았을 때 "x" 로 사전에 기입했다고 가정해야만 사용 가능
        if info_All[i*6+2] != "x":
            tel.append(info_All[i*6+2])
        else:
            tel.append("000-0000-0000")
        gender.append(info_All[i*6+3])
        area.append(info_All[i*6+4])
        buy.append(info_All[i*6+5])

    # 미션 출력예시 속 dic
    dic = {}
    dic["아이디"] = id
    dic["나이"] = age
    dic["전화번호"] = tel
    dic["성별"] = gender
    dic["지역"] = area
    dic["구매횟수"] = buy
    print(dic)

    #vip 고객리스트는 [정수형태]를 받아 리스트를 만들 것임, i 번째 회원이 vip인지 아닌지 확인하는 과정을 거치게 됨.
    vip = []

    #vip 고객 선정
    for i in dic["구매횟수"]:
        if (int(i) >= 8) and (dic["전화번호"][dic["구매횟수"].index(i)] != "000-0000-0000"):
            vip.append(dic["구매횟수"].index(i))

    #vip 고객 출력
    for i in vip:
        print("할인 쿠폰을 받을 회원정보 아이디:",dic["아이디"][i])
        print("나이:",dic["나이"][i])
        print("전화번호:",dic["전화번호"][i])
        print("성별:",dic["성별"][i])
        print("지역:",dic["지역"][i])
        print("구매횟수:",dic["구매횟수"][i])

good_customer(info)