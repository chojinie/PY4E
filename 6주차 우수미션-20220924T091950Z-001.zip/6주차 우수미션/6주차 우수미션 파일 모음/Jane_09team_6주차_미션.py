#Jane_09team 6주차 미션

#풀이는 크게 다르지는 않아서 이번에는 취합을 하고자 했지만 
#하지만 개인사정으로 참여하지를 못하신 분이 주석을 굉장히 꼼꼼하게 써주시느라
#차마 지우기 아까워서 모두 한번에 수록하겠습니다.
#처음 배우시는 분들도 팀에 있어서 공부하기 좋게 써주신 것 같습니다! 

#1 

#📌Q1. 역사 문제를 하나 내보겠습니다. 고려시대와 조선시대 왕 이름 중에서 고려에도 있고 조선에도 있는 이름은 몇개 일까요? 한 번에 딱 안 떠오른다면 왕 이름을 드릴테니 파이썬 함수로 만들어서 출력 해봅시다.
 
#😲조건1 - 중복되는 왕 이름 출력
#😲조건2 - 중복되는 왕 이름의 수 출력

#첫번째 풀이 
#큰 차이는 없지만 개수를 세는 count 함수를 새로 정의하셨습니다. 


# {왕이름(key),중복 개수(value)} 빈 딕셔너리 생성
dict_king = dict()
def king(korea_king, chosun_king):
  # 고려 왕 이름을 names1 리스트에 (,)를 기준으로 나눠서 추가
  n_korea = korea_king.split(",")
  # 조선 왕 이름을 names2 리스트에 (,)를 기준으로 나눠서 추가
  n_chosun = chosun_king.split(",")
  # n_korea 요소의 개수 만큼 반복
  # 고려 왕 이름을 먼저 dict_king(딕셔너리)에 추가
  for name in n_korea:
    # {왕이름(key),중복 개수(1)} 로 초기화
    dict_king[name] = 1
  # n_chosun 요소의 개수 만큼 반복
  # 조선 왕 이름을 dict_king(딕셔너리)에 추가
  for name in n_chosun :
    # 중복된 이름이 dict_king(딕셔너리)에 있으면 중복 개수 + 1
    if name in  dict_king:
        dict_king[name] += 1
    # 중복된 이름이 dict_king(딕셔너리)에 없으면 중복 개수 = 1 초기화
    else :
        dict_king[name] = 1
  # 중복된 이름,개수를 출력하는 함수 호출
  count(dict_king)
# 딕셔너리에 중복된 이름,개수를 출력 함수
def count(dict):
  count = 0
  # 딕셔너리 요소의 개수 만큼 반복
  for name in dict:
    # 딕셔너리에 해당 name(key)값의 Value가 1보다 크면 count + 1
    if dict.get(name) > 1:
      print("조선과 고려에 모두 있는 왕 이름: %s" % name)
      count += 1
  print("조선과 고려에 모두 있는 왕 이름은 총%d개 입니다" % count)
# 왕 이름
korea_king = "태조,혜종,정종,광종,경종,성종,목종,현종,덕종,정종,문종,순종,선종,헌종,숙종,예종,인종,의종,명종,신종,희종,강종,고종,원조,충렬왕,충선왕,충숙왕,충혜왕,충목왕,충정왕,공민왕,우왕,창왕,공양왕"
chosun_king = "태조,정종,태종,세종,문종,단종,세조,예종,성종,연산군,중종,인종,명종,선조,광해군,인조,효종,현종,숙종,경종,영조,정조,순조,헌종,철종,고종,순종"
king(korea_king, chosun_king)




#두번째 풀이
#풀고 보니 예시 코드와 비슷한 것 같기는 하지만 설명하겠습니다. 
#먼저 고려왕:1이 되도록 딕셔너리를 만들고 조선왕 리스트를 하나하나 루프를 돌리면서 이름이 겹치면
#고려왕: 2 가 되도록 코드를 짰습니다. (value값 수정)
#count 함수를 정의하기 대신 value값이 1보다 큰 key 값 (왕 이름)을 리스트로 모아
#length 함수를 활용해 개수를 셌습니다. 

korea_king = "태조,혜종,정종,광종,경종,성종,목종,현종,덕종,정종,문종,순종,선종,헌종,숙종,예종,인종,의종,명종,신종,희종,강종,고종,원조,충렬왕,충선왕,충숙왕,충혜왕,충목왕,충정왕,공민왕,우왕,창왕,공양왕"
chosun_king = "태조,정종,태종,세종,문종,단종,세조,예종,성종,연산군,중종,인종,명종,선조,광해군,인조,효종,현종,숙종,경종,영조,정조,순조,헌종,철종,고종,순종"

def king(korea_king, chosun_king):
    korealist = korea_king.split(",") #고려왕을 , 기준으로 나눠 리스트로 만들기 
    chosunlist = chosun_king.split(",") #조선왕을 , 기준으로 나눠 리스트로 만들기 

    dup = {} #중복되는 왕의 이름 갯수를 세기 위한 딕셔너리 생성 

    for i in korealist:
        dup[i] = 1 #기본은 1개
    #print(dup)
    
    for j in chosunlist:
        if j in dup:
            dup[j] += 1 #이미 있으면 추가하기 
    
    #print(dup)

    result = [] 
    for k in dup:
        if dup[k] >1: 
            result.append(k) #굳이 필요하진 않으나 리스트의 length 함수를 쓰고 프린트 하기 위해 리스트 사용
    #print(result)

    for king in result:
        print(f"조선과 고려에 모두 있는 왕 이름 :{king}")

    print(f"조선과 고려에 모두 있는 왕 이름은 총 {len(result)}개 입니다.")

print(king(korea_king, chosun_king))






#2
#📌Q2.  여러분은 6명의 멤버를 거느리는 영업팀의 영업관리자 입니다. 각 멤버별로 올해 실적을 보고 잘한 멤버는 보너스를 주고 못한 멤버는 면담을 하려고 합니다. 파이썬을 이용하여 함수를 만들어 보너스 대상자와 면담 대상자를 골라주세요.
#😲조건 1 - 예비 보너스 대상자는 평균 실적 1등 2등 입니다.
#😲조건 2 - 예비 면담 대상자는 평균 실적 5등 6등 입니다.
#😲조건 3 - 보너스 대상자의 평균 실적이 5보다 크지 않으면 보너스 대상자에서 제외 됩니다.
#😲조건 4 - 면담 대상자의 평균 실적이 3보다 크면 면담 대상자에서 제외 됩니다.



#첫번째 풀이
#실적을 모두 더하고 나중에 한번에 나누는 방식으로 평균을 구하셨습니다. 
#lambda를 활용해서 value값으로 내림차순/오름차순 정렬하는걸 잘 활용하셨습니다.

dict_result = dict()
solted_result = dict()
new = dict()
def sales_management(member_names, member_records):
  # member_records의 인덱스 개수 만큼 반복
  for i in range(6):
    sum_record = 0
    #print(">>>> i:",i)
    # member_records의 각 인덱스의 각 요소들 더하기
    for j in range(12):
      #print("j:",j)
      # 실적 더하기
      sum_record += member_records[i][j]
      #print(f"sum = {sum_record} --- member_records[{i}][{j}] = {member_records[i][j]}")
    #dict_result의 value값에 실적 합계 저장
    dict_result[member_names[i]] = sum_record
    #print(dict_result)
    #dict_result를 value값으로 역순 정렬
  solted_result = sorted(dict_result.items(), key=lambda x: x[1],reverse=True)
#  for n in range(6):
#    print("solted_result[",n,"]:",solted_result[n])
#    print("solted_result[",n,"][0]:",solted_result[n][0])
#    print("solted_result[",n,"][1]:",solted_result[n][1])
  # solted_result의 각 인덱스에 해당 하는 요소들을 새로운 new 딕셔너리에 추가
  for k in range(6):
    a = solted_result[k][0]
#    print(a)
    # 평균 실적을 구함
    b = solted_result[k][1] // 12
#    print(b)
    new[a] = b
#  print(new)
  # 실적 1,2등 구분을 하기 위한 count 변수
  count = 0
  # 평균 실적으로 구분
  for i, (name,rank) in enumerate(new.items()):
    # 조건3 - 보너스 대상자 평균 실적이 5보다 크지 않으면 제외
    if rank > 5:
      count += 1
      # 조건1 - 평균 실적 1,2등만 보너스 대상자
      if count < 3:
        print("보너스 대상자",name,"i:",i)
    # 조건 2 - 예비 면담 대상자 평균 실적 5,6등
    # new의 길이는 6이라, i > 3, i의 인덱스 4(5등),5(6등) 면담 대상자
    elif i > (len(new)-3):
      print("면담 대상자",name,"i:",i)
      # 조건 4 - 면담 대상자 평균 실적 3보다 크면 면담 대상자 제외
      if rank > 3:
        print("면담 대상자 제외",name,"i:",i)
    else:
      print("해당 사항 없음",name,"i:",i)
# 이름
member_names = ["갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이"]
# 실적(12개월)
member_records = [[4,5,3,5,6,5,3,4,1,3,4,5],[2,3,4,3,1,2,0,3,2,5,7,2],
           [1,3,0,3,3,4,5,6,7,2,2,1],[3,2,9,2,3,5,6,6,4,6,9,9],
           [8,7,7,5,6,7,5,8,8,6,10,9],[7,8,4,9,5,10,3,3,2,2,1,3]]
sales_management(member_names, member_records)




#두번째 풀이
#value 정렬을 할 때 리스트 컴프리헨션을 업그레이드하셨습니다
#value 정렬이 까다로운데 위치를 바꿈으로서 편하게 하신 것 같습니다
#일단 두명씩 뽑고 조건에 맞지 않으면 제외하는 식으로 하셨습니다. 


member_names = ["갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이"]
member_records = [[4,5,3,5,6,5,3,4,1,3,4,5],[2,3,4,3,1,2,0,3,2,5,7,2],
           [1,3,0,3,3,4,5,6,7,2,2,1],[3,2,9,2,3,5,6,6,4,6,9,9],
           [8,7,7,5,6,7,5,8,8,6,10,9],[7,8,4,9,5,10,3,3,2,2,1,3]]
def sales_management(member_names, member_records) :
    #이름 - 실적 매칭
    match_dict = dict()
    for i in range(len(member_names)) :
        match_dict[member_names[i]] = member_records[i]
    #실적 평균
    for (k,v) in match_dict.items():
        sum = 0
        for j in v:
            sum = sum + j
        average = sum / len(v)
        match_dict[k] = average
    #print(match_dict)
    # 순위대로 정렬
    ranking = [ (v,k) for k,v in match_dict.items() ] #리스트 컴프리헨션 
    ranking = sorted(ranking, reverse=True)
    # 예비 보너스, 면담 대상자 선정
    bonus = (ranking[0][1], ranking[1][1])
    counsel = (ranking[4][1], ranking[5][1])
    # 조건 3 : 보너스 대상자의 평균 실적이 5보다 크지 않으면 보너스 대상자에서 제외
    for l in bonus:
        if match_dict[l] <= 5:
            continue
        print('보너스 보상자:', l)
    #조건 4 : 면담 대상자의 평균 실적이 3보다 크면 면담 대상자에서 제외
    for m in counsel:
        if match_dict[m] > 3:
            continue
        print('면담 대상자:', m)
sales_management(member_names, member_records)



#세번째 풀이 
#평균을 구할때 numpy 라이브러리를 활용했습니다.
#다만 오류가 발생되기도 해서 구글코랩에서 돌리기를 추천합니다.


member_names = ["갑돌이", "갑순이", "을돌이", "을순이", "병돌이", "병순이"]
member_records = [[4,5,3,5,6,5,3,4,1,3,4,5],[2,3,4,3,1,2,0,3,2,5,7,2], 
           [1,3,0,3,3,4,5,6,7,2,2,1],[3,2,9,2,3,5,6,6,4,6,9,9],
           [8,7,7,5,6,7,5,8,8,6,10,9],[7,8,4,9,5,10,3,3,2,2,1,3]]


import numpy as np

member_average = []
# [4.0, 2.8333333333333335, 3.0833333333333335, 5.333333333333333, 7.166666666666667, 4.75]
# 넘파이 모듈을 활용해 평균을 구하면 나오는 값입니다. 

for i in member_records:
    av = np.mean(i)
    member_average.append(av)

#print(member_average)

member = {}

if len(member_average) == len(member_names): #굳이 필요 없지만 혹시 누락되었다면 에러가 뜨기보다 안내가 프린트되도록 했습니다.
  num = len(member_names)
  for i in range(num):
    member[member_average[i]]=member_names[i]
else:
  print("멤버, 실적 리스트가 누락되었는지 확인해주세요.")


#print(member)

smember = sorted(member.items(), reverse = True)
print(smember)

bonus = []

for j in range(len(smember)):
  if float(smember[j][0]) >= 5: # 보너스 대상자의 평균 실적이 5보다 크지 않으면 보너스 대상자에서 제외된다는 조건3 
    bonus.append(smember[j])
  else: pass
  if len(bonus) ==2: #사실 제가 썼는데 이제 보니 경우를 조금 이상하게 나눈 것 같네요 두번째 풀이처럼 먼저 뽑고 제외하는 방식이 나았을 것 같습니다. 
    break

#print(bonus)

for k in range(len(bonus)):
  print(f"보너스 대상자: {bonus[k][1]}")

#print(f"보너스 대상자: {smember[0][1]}")
#print(f"보너스 대상자: {smember[1][1]}")

smember2 = sorted(member.items())
consult = []

for j in range(len(smember2)):
  if float(smember2[j][0]) < 3: # 면담 대상자의 평균 실적이 3보다 크면 면담 대상자에서 제외된다는 조건3 
    consult.append(smember2[j])
  else: pass
  if len(consult) ==2:
    break

for l in range(len(consult)):
  print(f"면담 대상자: {consult[l][1]}")





#3번
#📌Q3. 예금 금리가 너무 낮아서 주식을 시작했습니다. 아래와 같이 매수한 종목 이름, 수량, 매수 평균 금액이 있습니다. 
#판매가는 따로 주어집니다. 종목과 수익률만 출력하시고 종목별 수익률이 높은 순서대로 출력해주세요. (소수 둘째자리까지 출력)


#첫번째 풀이
#종목, 수익률, 투자금, 판매금, 손익금, 수익률 리스트를 각각 나누어서 만들고 인덱싱을 활용해서 문제를 푸셨습니다.



#투자금 계산방법
#매수평균금액 * 수량 = 투자금
#판매가 * 수량 = 판매금
#판매금 - 투자금 = 손익금
#(손익금 / 투자금) * 100 = 수익률
s_profit = dict() #종목, 수익률 리스트
invest_money = [] #투자금 리스트
sale_money = [] #판매금 리스트
profit_list = [] #손익금 리스트
prate_list = [] #수익률 리스트
def stock_profit(stocks, sells):
  # stocks 를 ","를 기준으로 나눠서 b 리스트에 넣음
  # temp용 리스트 b
  b = stocks.split(",")
  # b 리스트 길이 만큼 반복
  for i in range(len(b)):
    # b 리스트의 각 i번째 요소를 c 리스트에 넣음
    # temp용 리스트 c
    c = b[i].split("/")
    #c[0]:종목이름, c[1]:수량, c[2]: 매수가격
    # 투자금 계산
    invest = int(c[1]) * int(c[2])
    invest_money.append(invest)
    # 판매금 계산
    sale = int(sells[i]) * int(c[1])
    sale_money.append(sale)
    # 손익금 계산
    profit = sale_money[i] - invest_money[i]
    profit_list.append(profit)
    # 수익률 계산
    rate = (profit_list[i] / invest_money[i]) * 100
#    print(c[0],c[1],c[2])
#    print(f"g(수익률):{g:.3}")
#    print("투자금:",invest_money)
#    print("판매금:",sale_money)
#    print("손익금:",profit)
    # s_profit 리스트에 종목 이름, 수익률 추가
    s_profit[c[0]] = rate
#    print(s_profit)
  # 종목, 수익률만 있는 딕셔너리를 value값으로 역순 정렬 -> sorted_profit 리스트에 저장
  sorted_profit = sorted(s_profit.items(), key=lambda x: x[1],reverse=True)
#  print(sorted_profit) # 정렬된거 보여줌
  # 정렬된 리스트의 이름(key),수익률(value)값을 출력
  for name, pro in sorted_profit:
    print(f"{name}의 수익률 {pro:.3}")
#         종목이름/수량/매수평균금액
stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
# 판매가
sells = [82000,160000,835000,410000]
stock_profit(stocks, sells)




#두번째 풀이

#첫번째 풀이의 수익률 계산법을 활용해 풀었고 크게 다르지는 않습니다만, 
#수익률을 바로 계산해서 종목:수익률로 바로 딕셔너리에 추가했습니다.


#수익률 계산방법 
#수익률 = (손익금 / 투자금) * 100 
#손익금 = 판매금 - 투자금 
#   판매금 = 판매가 * 수량
#투자금 = 매수평균금액 * 수량 

stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000] #매수평균금액

def stock_profit(stocks, sells):
    stocksplit = stocks.split(",")
    stocklist = []
    #print(stocksplit)

    for i in stocksplit:
        n = i.split("/")
        stocklist.append(n)
    
    #print(stocklist)

    finaldic = {}

    j = 0
    for i in stocklist:
        invest = int(i[2])*int(i[1])  #투자금 계산 
        proloss = (sells[j] * int(i[1])) - invest  #손익금 계산
        earn = (proloss/invest)*100 #수익률 
        earn = float(f"{earn:.3}")
        finaldic[earn] = i[0]
        j += 1 

    print(finaldic)
    
    sort_dic = sorted(finaldic.items(), reverse = True) 
    #첫번째 풀이의 람다 식도 구글링하다가 찾긴 했는데 제 컴퓨터에선 왠지 오류가 뜨길래, 
    #key, value 값을 반대로 넣어 key 값으로 정렬했습니다. 

    print(sort_dic)

    for i in sort_dic:
        print(f"{i[1]}의 수익률: {i[0]}")


stock_profit(stocks, sells)


#세번째 풀이 
#역시 크게 다르지는 않고 리스트, 튜플, 딕셔너리를 모두 잘 활용하셨습니다. 

stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]

def stock_profit(stocks, sells):

  div = stocks.split(',') 
  companies = []
  name = []
  profit = []

  for i in div:
    com = i.split('/')
    companies.append(com)
  
  for i in companies:
    name.append(i[0])

  for i, j in zip(sells, companies):
    p = ((i - int(j[2]))/int(j[2]))*100
    profit.append(p)
  
  com_profit = { name:value for name, value in zip(name, profit) }
  target = sorted(com_profit.items(), key=lambda x: x[1], reverse=True)

  for i in target:
    print(i[0]+"의 수익률 " + f"{i[1]:.3}")

stock_profit(stocks, sells)





#4 
#📌Q4. 여러분은 어떤 상품을 판매하고 있습니다. 매월 상품을 많이 구매해준 VIP회원에게 할인 쿠폰을 제공해주려고 합니다. 아래와 같은 회원 정보가 있을 때 회원 정보를 출력하고 할인 쿠폰을 받을 회원이 누구인지 출력하는 함수를 만들어 주세요.
#😲조건1 - 8회 이상 구매한 회원이 VIP대상
#😲조건2 - 전화번호가 없으면 쿠폰을 받을 수 없음
#😲조건3 - 전화번호가 없으면 000-0000-0000으로 출력할 것


#첫번째 풀이 
#아이디, 나이, 폰번호, 성별, 지역, 구매횟수를 각각 리스트로 넣은 후에 딕셔너리에
#아이디: [1,2,3,4,5,6], 나이: [1,2,3,4,5,6] , .. 
#이런 식으로 넣으신 후 인덱싱을 활용하셨습니다. 


# 빈 딕셔너리 생성
customer_info = {}
# 빈 리스트들 생성
id = []
age = []
phone = []
gender = []
area = []
buy_count = []
coupon = []
def good_customer(info):
  # info를 ","로 나눠서 info_list[리스트]에 저장
  info_list = info.split(",")
#  print(info_list)
  for i in range(len(info_list)):
#    print("i:",i)
    if (i % 6) == 0: #딱 6개씩 나뉘기 때문에 나머지를 활용하셨습니다. 
      id.append(info_list[i])
#      print("i % 6 == 0 [temp]",id)
    elif (i % 6) == 1:
      age.append(info_list[i])
#      print("i % 6 == 1 [temp]",age)
    elif (i % 6) == 2:
      # 조건3 - 전화번호가 없으면 000-0000-0000으로 출력
      if info_list[i] == 'x':
        info_list[i] = '000-0000-0000'
      phone.append(info_list[i])
#      print("i % 6 == 2 [temp]",phone)
    elif (i % 6) == 3:
      gender.append(info_list[i])
#      print("i % 6 == 3 [temp]",gender)
    elif (i % 6) == 4:
      area.append(info_list[i])
#      print("i % 6 == 4 [temp]",area)
    elif (i % 6) == 5:
      buy_count.append(int(info_list[i]))
#      print("i % 6 == 5 [temp]",buy_count)
      # 조건1 - 8회 이상 구매하고 전화번호가 있으면 쿠폰을 받을 수 있음
      if (int(info_list[i]) >= 8) and (info_list[i-3] != '000-0000-0000'):
        coupon.append(1)
      # 조건2 - 전화번호가 없으면 쿠폰을 받을 수 없음
      else:
        coupon.append(0)
  # 각각의 키값에 value에 해당하는 리스트들을 넣어줌
  customer_info['아이디'] = id
  customer_info['나이'] = age
  customer_info['전화번호'] = phone
  customer_info['성별'] = gender
  customer_info['지역'] = area
  customer_info['구매횟수'] = buy_count
  print(customer_info)
  for k in range(6):
    if coupon[k] == 1:
      print("할인 쿠폰을 받을 회원정보",end=" ")
      for j in customer_info.keys():
        print(f"{j}:{customer_info[j][k]}",end=",")
# 6명의 회원이고 "아이디,나이,전화번호,성별,지역,구매횟수" 순서로 입력되어 있음
info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"
good_customer(info)



#두번째 풀이
# 아직 딕셔너리가 손에 안 익어서 리스트로 우선 해보셨다고 합니다. 
# 출력해야 하는 회원의 인덱스를 저장한 후에 그 인덱스를 활용하셨습니다. 
# 6명의 회원이고 "아이디,나이,전화번호,성별,지역,구매횟수" 순서로 입력되어 있습니다 
info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"
info = info.split(',')
id = []
age = []
tel = []
sex = []
reside = []
buy = []
index = [] # 조건 2를 위해 전화번호가 없는 회원 인덱스 저장
count = [] # 조건 3을 위해 구매횟수가 8회 이상인 회원 인덱스 저장
result = [] # 조건 2, 3을 모두 만족하는 회원 인덱스 저장
def coupon(info):
    for i in range(len(info)): #역시 나머지를 활용하셨습니다 
        if i % 6 == 0:
            id.append(info[i])
        elif i % 6 == 1:
            age.append(info[i])
        elif i % 6 == 2:
            tel.append(info[i])
        elif i % 6 == 3:
            sex.append(info[i])
        elif i % 6 == 4:
            reside.append(info[i])
        elif i % 6 == 5:
            buy.append(info[i])
    for j in range(len(tel)):
        if tel[j] == 'x':
            index.append(j)
            tel[j] = '000-0000-0000'
        if int(buy[j]) >= 8:
            count.append(j)
    for k in count:
        if k not in index:
            result.append(k)
    for l in result:
        print('할인 쿠폰을 받을 회원정보 아이디:',id[l],'나이:',age[l],'전화번호:',tel[l],'성별:',sex[j],'지역:',reside[l],'구매횟수:',buy[l])
print(info)
coupon(info)




#세번쨰 풀이


info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"
#infolist=info.split(",")
#print(len(infolist))

#infolist[1:6]

def good_customer(info):
    infolist = info.split(",")
    infodic = {}
    #print(infolist)
    i = 0
    while True: #아이디를 제외하고 나머지를 모두 리스트로 묶어 아이디: 나머지 정보 리스트 로 딕셔너리에 저장되도록 했습니다. 
        infodic[infolist[i]] = infolist[i+1:i+6] 
        i += 6
        if i >= len(infolist):
            break
    #print("확인용",infodic)

    viplist = {} #구매횟수가 8 이상인 모든 회원을 모았습니다. 
    for k in infodic:
        if int(infodic[k][4]) >= 8:
            viplist[k] = infodic[k]
    print(viplist)

    couponlist = {} #쿠폰을 수령할 최종 회원 딕셔너리를 작성했습니다. 
    faillist = {} #구매횟수가 8 이상인 회원이면서 전화번호가 누락된 회원 딕셔너리를 작성했습니다. 
    for j in viplist:
        if viplist[j][1] == "x":
            faillist[j] = [viplist[j][0],"000-0000-0000",viplist[j][2],viplist[j][3],viplist[j][4]]
        else: couponlist[j] = viplist[j]
    
    print(couponlist) #확인용
    #print(faillist) #확인용

    for k in couponlist:
        print(f"할인쿠폰을 받을 회원정보 아이디: {k}, 나이:{couponlist[k][0]}, 전화번호:{couponlist[k][1]}, 성별:{couponlist[k][2]}, 지역:{couponlist[k][3]}, 구매횟수: {couponlist[k][4]}")

print(good_customer(info))