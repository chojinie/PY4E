def find_good_customer(info):
    #모든 정보가 구분없이 ','로 구별되어 있으므로 ','로 정보를 나눠 리스트로 저장
    info_li = list(info.split(','))
    #딕셔너리 선언. 아이디,나이,전화번호,성별,지역,구매횟수를 '키'로 저장할 예정
    dict = {}
    #인원과 정보가 각각 6이라는 것이 주어졌으므로, 순서에 맞게 딕셔너리에 저장한다.
    """
    예를 들어, 아이디,나이,전화번호,성별,지역,구매횟수 순으로 저장되어 있으므로
    딕셔너리에 저장할 때 아이디의 리스트값은 첫 원소,첫원소+6,첫원소+12,.. 로 저장하면 아이디만 담기게 된다.
    """
    dict['아이디'] = [info_li [i*6] for i in range(6)]
    dict['나이'] = [info_li [i*6+1] for i in range(6)]
    dict['전화번호'] = [info_li [i*6+2] for i in range(6)]
    dict['성별'] = [info_li [i*6+3] for i in range(6)]
    dict['지역'] = [info_li [i*6+4] for i in range(6)]
    dict['구매횟수'] = [info_li [i*6+5] for i in range(6)]

    #딕셔너리 결과 출력
    print(dict)

    #6명의 정보를 순회
    for i in range(6):
        #만약 구매횟수의 i번째가 8 이상. 그리고 전화번호의 i번째가 'x'가 아니라면(번호가 있다면)
        if int(dict['구매횟수'][i])>=8 and dict['전화번호'][i]!='x':
            #결과를 출력하기 위해 앞 대사를 미리 입력하고
            ans = '할인 쿠폰을 받을 회원정보 '
            #딕셔너리를 돌면서
            for key,value in dict.items():
                # 입력한 대사에 회원 정보를 추가한다.
                ans+=f"{key}:{value[i]},"
            #결과 출력. 맨 마지막에 ','가 붙어있어서 마지막을 제외한 부분을 출력한다.
            print(ans[:-1])






info = "abc,21세,010-1234-5678,남자,서울,5,cdb,25세,x,남자,서울,4,bbc,30세,010-2222-3333,여자,서울,3,ccb,29세,x,여자,경기,9,dab,26세,x,남자,인천,8,aab,23세,010-3333-1111,여자,경기,10"

find_good_customer(info)