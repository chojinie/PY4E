#각각의 주식, 판 가격을 받아서 수익률을 출력하는 함수
def revenue_list(stocks,sells):
    revenue_dict = {}
    #주식당 정보다 ','로 구별되어 있으므로 split()을 이용해 분별한다
    stock = list(stocks.split(','))
    #분별된 정보를 순회한다
    for i in stock:
        #분별된 정보는 '/'로 구별되어 있다. 구별된 순으로 이름,주 수, 주가 이므로 맞게 변수로 저장한다
        name,cnt,price = i.split('/')
        #판 가격순서와 정보순서가 일치하므로 sells의 첫 가격을 현재 주식의 판 가격으로 받는다.
        # 받을때는 pop()으로 받는다. 그래야 다음 반복문의 첫 가격과 정보 순서가 맞게된다.
        sell = sells.pop(0)

        # revenue_dict에 저장. 키 = 회사이름, 값 = 수익률       수익률 = (판 가격- 산 가격) / 산 가격) *100
        revenue_dict[name] = (sell-int(price))/int(price)*100

    """
        *람다정렬 요약*
     sorted(dict.items(),key=lambda x: x[1],reverse=True) 를 순서대로 해석해보면,
     sorted()는 괄호 안 내용을 리스트로 반환해주고
     dict.items(), 즉 (키,값) 튜플을 원소로 가지는 리스트를 new_list로 반환한다
     뒤에 'key=기준'을 추가해주면 기준에 따라 정렬해주는데
     key = lambda x: x[0] 를 해주면 키를 기준으로, key = lambda x: x[1] 을 해주면 값을 기준으로 정렬해준다
     지금은 정렬해 줄 원소가 (키,값) 이므로 x[0]=키, x[1]=값 이 된다.
    """
    
    #람다정렬로 수익률(값) 이 높은 순으로 정렬하여 반복문을 돈다
    for name,revenue in sorted(revenue_dict.items(), key = lambda x: x[1], reverse= True):
        #결과 출력
        print(f"{name}의 수익률 {revenue:.3}")




stocks = "삼성전자/10/85000,카카오/15/130000,LG화학/3/820000,NAVER/5/420000"
sells = [82000, 160000, 835000, 410000]

revenue_list(stocks,sells)