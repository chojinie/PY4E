#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
📌Q1. 여러분 혹시 베스킨라빈스31 게임을 아시나요? 1부터 31까지 숫자를 플레이어들끼리 번갈아 외치다가 31을 외치는 사람이 패배하는 게임인데요.
이번엔 이 게임을 파이썬 함수로 만들어 봅시다. 지성이 없이 숫자를 랜덤하게 외치는 컴퓨터와 대결을 해보겠습니다.
😲조건1 - 나의 턴에서는 숫자를 직접 입력하며 한 번 입력 후에 space 한 번으로 구분

Ex)
my = input("My turn - 숫자를 입력하세요: ")
1 2 3
😲조건2 - 나와 컴퓨터 모두 한 턴에 1회 ~ 3회까지만 숫자를 외칠 수 있음
😲조건3 - 외쳐진 숫자보다 1큰 수만 외칠수 있음 (ex: 5 다음엔 무조건 6)
위 조건이 안맞을 경우 다시 입력
🧐hint

# 컴퓨터가 1~3회 중에서 몇 번을 시도할 것인지 랜덤하게 고르는 방법
import random
computer_turn_num = random.randint(1,3)

# 첫번째를 나타내는 인덱스 0, 마지막을 나타내는 인덱스 -1
example = [1,2,3]
print(example[0]) # 1
print(example[-1] # 3

✅출력 예시
bs31()

베스킨라빈스 써리원 게임
------------------
My turn - 숫자를 입력하세요: 1 2 3
현재 숫자 : 3
컴퓨터 : 4
현재 숫자 : 4

My turn - 숫자를 입력하세요: 5
현재 숫자 : 5
컴퓨터 : 6
컴퓨터 : 7
현재 숫자 : 7
"""

def baskin_31():
    import random
    total = 0                                                           # 전체 코드를 관통하는 기준 수(변수)를 지정해주는 작업.
    while True :                                                        # while True로 시작하는 경우, 그 값이 참일때는 계속 반복함.
        my_turn_num = input("My turn - 숫자를 입력하세요 (숫자간 띄워쓰기로 구분) : ")              # 숫자를 입력(input은 입력된 값을 str형으로 저장함)
        my_turn_num = my_turn_num.split()                               # 입력된 숫자를 str형에서 리스트로 변환. 단, 이때 split을 빈칸으로 둘 경우 띄어쓰기를 기준으로 나눔
        # 아래의 if절 3개는 오류가 없을 경우, 알고리즘에 포함되지 않고 계산됨.
        # 전 숫자 대비 1차이가 나지 않거나, 숫자 개수가 4개 이상인 경우를 점검
        if int(my_turn_num[0]) != total+1 or len(my_turn_num) > 3 :     # 리스트 내 문자열을 슬라이싱 후, int형으로 변환하여 계산.
            print("숫자를 다시 확인해주세요.")
            continue                                                    # if절에 걸린 경우, if절을 수행한 후 continue로 다시 while문 처음으로 돌아감.
        # 숫자가 2개이나, 연속되지 않은 경우를 점검
        if len(my_turn_num) == 2 :
            if int(my_turn_num[1]) - int(my_turn_num[0]) != 1:
                print("연속되지 않은 2개의 숫자입니다. 다시 입력해주세요.")
                continue                                                # if절에 걸린 경우, if절을 수행한 후 continue로 다시 while문 처음으로 돌아감.
        # 숫자가 3개이나, 연속되지 않은 경우를 점검
        if len(my_turn_num) == 3:
            if int(my_turn_num[2]) - int(my_turn_num[1]) != 1 or int(my_turn_num[1]) - int(my_turn_num[0]) != 1:
                print("연속되지 않은 3개의 숫자입니다. 다시 입력해주세요.")
                continue                                                # if절에 걸린 경우, if절을 수행한 후 continue로 다시 while문 처음으로 돌아감.

        total = int(my_turn_num[-1])                                    # total 변수에 입력한 수의 가장 마지막 수를 int형으로 변환 후 슬라이싱하여 지정함.
        print(f'현재숫자 : {total}')
        # 사람이 패배하는 조건을 추가함
        if total >= 31:
            print("패배")
            break                                                       # break문은 continue와 달리 해당 조건에 해당되는 경우 while 문을 깨고 종료시킴.

        computer = []                                                   # computer는 처음에는 빈 리스트를 지정함.(사람과 달리 입력된 모든 값을 리스트로 저장하기 위함)
        computer_turn_num = random.randint(1,3)                         # random으로 나오는 숫자를 받음
        for i in range(computer_turn_num):                              # 해당 숫자만큼을 range로 반복하여 '+1' 방식으로 진행(만일 리스트로 저장하지 않는다면 굳이 쓸 필요 없이 사람이 입력한 total값에 더하는 방식으로 가도 될 듯)
            total += 1
            # 만일 연산 중 컴퓨터가 31을 넘어갈 경우
            if total > 31:
                total -= 1                                              # 31을 넘어가는 숫자가 나올 경우(여기서는 32), 해당 숫자에서 1을 빼고 for문을 반복함.
                continue
            computer.append(total)                                      # for문이 종료되고 나서 마지막 total값을 computer 리스트에 더함.
            print(f'컴퓨터 : {computer[-1]}')
        print(f'현재숫자 : {total}')
        # 컴퓨터의 패배조건을 확인
        if 31 in computer:                                              # 만일, 컴퓨터가 가지고 있는 리스트에서 31이 있다면, 사람의 승리를 선언 후, break문을 통해 while문을 종료함.
            print("승리")
            break
    print("게임 종료")

print(baskin_31())


# In[ ]:


# Q2.(1)
#mission2
# 학생 답
s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315"]
# 정답지
a = [3,2,4,2,5,2,4,3,1,2]
s2 = list()
s3 = list()
name = list()
for k in range(0,5):
    s1 = s[k].split(',')
    print('s1은',s1)
    s2.append(s1)
    s3.append(s1[1])
    name.append(s1[0])
    #print(s3)
kim = s3[0]
lee = s3[1]
park = s3[2]
chu = s3[3]
jung = s3[4]
kim_1 = list()
K = 0
lee_1 = list()
L = 0
park_1 = list()
P = 0
chu_1 = list()
C = 0
jung_1 = list()
J = 0
for j in range(0,10):
    kim_1.append(kim[j])
    lee_1.append(lee[j])
    park_1.append(park[j])
    chu_1.append(chu[j])
    jung_1.append(jung[j])
    
for l in range(0,10):    
    if int(kim_1[l]) == a[l]:
        K = K + 10
    if int(lee_1[l]) == a[l]:
        L = L + 10
    if int(park_1[l]) == a[l]:
        P = P + 10
    if int(chu_1[l]) == a[l]:
        C = C + 10
    if int(jung_1[l]) == a[l]:
        J = J + 10
    else:
        continue
sco = [str(K),str(L),str(P),str(C),str(J)]
print(sco)
sco.sort(reverse=True)
print(sco)
score = [K,L,P,C,J]
print(score)
score.sort(reverse=True)
print(score)
total = [[K,name[0]],[L,name[1]],[P,name[2]],[C,name[3]],[J,name[4]]]
total.sort(reverse=True)
print(total)
for h in range(0,5):
    tt = total[h]
    print('학생:',tt[1],',','점수:',tt[0],'점,', h+1,'등')
#print(s2)


# In[ ]:


# Q2.(2)
# 학생 답
s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315"]
# 정답지
a = [3,2,4,2,5,2,4,3,1,2]
def grader(student, answers):
    name = [] # 이름을 분리하여 저장할 빈 리스트
    answer = [] # 학생들의 답을 분리하여 저장할 빈 리스트
    scores = [] # 채점후 점수를 저장할 빈 리스트
    for s in student:         # grader() 함수 호출시 student 매개 변수 자리에 전역변수 s의 값들(list로 저장되어 있음)이 들어 온 것을 for문으로 돌림
        s = s.split(",") # ','를 분리 기호로 사용, ','를 기준으로 이름과 정답지로 분리
        name.append(s[0])     # 반복 변수 s로 받아온 전역 변수의 값 중 ',' 앞의 값이 index 0이 되어 name 리스트에 추가 된다.
        # name = ['김갑', '이을', '박병', '최정', '정무' ]
        answer.append(s[1])   # 반복 변수 s로 받아온 전역 변수의 값 중 ',' 앞의 값이 index 1이 되어 answer 리스트에 추가 된다.
        # answer = ['3242524215', '3242524223', '2242554131', '4245242315', '3242524315']
    score = 0
# 점수 계산
# 한 명씩 점수 계산, 답지와 내답이 같으면 10점 추가, 10문제라서 문제당 10점
    for a in answer:      # answer에 저장된 리스트의 값들을 하나 씩 a에 넣어줌
        for i in range(len(a)):# len(a) = 10, 따라서 range(len(a)) = range(10) => [0,1,2,3,4,5,6,7,8,9]이므로 i에 0부터 9까지(10문제) 넣어줌
            if int(a[i]) == answers[i]: #학생들의 입력값과 정답지의 답안 비교
            # a[i] = a[0] ~ a[9] : 학생들의 입력 답안
            # answers[i] : 정답지의 답안
                score = score + 10    # 학생들의 입력값과 정답지의 답안이 일치하면 10점 추가
        scores.append(score)    # scores 리스트에 score 값을 추가
        score = 0   # 다음 학생의 점수를 구하기 위해 score를 0으로 리셋
# 이름과 점수를 결합
    for i in range(len(name)):
        # len(name) : name에 들어 있는 리스트의 인덱스를 구함 => 학생의 수 확인 가능
        # range(len(name)) : 0부터 (학생의수-1)만큼의 수까지 범위 지정
        name[i] = str(scores[i])+name[i]
        # 0번 인덱스 값부터 마지막 인덱스 값까지의 점수와 이름을 해당 인덱스의 name 리스트에 문자열로 저장
# 점수 기준 내림차순 정렬
    name.sort(reverse=True) # reverse=False : 올림차순 정렬
# 한 사람씩 출력
    for i in range(len(name)):
        print(f"학생: {name[i][2:]} 점수: {name[i][:2]}점 {i+1}등")
# 함수 호출하여 실행하기
grader(s, a)  # 매개변수 값에 전역변수인 s와 a를 넣어줌


# In[ ]:


# Q3.
import random
def find_number():
    computer_number_list = []
    count_player_number = 0
    list_player_number = [0,0,0]
    log_player_number = []
    while True:
        computer = random.randint(0 , 100)
        computer_number_list.append(computer)
        if(len(computer_number_list) == 3):
            break
    computer_number_list.sort()
    print(computer_number_list)
    while True:
        count_player_number += 1
        print(count_player_number,"차 시도")
        while True:
            player_number = int(input("숫자를 예측해 보세요 :"))
            if player_number in log_player_number:
                print("중복입니다.")
            else:
                log_player_number.append(player_number)
                break


        if(player_number != int(computer_number_list[0]) and player_number != int(computer_number_list[1]) and player_number != int(computer_number_list[2])):
            print(player_number,"는 없습니다.")
        if(count_player_number == 5 or count_player_number == 10):
            if(int(computer_number_list[0]>player_number)):
                print("최솟값은 ",player_number,"보다 작습니다.")
            elif(player_number>int(computer_number_list[0]) and player_number<int(computer_number_list[1])):
                print(player_number,"은 최솟값과 중간값 사이입니다.")
            elif(player_number>int(computer_number_list[1]) and player_number<int(computer_number_list[2])):
                print(player_number,"은 중간값과 최고값 사이입니다.")
            elif(player_number>int(computer_number_list[2])):
                print(player_number,"은 최고값 보다 큽니다.")
        if(player_number == int(computer_number_list[0])):
            print("숫자를 맞추셨습니다!",player_number,"는 최솟값입니다.")
        elif(player_number == int(computer_number_list[1])):
            print("숫자를 맞추셨습니다!",player_number,"는 최솟값입니다.")
        elif(player_number == int(computer_number_list[2])):
            print("숫자를 맞추셨습니다!",player_number,"는 최댓값입니다.")

if __name__ == "__main__":
    find_number()


# In[ ]:


# Q4.
# 주어진 날짜로 부터 100일 후 날짜 구하는 함수 만들기
def after_100(month, date, day):
    dates = [31,28,31,30,31,30,31,31,30,31,30,31]       # 각달의 최대 날짜 값을 리스트에 넣어 dates에 담는다.
    days = ["월요일","화요일","수요일","목요일","금요일","토요일","일요일"]             # 각 요일을 리스트에 넣어 days에 담는다.
    after = 100                                         # 100일 후를 받을 변수 after의 초기값을 100으로 할당
# 파이썬 index는 0부터 시작하기 때문에 월 -1
    index = month-1                                     # month : 매개변수로 입력 받는 값 => 1 ~ 12 : index의 첫 자리는 0이기 때문에 '-1'을 해야 함, 따라서 index는 0부터 11가지의 값을 가질 수 있음
    while True:                                         # while문 반복을 통해 after가 음수가 나올 때 while문을 벗어 나며, 마지막으로 저장된 값을 index에 담아 dates[index]에 사용하여 '월'을 확인할 수 있다.
                                                        # ex) 8월을 선택할 경우 index는 7부터 시작하여 10을 끝으로 while문을 벗어나기 때문에 dates[10]은 11월이 된다.
        after = after - dates[index]                    # after = 100, dates[index] = dates[0] ~ dates[11] => [31, 28,......,31]
        if after < 0:                                   # after가 음수가 되면 while문 탈출
            break
        index = index + 1
        if index == 12:                                 # index 값이 12가 되면 다시 0으로 되돌리기 : 12월에서 1월로 가기
            index = 0
    # ---------------------------------------------------------------------------------------------------------------
    print('after :',after)          # while문을 벗어난 후 after값 확인
    # ---------------------------------------------------------------------------------------------------------------
    date_after_100 = after + dates[index] + date -1
        # date_after_100 = (after-dates) + dates[index] + date -1
        # ex) 8월 17일 입력
        # after = -22, index = 10
        # date = after_100() 함수 호출 시 입력한 날짜 매개 변수 값 = 17
        # -1 : 현재일 수(17일)을 더하고 또 오늘(1일)을 포함하기 때문에 '-1' 값 연산이 필요
        # date_after_100 = -22 + dates[10] + 17 -1 = -22 + 30 + 17 -1 = 24
    # ---------------------------------------------------------------------------------------------------------------
    print('date_after_100 :',date_after_100)          # 100일 후 날짜값(date_after_100)이 제대로 찍히는 지 확인
    # ---------------------------------------------------------------------------------------------------------------
    # 만약 일수가 30일, 31일을 넘어가면 100일 후의 월의 일수를 빼주고 월 +1 추가
    if date_after_100 > dates[index]:       # 위에서 구한 day_after_100 값이 28, 30, 31 보다 클때
        date_after_100 = date_after_100 - dates[index]
        index = index + 1
    # 요일 구하기
    day_index = days.index(day)
        # day : after_100() 함수의 day 매개 변수 값
        # days.index(day) : days 리스트에 포함 된 요일 값의 인덱스 위치
        # ex) '월'요일의 경우 : day_index = day.index(day) = 0
    day_index2 = day_index + 100 % 7 -1
        # 요일은 7로 나눈 나머지 만큼 움직이면 됨, 오늘을 포함하기 때문에 -1
        # ex) '월'요일의 경우 : day_index = day.index(day) = 0
        # ex) day_index2 = 0 + 100 % 7 -1 = 0 + 2 -1 = 1
    if day_index2 > (len(days) -1):
        # 일요일(index[6]) 다음은 다시 월요일(index[0])로 돌아감
        # len(days) = 7
        day_index2 = day_index2 - (len(days) -1) -1
            # ex) '일'요일의 경우 : day_index2 = 6 + 100%7 -1 = 6 + 2 - 1 = 7
            # day_index2 = day_index2 - (len(days) -1) -1 = 7 - (7 - 1) -1 = 0
            # day_index2 = 0 => dates[0] = '월'
    day_after_100 = days[day_index2]
        # ex) after_a00(11, 21, '월') --> day_index2 = 1
        # days[day_index2] = days[1] = '화'
    print(f"{month}월 {date}일 {day}요일부터 100일 뒤는 {index+1}월 {date_after_100}일 {day_after_100}요일")
print('============================ 100일 후 날짜 찾기 ============================')
print('오늘 부터 100일 후 기념일을 알고 싶으면 오늘의 날짜를 입력하세요. ')
m = int(input('몇월인가요? : '))
d = int(input('몇일인가요? : '))
w = input('무슨 요일인가요? : ')
# months = range(1, 12)
# days = range(1,31)
# weeks = ["월요일","화요일","수요일","목요일","금요일","토요일","일요일"]
after_100(m, d, w)

