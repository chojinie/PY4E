#jane_09team 5주차 미션

#이번 미션은 팀원들이 대체로 어려워해서 많이 들어오진 않았지만 최대한 취합해보았습니다.

#1

#Q1. 여러분 혹시 베스킨라빈스31 게임을 아시나요? 1부터 31까지 숫자를 플레이어들끼리 번갈아 외치다가 31을 외치는 사람이 패배하는 게임인데요.
#이번엔 이 게임을 파이썬 함수로 만들어 봅시다. 지성이 없이 숫자를 랜덤하게 외치는 컴퓨터와 대결을 해보겠습니다.
#조건1 - 나의 턴에서는 숫자를 직접 입력하며 한 번 입력 후에 space 한 번으로 구분
#Ex)
#my = input("My turn - 숫자를 입력하세요: ")
#1 2 3


#조건2 - 나와 컴퓨터 모두 한 턴에 1회 ~ 3회까지만 숫자를 외칠 수 있음
#조건3 - 외쳐진 숫자보다 1큰 수만 외칠수 있음 (ex: 5 다음엔 무조건 6)
#위 조건이 안맞을 경우 다시 입력


#두 코드가 큰 차이는 없고 31이 걸리는 기준만 조금 다릅니다.
#첫번째 코드는 리스트의 길이가 30을 초과하는 순간 지는 것으로 해놓았고,
#두번째 코드는 31을 외치면 지는 것으로 설정했습니다.


#첫번째 코드 


import random
def game31():
  num = []
  tmp = []
  k = 0 #현재 숫자를 나타냄
  while(True):
    computer_turn_num = random.randint(1,3)
    my_turn_num = input('My turn - 숫자를 입력하세요: ')
    print("")
    num = my_turn_num.split()
    #문자열을 정수로 변환
    num = [int(item) for item in num]
    #입력한 숫자가 현재 숫자보다 작거나 2이상 크게 입력시 다시 입력
    if(k > num[0] or (k+1) < num[0]):
      print('다시 입력하세요')
      continue;
    else:
      #플레이어가 입력한 숫자를 tmp 리스트에 병합
      tmp = tmp + num
      #플레이어가 31 입력시 컴퓨터 승리
    if(len(tmp) > 30): 
      print('컴퓨터 승리!')
      break;
    else:
      print('현재 숫자:',len(tmp))
      print("")
      print('컴퓨터: ',end = "")
      #컴퓨터가 입력한 숫자를 tmp 리스트에 추가
      for i in range(computer_turn_num):
        j = len(tmp) + 1
        #컴퓨터가 31 입력시 플레이어 승리
        if(j > 30):
          print(j, end = "\n")
          print('플레이어 승리!')
          break;
        else:
          tmp.append(j)
          print(j ,end = " ")
      #현재 숫자를 k에 저장
      k = j
      print('\n')
      if(j < 31):
        print('현재 숫자:',j)
    print('')
    #j(현재숫자)가 31 나오면 반복문 종료
    if(j > 30):
      break;
#31을 입력하면 패배하는 게임
print('베스킨라빈스 써리원 게임')
print('ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ')
game31()



#다른 코드

def bs31():
    print("베스킨라빈스 써리원 게임")
    print("------------------")
    import random
    n = 0
    turn = 1 # 홀수는 사용자의 차례, 짝수는 컴퓨터의 차례가 되도록 할것입니다.
    game = []
    while True:
        if turn%2 ==1:
            my = input(f"My turn - 숫자를 입력하세요: {n+1}부터 입력")
            mywait = my.split() #잘 입력했는지 점검하기 위한 임시 리스트입니다.
            if "31" in mywait:
                print("당신은 졌습니다.")
                break
            #print(mywait) 내가 외치는 숫자 리스트가 잘 모아졌는지 확인
            if 1<= len(mywait) < 4 and int(mywait[0]) == n+1:
                game.extend(mywait)
                print("나의 입력:", game[n:])
                n = int(game[-1])
                #print("현재 n = ",n) n이 잘 지정됐는지 확인
                turn +=1 #오류가 없으니 다음 턴으로 넘기는 차례입니다
                #print(game)
                continue
            else:
                print(f"다시 입력해주세요. {n+1}부터 시작이고 숫자 3개까지 가능합니다.")
            
           
        elif turn%2 ==0:
            import random 
            computer_turn_num = random.randint(1,3)
            for i in range(1,computer_turn_num+1):
                game.append(str(n+i))
            print("컴퓨터의 입력: ",game[n:])
            if "31" in game: 
                print("당신이 이겼습니다.")
                break
            n = int(game[-1])
            #print(game)
            turn +=1 #오류가 없으니 다음 턴으로 넘기는 차례입니다
            continue 
        
bs31()







# 2

#Q2. 다음과 같이 학생들의 시험 답지가 있습니다. 그리고 답안지도 있습니다.
#함수를 하나 만들어 채점을 하고 학생들의 점수를 출력하고 등수도 함께 출력해주세요.

#세 종류의 코드가 들어왔는데, 어려워하신 분들은 오름차순을 어떤 식으로 활용할지 고민하셨습니다.
#첫번째 코드는 채점까지는 완료했고 오름차순까지는 힘들어하셨습니다. 

def grading(s,a):
    sao = [] #학생 답안
    name = [] #학생 이름
    for i in range(len(s)) :
        each = s[i]
        slice = each.split(',')
        n = slice[0]
        name.append(n)
        sa = slice[1]
        sao.append(sa)
    score = []
    for j in sao :
        point = 0
        for k in range(len(j)):
            if int(j[k]) == int(a[k]) :
                point = point + 10
        score.append(point)
    for l in range(len(score)):
        print('학생:', name[l], '점수:', score[l])
s = ["김갑,3242524215", "이을,3242524223", "박병,2242554131", "최정,4245242315", "정무,3242524315"]
a = [3,2,4,2,5,2,4,3,1,2]
grading(s,a) #이 상태로 프린트하면 오름차순까지는 안나오고 학생별로 채점결과까지는 나옵니다. 


#두번째 코드
#리스트만 이용했고 오름차순까지는 성공한 코드입니다.


def grader(s,a):
  sa = []
  p = []
  for i in range(5):
    score = 0
    sa = s[i].split(',')
    #정답만 num 리스트에 넣음
    num = sa[1]
    #문자열 정수로 변환
    num = [int(item) for item in num]
    #정답 맞추기
    for k in range(10):
      if(num[k] == a[k]):
        score = score + 10
      sa[1] = score #리스트가 리스트에 들어가기 때문에 점수가 됩니다.
    #[이름, 점수] 를 하나의 요소로 p 리스트에 추가하는 과정
    p.append(sa)
    #print("sa확인",sa) 잘 들어갔나 확인하는 과정입니다.
    #내림차순 정렬
    p.sort(key=lambda k:k[1], reverse = True)
    #print("p확인",p) 잘 들어갔나 확인하는 과정입니다.

  #출력
  for k in range(5):
    print('학생:',p[k][0],'점수:',p[k][1],'점',k+1,'등')
#학생 답
s = ["김갑,3242524215", "이을,3242524223", "박병,2242554131", "최정,4245242315", "정무,3242524315"]
#정답지
a = [3,2,4,2,5,2,4,3,1,2]
grader(s,a)


#세번째 코드
#제(리드부스터) 코드인데 사실 그렇게 마음에 들지는 않습니다. 
#아직 안 배운 딕셔너리를 사용하기도 했기 때문인게 가장 큽니다. 

def graders(s,a):
    sol = [] 
    for i in s:
        comma = i.find(",")
        ii= i[comma+1:]
        sol.append(ii)
    #print(sol) 학생이 제출한 숫자만 나오게 다시 만드는 리스트
    #사실 이걸 굳이 할 필요는 없었던 것 같아서 조금 아쉽습니다. 

    result = [] #채점결과를 보기 위한 리스트 

    #정오표
    #굳이 필요하진 않았지만 채점 결과를 만드는 것도 해보았습니다. 
    for j in sol:
        answer = ""
        for ind in range(len(j)):
            if int(j[ind]) == int(a[ind]):
                answer+="O" #맞으면 O
            else:  
                answer+="X" #틀리면 X
        print(answer) #잘 채점이 됐는지 확인
        result.append(answer)
    #print(result) #채점 결과가 다 모아졌는지 확인 

    name = ["김갑", "이을", "박병", "최정", "정무"]
    i = 0
    final = {}
    for k in result:
        point = k.count("O")*10 #맞은 갯수를 세어보았습니다. ("O"의 갯수)
        final[point] = name[i]
        i += 1 

    
    dic = dict(sorted(final.items(), reverse = True))
    print(dic) #학생들의 점수(여기선 key) 기준으로 내림차순하고, 이름과 함께 딕셔너리로 잘 저장됐는지 확인 

    no = 1
    finalreturn = "" 
    for x in dic:
        finalreturn += f"학생: {dic[x]}, 점수: {x}점, {no}등 \n" 
        #바로 이걸 프린트해도 되는데 한방에 정리하고 싶어서 이렇게 텍스트로 정리했습니다. 
        no+=1

    return finalreturn

print(graders(s,a))


#3번

#Q3. 숫자 맞추기 게임을 만들어 볼게요. 컴퓨터가 임의의 숫자를 3개 만들고 우리가 그것을 맞춰보겠습니다.
#😲조건1 - 숫자는 0 ~ 100까지 숫자를 3개 만듭니다(중복 불가).
#😲조건2 - 5회, 10회까지 정답을 못맞추면 최솟값, 최대값에 대한 힌트를 줍니다.
#😲조건3 - 정답을 맞추면, 맞춘 정답이 최솟값인지, 중간값인지, 최댓값인지 알려줍니다.



#첫번째 코드는 이미 입력한 숫자는 제외하고 카운트되도록 짜여진 코드입니다.
#그 외에는 조건에 맞도록 코드를 짰습니다. 


import random
def guess_numbers():
  a = [] #컴퓨터 숫자 3개를 넣는 리스트
  b = [] #사용자가 입력한 숫자들을 넣는 리스트
  count = 0 #정답 횟수
  t = 0 #시도 횟수
  for i in range(3):
    number = random.randint(0, 100)
    a.append(number)
  a.sort()
  print('컴퓨터 숫자',a)
  while(True):
    #시도 횟수 증가
    t = t + 1
    print(t,'차 시도')
    myNum = int(input('숫자를 예측해보세요: '))
    if(myNum in b):
      print('이미 예측에 사용한 숫자입니다')
      t = t - 1
      continue
    #입력한 숫자를 b 리스트에 추가
    b.append(myNum)
    #숫자를 맞추면 정답과 최소, 중간, 최대를 표시, count가 3이 되면 게임 종료
    for j in range(3):
      if(myNum == a[0]):
        count = count + 1
        print('숫자를 맞추셨습니다!',a[0],'는 최솟값입니다.')
        break;
      elif(myNum == a[1]):
        count = count + 1
        print('숫자를 맞추셨습니다!',a[1],'는 중간값입니다.')
        break;
      elif(myNum == a[2]):
        count = count + 1
        print('숫자를 맞추셨습니다!',a[2],'는 최댓값입니다.')
        break;
    #5의 배수 시도 마다 못 맞추면 힌트 제공
    #수정본은 아니긴 하지만 elif 사용하면 위에 쓴 조건은 자동으로 삭제 된다는 것은 말씀드렸습니다!
    if((t % 5) == 0 and myNum not in a):
      print(myNum,'는 없습니다')
      if(myNum < a[0]):
        print('최솟값은',myNum,'보다 큽니다')
      elif(a[0] < myNum and a[1] > myNum):
        print('최솟값은',myNum,'보다 작습니다')
      elif(a[1] < myNum and a[2] > myNum):
        print('최댓값은',myNum,'보다 큽니다')
      elif(a[2] < myNum):
        print('최댓값은',myNum,'보다 작습니다')
    if(count == 3):
      print('게임종료')
      print(t,'번 시도만에 예측 성공')
      break;
#숫자 맞추기 게임
guess_numbers()





#두번째 코드는 10회일 때의 힌트까진 안 줬고 실제로 맞춰보기에 약간 어려운 난이도의 up&down 게임입니다.


def guess_numbers():
    import random
    numlis = []
    while len(numlis)<3:
        number = random.randint(0, 100)
        if number not in numlis:   
            numlis.append(number) #겹치지 않게 리스트에 추가되도록 하는 코드 
    numlis.sort()
    print("랜덤숫자는 ",numlis) #체크용 

    answer = 0
    trynum= 0
    correct = 0
    while correct<3: #3개 다 맞추면 꺼지는 루프 
        num_inp = int(input("숫자를 맞춰보세요!"))
        if num_inp == numlis[0]:
            print(f"숫자를 맞추셨습니다! {numlis[0]}는 최솟값입니다.")
            trynum +=1 
            correct +=1
        elif num_inp == numlis[1]:
            print(f"숫자를 맞추셨습니다! {numlis[1]}는 중앙값입니다.")
            trynum +=1 
            correct +=1
        elif num_inp == numlis[2]:
            print(f"숫자를 맞추셨습니다! {numlis[2]}는 최댓값입니다.")
            trynum +=1 
            correct +=1 
        else: 
            print("다시 입력해주세요.")
            trynum +=1
        if trynum > 5:
            if num_inp < numlis[0]: 
                print(f"입력하신 {num_inp}은 최솟값보다 작습니다.")
                trynum +=1
            elif num_inp < numlis[1]: 
                print(f"입력하신 {num_inp}은 최솟값보다 크고, 중앙값보다 작습니다.")
                trynum +=1 
            elif num_inp < numlis[2]: 
                print(f"입력하신 {num_inp}은 중앙값보다 크고, 최댓값보다 작습니다.")
                trynum +=1
            elif num_inp > numlis[2]: 
                print(f"입력하신 {num_inp}은 최댓값보다 큽니다.")

guess_numbers()




#4번
#Q4. 오늘 애인이 생겼다고 해봅시다. 100일을 기념하고 싶은데요.
#날짜를 넣으면 100일 뒤가 몇월 며칠인지 계산해주는 함수를 만들어 보겠습니다.
#😲조건1 - "오늘부터 1일"이기 때문에 날짜를 계산할 때 오늘을 포함합니다
#😲조건2 - 몇년도인지 구분하지 않고 윤년도 고려하지 않고 2월은 무조건 28일로 합니다.

#첫번째 코드는 월, 일까지는 해결하셨고 요일예측은 완성되지 않은 코드입니다. 
#다만 월별 최대일수를 조건별로 나눠서 하셔서 고생하셨습니다. 
#100일후이기 때문에 루프를 99번 돌리는 형식의 코드입니다. 

def after_100(myMonth, myDate, myDay):
  month = myMonth
  date = myDate
  weekday = ['월','화','수','목','금','토','일']
  day = weekday.index(myDay)
  newDay = weekday[(day + 99) % 7]
  #입력한 일의 인덱스
  date = num.index(myDate)
  for i in range(99):
    #12월을 넘기면 1월로 초기화
    if ((month % 13) == 0):
      month = 1
      print('month: ',month)
    else:
      #2월은 28일까지 계산
      if (month == 2):
        date = date + 1
        if ((date % 28) == 0):
          month = month + 1
          date = 0
      if (month < 8):
        #짝수달이면 30일까지 계산
        if ((month % 2) == 0):
          date = date + 1
          if ((date % 30) == 0):
            month = month + 1
            date = 0
        #홀수달이면 31일까지 계산
        elif ((month % 2) == 1):
          date = date + 1
          if ((date % 31) == 0):
            month = month + 1
            date = 0
      if (month >= 8):
        #짝수달이면 31일까지 계산
        if ((month % 2) == 0):
          date = date + 1
          if ((date % 31) == 0):
            month = month + 1
            date = 0
        #홀수달이면 30일까지 계산
        elif ((month % 2) == 1):
          date = date + 1
          if ((date % 30) == 0):
            month = month + 1
            date = 0
  print(myMonth,'월',myDate,'일',myDay,'요일부터 100일 뒤는',month,'월',date,'일',newDay,'요일')
num = []
#달력
for i in range(31):
  i = i + 1
  num.append(i)
myMonth = int(input('월을 입력하세요: '))
myDate = int(input('일을 입력하세요: '))
myDay = input('요일을 입력하세요: ')
after_100(myMonth, myDate, myDay)




#두번째 코드는 사실 제(리드부스터) 코드인데 
#저희 조에 처음 시작하는 분들이 많아서 설명 디테일하게 하기 위해서 일부러 주석을 좀 세세하게 달았습니다.


#월별 최대 일수는 리스트로 이미 만들어 놓았습니다. 
#그 상태에서 리스트의 인덱스를 활용했습니다.
#요일 또한 이미 만들어놓고 인덱스를 활용했는데 요일부터 설명하겠습니다. 

mon = [31,28,31,30,31,30,31,31,30,31,30,31]
whatday = ["월", "화", "수", "목", "금", "토", "일"]
# 연애 시작한 날은 1일자부터 계산하니 1,8,15, ... (7n + 1)일차는 -> 요일이 그대로 유지됩니다. 
# 등차수열로 표현할 수 있게 됐습니다.
# 100일의 경우를 따져보자면 연애 시작한 날부터 + 99일이 되어야 합니다.
# 7*14+ 1 = 99 이므로 100일이라면 사귀기로 한 날의 요일 + 1이 되어야합니다. 
# 입력한 day의 whatday(요일) 리스트에서의 index를 구하고 그 +1 인 요일을 출력해야겠다고 생각했습니다.
# 일반화하면,원래 처음 요일에서 (세고 싶은 기념일수)%7-1 만큼 인덱스를 더하면 
# (세고 싶은 기념일수)일 후의 요일이 출력됩니다. 
# 다만 이 경우 일요일은 약간 특이하게 처리해줘야 하기 때문에 밑에서 설명하겠습니다.
# 이를 이용하면 100일, 200일, .. 후에 무슨 요일인지도 출력할 수 있습니다. 
# 1 월이 넘어갈 때 잘 계산되는지 확인하기 위해, 규칙을 찾은 김에 겸사겸사 만들었습니다.



def after_100(month,day,wd,cel = 100): 
    mon = [31,28,31,30,31,30,31,31,30,31,30,31]
    whatday = ["월", "화", "수", "목", "금", "토", "일"]
    #month,day,wd는 각각 연애를 시작한 날의 월, 일, 요일입니다. 
    #cel은 계산하고 싶은 기념일(문제에서는 100일)이 몇일인지에 대한 변수입니다.
    #문제의 경우 100일이니 이 문제에서는 cel의 값의 디폴트는 = 100 으로 고정시켰지만
    #필요한 경우 200일,300일, ... 도 계산할 수 있도록 cel 도 변수로 넣었습니다.
    #mon[month-1] # 그 달의 일수입니다.
    print("오늘부터 1일! ",month,"월",day,"일") #시작일 확인 
    n = 1 #몇일자인지 세기 위한 도구입니다. 오늘부터 1일이니 n = 1로 고정합니다. 
    while True:
        day +=1 
        n += 1
        if day == mon[month-1]+1: 
            #지정한 달의 일수보다 커지면 month가 커지고 day 는 1로 바뀌도록 했습니다
            #1월이라고 가정하면 32일이 되는 순간을 의미합니다.
            month +=1
            day = 1
        if month > 12:
            #13월이 되는 순간 month는 1로 바꾸어줍니다. 
            month = 1 
        print("month:",month,"day:",day,"n:",n,"일") 
        #-> 루프가 잘 돌아가고 있는지 확인하기 위한 작업입니다. 미션과는 무관합니다.
        if n == cel: #100일에 다다르면 루프는 종료하게 설계했습니다.
            break 
    #요일 구하기는 위에 자세하게 설명해놓았습니다. 
    wd_index = whatday.index(wd) 
    final_wd = wd_index + cel%7-1
    #주어진 요일이 whatday list에서 어떤 위치를 갖는지 찾고 
    while final_wd >=7: 
        #if 를 써도 크게 문제 없이 돌아갈 것 같지만 혹시 모르니 루프로 짰습니다. 
        #이 일을 하지 않으면 100일 후의 경우 일 -> 월로 넘어가지 못하고 리스트의 범위를 벗어나 error가 뜹니다 
        final_wd = final_wd -7
    after_wd = whatday[final_wd]
    #print(after_wd) (cel)일 후의 요일이 잘 계산되었는지에 대한 체크 결과입니다 
    #print(month,day) (cel)일 후의 날짜가 잘 계산되었는지에 대한 체크 결과입니다 
    result = f"{cel}일 기념일은 {month}월 {day}일 {after_wd}요일입니다. 미리 준비하세요!"
    return result

print(after_100(6,21,"월"))
print(after_100(6,21,"월",200)) 


#이거는 검색하다 찾았는데 datetime 모듈을 활용해서도 
#실제 n일 후의 날짜를 쉽게 구할 수 있더군요.
#하지만 우리가 문제를 푸는 취지에는 맞지 않기는 합니다만 
#일상생활에 쓰기엔 더 좋을 것 같아 팀원들에게는 공개했습니다. 

import datetime
  
year, month, day, n = 2021, 5, 10, 1000

day = datetime.date(year, month, day)
theday = day + datetime.timedelta(n)
print(theday)

print('\n')
