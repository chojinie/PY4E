date_list = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
day_list = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"]

today = input("오늘의 날짜와 요일을 입력해주세요: ")
today_list = []
today_list.append(today.split(' ')[0].replace("월", ""))
today_list.append(today.split(' ')[1].replace("일", ""))
today_f = ",".join(today_list)
day_f = today.split(' ')[2]

print(today_f)
print(day_f)

def after_100(a, b):
    month = int(a[:a.index(",")])
    date = int(a[a.index(",") + 1:])
    
    S = 100 - (date_list[month - 1] - date + 1)

    while S > 0:
        S = S - date_list[month]
        month = (month + 1) % 12
    
    r = 100 % 7
    
    print(today + "부터 100일 뒤는", str(month) + "월", str(date_list[10 - 1] + S - 1) + "일", day_list[(int(day_list.index(b))+ r) % 7 - 1])
    
after_100(today_f, day_f)