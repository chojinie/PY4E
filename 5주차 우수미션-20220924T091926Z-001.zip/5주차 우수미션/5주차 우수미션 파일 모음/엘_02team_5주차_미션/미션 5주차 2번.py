key = [3,2,4,2,5,2,4,3,1,2]

answer_sheet = []
while True:
    answer_sheet.append(input("학생의 이름과 답을 입력해주세요(이름,답): "))
    if "끝" in answer_sheet:
        break
answer_sheet.remove("끝")

def grade(a, b):
    as_list = []
    for i in range(len(a)):
        as_list.append(a[i].split(","))

    key_str = "".join(map(str,b))
    for j in range(len(as_list)):
        score = 0
        for k in range(len(key_str)):
            if as_list[j][1][k] == key_str[k]:
                score = score + 10
        as_list[j].append(score)
        
    result = sorted(as_list, key = lambda x : x[2], reverse = True)
    
    for r in range(len(result)):
        print("학생:", str(result[r][0]), "점수:", str(result[r][2]) + "점", str(r + 1) + "등")

grade(answer_sheet, key)