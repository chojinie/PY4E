number_list = []
import random
while len(number_list) <= 2:
    num = random.randint(0, 100)
    if num not in number_list:
        number_list.append(num)

number_list.sort()
min = min(number_list)
mid = number_list[1]
max = max(number_list)
answer_list = []
reply_list = []

def guess_number():
    for i in range(1, 102):
        if len(answer_list) == 3:
            print("게임 종료")
            print(str(i-1), "번 시도만에 예측 성공")
            break
        
        
        if i == 5:
            while True:
                print(str(i) + "차 시도")
                ans = int(input("숫자를 예측해보세요: "))
                if ans not in reply_list:
                    reply_list.append(ans)
                    break
                else:
                    print("이미 예측에 사용한 숫자입니다.")    
            if ans not in number_list:
                print(str(ans) + "는 없습니다.")
                if ans > min:
                    print("최솟값은", str(ans) + "보다 작습니다.")
                elif ans < min:
                    print("최솟값은", str(ans) + "보다 큽니다.")
                continue

        if i == 10:
            while True:
                print(str(i) + "차 시도")
                ans = int(input("숫자를 예측해보세요: "))
                if ans not in reply_list:
                    reply_list.append(ans)
                    break
                else:
                    print("이미 예측에 사용한 숫자입니다.")    
            if ans not in number_list:
                print(str(ans) + "는 없습니다.")
                if ans > max:
                    print("최댓값은", str(ans) + "보다 작습니다.")
                elif ans < max:
                    print("최댓값은", str(ans) + "보다 큽니다.")    
                continue

        while True:
            print(str(i) + "차 시도")
            ans = int(input("숫자를 예측해보세요: "))
            if ans not in reply_list:
                reply_list.append(ans)
                break
            else:
                print("이미 예측에 사용한 숫자입니다.")
        if ans in number_list:
            answer_list.append(ans)
            if ans == min:
                print("숫자를 맞추셨습니다!", str(ans) + "는 최솟값입니다.")
            elif ans == mid:
                print("숫자를 맞추셨습니다!", str(ans) + "는 중간값입니다.")
            elif ans == max:
                print("숫자를 맞추셨습니다!", str(ans) + "는 최댓값입니다.")
                
guess_number()