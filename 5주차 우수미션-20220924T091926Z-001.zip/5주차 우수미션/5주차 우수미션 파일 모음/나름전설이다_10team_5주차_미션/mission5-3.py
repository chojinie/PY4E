import random

def guess_number():
    guess_list = []
    already_list = []
    answer_list = []
    count = 0
    for i in range(3): # 0부터 100까지의 숫자중 3개 랜덤으로 뽑기
        number = random.randint(0, 100)
        while number in guess_list: #중복된 값이 있으면 다시 뽑기
            number = random.randint(0,100)
        guess_list.append(number)
    guess_list.sort()
    max_num = guess_list[2] # 랜덤한 숫자의 최댓값
    mid_num = guess_list[1] # 랜덤한 숫자의 중간값
    min_num = guess_list[0] # 랜덤한 숫자의 최소값
    while True:
        print(f'{count+1}차 시도')
        user_number = int(input("숫자를 입력해보세요 : "))
        already_list.append(user_number)
        if guess_list[0] == user_number:
            print(f'숫자를 맟추셨습니다. {user_number}는 최솟값입니다.')
            answer_list.append(user_number) # 숫자를 맞추면 리스트에 정답 추가
        elif guess_list[1] == user_number:
            print(f'숫자를 맟추셨습니다. {user_number}는 중간값입니다.')
            answer_list.append(user_number)
        elif guess_list[2] == user_number:
            print(f'숫자를 맟추셨습니다. {user_number}는 최댓값입니다.')
            answer_list.append(user_number)

        if count >= 4: #5번째시도 이후로 힌트
            if user_number < min_num and user_number not in guess_list:
                print(f'{user_number}는 없습니다.')
                print(f'{user_number}은 최솟값보다 작습니다.', sep='/n')
            elif user_number > max_num and user_number not in guess_list:
                print(f'{user_number}는 없습니다.')
                print(f'{user_number}은 최댓값보다 크다.', sep='/n')
            elif user_number < max_num and user_number > mid_num and user_number not in guess_list:
                print(f'{user_number}는 없습니다.')
                print(f'{user_number}는 최댓값과  중간값 사이에 있습니다.', sep='/n')
            elif user_number < mid_num and user_number > min_num and user_number not in guess_list:
                print(f'{user_number}는 없습니다.')
                print(f'{user_number}는 최솟값과 중간값 사이에 있습니다.', sep='/n')
        if count > 8: #10번 시도하면 게임 종료
            print("정답을 맞추지 못했습니다. ")
            print("정답은 :",guess_list)
            quit()

        answer_list.sort() #정답을 정렬
        if guess_list == answer_list: #랜덤한 값과 사용자의 값이 같으면 게임종료료            print("게임 종료")
            print(f'{count+1}번 시도만에 예측 성공')
            break
        count += 1

guess_number()




