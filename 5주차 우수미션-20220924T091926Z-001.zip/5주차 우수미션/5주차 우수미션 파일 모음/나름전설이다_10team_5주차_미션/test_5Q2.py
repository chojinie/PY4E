def grader(s, a):  # 함수 정의
	score = list()
	gx = list()
	for sx1 in s :      # 개별 작업을 위한 루프
		sx2 = sx1.split(',')  # 이름, 답안 분리
		nx1 = sx2[0]
		sx3 = sx2[1]
		sx4 = list()   # 답안 비교를 위해 저장
		for sa in sx3:
			sa = int(sa)
			sx4.append(sa)

		count = 0
		i = 0
		for ax in a :   # 정답지와 비교
			if ax == sx4[i] :
				count = count + 1
			i = i + 1
		grade = count * 10
		score = [grade,nx1]   # 개별 묶음
		gx.append(score)      # 리스트
		gx.sort(reverse=True) # 점수 정렬

	sc = 0
	si = 0
	for bx in gx :
		name = bx[1]
		scr1 = bx[0]
		sc = sc + 1
		print('학생:',name, ' 점수: %d점' %scr1, ' %d등' %sc)

# 학생 답
s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315"]

# 정답지
a = [3,2,4,2,5,2,4,3,1,2]

grader(s, a)  # 함수 실행
