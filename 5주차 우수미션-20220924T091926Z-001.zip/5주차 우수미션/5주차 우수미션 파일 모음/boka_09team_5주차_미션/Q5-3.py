import random

def guess_numbers():
    print(f"--- 0~100 사이 숫자 3개를 맞춰봅시다! ---")
    number = []
    while len(number) < 3:
        new_number = random.randint(0, 100)
        if new_number in number:
            continue
        else:
            number.append(new_number)
    number.sort()

    dict = {number[0] : "최솟값", number[1] : "중앙값", number[2] : "최댓값"}
    c = 0
    try_numlist = []
    while len(number) > 0:
        c += 1
        print(f"\n{c}차 시도 입니다")
        try_num = input("숫자를 예측해보세요 : ")
        #숫자가 아닌 글자를 입력하는 경우
        if try_num.isdecimal() == False:
            print(f"0 이상의 숫자를 입력해주세요")
            c -= 1
            continue
        else:
            try_num = int(try_num)
        #0에서 100 사이가 아닌 수를 입력하는 경우
        if try_num > 100:
            print(f"0~100 사이의 수를 입력해주세요")
            c -= 1
            continue
        
        if try_num in number:
            print(f"숫자를 맞추셨습니다! {try_num}는 {dict[try_num]}입니다")
            number.remove(try_num)
            try_numlist.append(try_num)
            if len(number) == 0:
                break
        else:
            if try_num in try_numlist:
                print("이미 예측에 사용한 숫자입니다")
                c -= 1
                continue
            else:
                print(f"{try_num}은 없습니다")
                try_numlist.append(try_num) 

            if c == 5: #최솟값 힌트/최솟값 맞춘 경우 중앙값 힌트/중앙값까지 맞춘 경우 최댓값 힌트
                if number[0] < try_num:
                    print(f"Hint : {dict[number[0]]}은 {try_num}보다 작습니다")
                else:
                    print(f"Hint : {dict[number[0]]}은 {try_num}보다 큽니다")
            elif c == 10: #최댓값 힌트/최댓값 맞춘 경우 중앙값 힌트/중앙값까지 맞춘 경우 최솟값 힌트
                if number[-1] < try_num:
                    print(f"Hint : {dict[number[-1]]}은 {try_num}보다 작습니다")
                else:
                    print(f"Hint : {dict[number[-1]]}은 {try_num}보다 큽니다")
            elif c % 5 == 0: #5의 배수번째 시도에서도 힌트 주기
                if number[-1] < try_num:
                    print(f"Hint : {dict[number[-1]]}은 {try_num}보다 작습니다")
                else:
                    print(f"Hint : {dict[number[-1]]}은 {try_num}보다 큽니다")
   
    print(f"\n------------- 게임종료 -------------\n{c}번 시도만에 예측 성공!")
    print(f"숫자 리스트는 {list(dict.keys())}였습니다!")



guess_numbers()