def after_100():
    dates = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    days = ["월", "화", "수", "목", "금", "토", "일"]

    #입력시 예외 처리
    month = input("오늘의 월을 입력해주세요(1~12) : ")
    while month.isdecimal() == False or int(month) > 12 or int(month) < 1:
        month = input("잘못 입력하셨습니다. 1~12월 중에 입력해주세요 : ")
    month = int(month)
    date = input("오늘의 날짜를 입력해주세요 : ")
    while date.isdecimal() == False or int(date) < 1 or int(date) > dates[month-1]:
        date = input(f"잘못 입력하셨습니다. 1~{dates[month-1]} 사이 숫자로 입력해주세요 : ")
    date = int(date)
    day = input("오늘의 요일을 입력해주세요 : ")
    while day not in days:
        day = input("잘못 입력하셨습니다. 월~일 중 하나로 입력해주세요 : ")

    #100일 후 날짜 지정
    new_date = 100-(dates[month-1] - date + 1 + dates[month-12] + dates[month-11] + dates[month-10])
    if new_date > 0:
        if month < 9 :
          new_month = month + 4
        else:
          new_month = month - 8
    else:
        new_date += dates[month-10]
        if month <= 9:
            new_month = month + 3
        else:
            new_month = month - 9
    new_day = days[days.index(day)-6]

    print(f"\n>> {month}월 {date}일 {day}요일부터 100일 뒤는 {new_month}월 {new_date}일 {new_day}요일입니다")


after_100()