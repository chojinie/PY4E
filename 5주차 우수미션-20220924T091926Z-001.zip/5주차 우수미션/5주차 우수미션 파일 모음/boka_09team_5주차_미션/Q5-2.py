def grader(s, a):
    rank = []
    for st in s:
        grade = 0
        student = st.split(',')
        name = student[0]
        answer = [int(ans) for ans in student[1]]
        for i in range(len(a)):
            if a[i] == answer[i]:
                grade += 10
        rank.append([name, grade])
    rank.sort(key=lambda x: x[1], reverse=True)
    for i, r in enumerate(rank):
        print(f"학생 : {r[0]} 점수 : {r[1]}점 {i+1}등")


# 학생 답
s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315"]

# 정답지
a = [3,2,4,2,5,2,4,3,1,2]

grader(s, a)