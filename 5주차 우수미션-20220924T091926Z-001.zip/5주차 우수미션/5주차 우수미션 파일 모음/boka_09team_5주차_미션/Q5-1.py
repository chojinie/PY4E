import random 

def bs31():
    print("---------------------------------------")
    print("배스킨 라빈스 31 게임을 시작하겠습니다")
    print("---------------------------------------")
    print("1부터 연속하는 자연수를 3개 이하로 입력해주세요")
    baskin = 0
    while baskin <= 31:
        my = input("나 : ")
        mynumber = my.split()
        #숫자가 아닌 글자가 들어오는 경우
        if ''.join(mynumber).isdecimal() == False:
            print("숫자만 입력해주세요")
            continue
        my_number = [int(n) for n in mynumber]
        #숫자 개수가 1~3개가 아닌 경우
        if len(my_number) > 3 or len(my_number) < 1:
            print("숫자는 1~3개로 입력해주세요")
            continue
        #현재 숫자의 다음 숫자가 아닌 경우
        if my_number[0] != baskin + 1:
            print("현재 숫자보다 1이 큰 숫자부터 입력해주세요")
            continue
        #연속한 수가 아닌 경우
        if my_number != [i for i in range(baskin+1, baskin+len(my_number)+1)]:
            print("연속하는 자연수를 입력해주세요")
            continue
        baskin = my_number[-1]
        if 31 <= baskin:
            break
        print("현재 숫자 :", baskin, "\n")

        computer_turn_num = random.randint(1,3)
        computernumber = baskin + computer_turn_num
        if computernumber >= 31:
            computernumber = 31
        computer_number = [num for num in range(baskin+1, computernumber+1)]
        print("컴퓨터 :", ' '.join([str(n) for n in computer_number]))
        baskin = computer_number[-1]
        if 31 <= baskin:
            break
        print("현재 숫자 :", baskin, "\n")

    print("31이 입력되었습니다")
    result = {my_number[-1]: "내", computer_number[-1]: "컴퓨터"}
    print("---------------------------------------")
    print("게임 종료! " + result[min(my_number[-1], computer_number[-1])]+"가 승리!")
    print("---------------------------------------")


bs31()