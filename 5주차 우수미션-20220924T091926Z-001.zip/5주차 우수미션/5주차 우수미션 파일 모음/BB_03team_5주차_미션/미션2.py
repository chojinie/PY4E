def printGrader(s,a):
    #점수를 저장할 리스트
    score_list = []

    #학생들의 정보를 차례로 돌아본다
    for x in range(len(s)):
        #x번째 학생의 정보를 split()함수로 이름(name),제출답안(s_answer)으로 저장
        name, s_answer = s[x].split(sep=',')
        score = 0
        #학생 답안과 답안지를 차례로 비교한다.
        for i in range(len((s_answer))):
            #만약 같다면
            if str(a[i]) == s_answer[i]:
                #점수 10점 추가
                score+=10
        #최종 점수를 [점수,이름] 리스트로 score_list에 저장
        score_list.append([score,name])

    #정렬해준다. 첫 원소를 오름차순으로 정리하기 때문에 역정렬을 해준다.
    #이 때 점수가 높은 순으로 정렬된다
    score_list.sort(reverse=True)

    #결과 출력
    for i in range(len(score_list)):
        print("학생: {}  점수: {}  {}등".format(score_list[i][1],score_list[i][0],i+1))



s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315"]

a = [3,2,4,2,5,2,4,3,1,2]

printGrader(s,a)


