import random
#1~31 사이의 숫자가 맞는지, 이전에 입력한 숫자보다 큰 수를 넣었는지, 3개 이상을 넣은건 아닌지 판단

def beskinGame():
    #게임 시작 알림
    print("-"*40)
    print("-"*40)
    print("-----베스킨라빈스 게임을 시작합니다!----")
    print("-------1부터 숫자를 입력해주세요!-------")
    print("-"*40)
    print("-"*40)
    print()
    print()

    # 0~31까지 존재하는 beskin 리스트 생성. 이 리스트에서 첫 원소를 빼가면서 셀 예정
    beskin = [i for i in range(32)]

    #31이 될떄까지 반복루프
    while(True):

        try:
            # 1~3개의 숫자를 입력받아서 my_li 리스트에 저장
            my_li = list(map(int,input("My Turn - 숫자를 입력하세요 ( 최대 3개 ) : ").split()))

        #만약 숫자 외를 입력하면 
        except ValueError:
            #다시 입력하라는 문장과 함께 다시 돌아간다.
            print("현재 숫자는 {}입니다. 순서에 맞는 자연수를 입력하세요".format(beskin[0]))
            continue

        #숫자를 처음엔 순서에 맞게 입력하고 뒷부분을 잘못 입력할 수 있다. (ex. 5 6 10)
        #그 때 pop()했던 원소를 다시 복구한 다음 반복문을 다시 시작한다. 그 때 불러오기 위해 save_li에 현재 beskin저장
        save_li = beskin[:]
        #이중반복문 탈출을 위한 변수
        flag = False

        #입력한 숫자리스트가 빌 때 까지 반복한다. if(리스트) 형태를 쓰게 되면 리스트가 비었을 때 False, 아닐때 True를 반환한다.
        while(my_li):

            #beskin리스트의 두번째 원소와 my_li의 첫 원소가 다르다면 잘못 입력한 것이다.
            #(beskin은 입력횟수만큼 pop()을 하기때문에 0부터 시작한다. 따라서 두번째 원소로 비교해야한다.)
            if(beskin[1] != my_li[0]):
                print("현재 숫자는 {}입니다. 순서와 갯수를 맞춰 다시 입력하세요.".format(beskin[0]))
                #잘못 입력했을 때 flag를 True로 바꾸고
                flag = True
                #beskin이 이전에 pop()되었을 수 있으니 저장한 리스트를 다시 불러온다.
                beskin = save_li[:]
                break
            #잘 맞는다면 두 리스트의 첫 원소를 제거
            else:
                beskin.pop(0)
                my_li.pop(0)
        
        #플래그가 true면 중간에 틀린 것이므로 반복문 다시 시작
        if(flag == True):
            continue
        

        
        print("현재 숫자 : {}".format(beskin[0]))
        #리스트안에 31만 남는다면
        #나의 입력에서 31이 나온 것이므로 컴퓨터 승리 출력
        if beskin[0] == 31:
            print("컴퓨터 승리!")
            return
        
        #컴퓨터 차례. 1~3까지 랜덤으로 저장
        computer_num = random.randint(1,3)
        #저장한 만큼 반복문 실행
        for _ in range(computer_num):
            #beskin 첫원소를 빼고
            beskin.pop(0)
            #beskin 리스트가 비게 된다면 컴퓨터 차례에서 31이 나왔으므로 나의 승리
            
            print("컴퓨터 : {}".format(beskin[0]))

        print("현재 숫자 : {}".format(beskin[0]))

        #리스트안에 31만 남는다면
        #컴퓨터의 입력에서 31이 나온 것이므로 나의 승리 출력
        if beskin[0] == 31:
                print("유저 승리!")
                return

beskinGame()
            