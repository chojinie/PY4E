import random

def guess_numbers():
    #랜덤하게 뽑힌 세 숫자를 저장할 리스트
    n_list = []

    #0~100까지 세 숫자를 뽑기 위해 반복문
    for _ in range(3):
        #랜덤하게 숫자를 고른다
        n = random.randint(0,100)
        #만약 고른 숫자가 이미 리스트안에 있다면
        while(n in n_list):
            #없는게 나올때까지 다시 고른다
            n = random.randint(0,100)
        #숫자 추가
        n_list.append(n)
    #최소,중간,최대값 구별을 위해 정렬
    n_list.sort()

    #이미 고른 숫자를 구별하기 위해 0~100까지 False로 이루어진 guess_list 생성.
    #후에 숫자를 고르면 그 인덱스는 True로 바꿔줄 예정
    guess_list = [False for i in range(101)]

    #총 도전한 숫자
    count = 0

    #맞출때까지 반복문을 시행한다
    while(True):
        #도전횟수 + 1
        count+=1
        print("{}차 시도".format(count))
        guess_num = int(input("숫자를 예측해보세요 : "))

        #만약 이미 고른 숫자라면 (guess_list[고른 숫자]가 True 라면)
        if guess_list[guess_num] == True:
            print("이미 예측에 사용한 숫자입니다.")
            #횟수를 다시 차감하고 반복문 다시 시작
            count-=1
            continue
        
        #골랐던 숫자가 아니라면
        else:
            #guess_list에 현재 숫자 위치를 True로 바꿔 골랐다는 표시를 한다
            guess_list[guess_num] = True
            #만약 추측숫자가 뽑은 숫자 중 없다면
            if not guess_num in n_list:
                #없다고 출력
                print("{}는 없습니다.".format(guess_num))


                #아직 최솟값을 못찾았다면
                if(guess_list[n_list[0]] == False):
                    #최솟값 힌트를 준다
                    if(guess_num<n_list[0]):
                        print("최솟값은 {}보다 큽니다.".format(guess_num))
                    else:
                        print("최솟값은 {}보다 작습니다.".format(guess_num))
                #최솟값은 찾고 최댓값은 못 찾았다면
                elif (guess_list[n_list[2]] == False):
                    #최댓값 힌트를 준다
                    if(guess_num<n_list[2]):
                        print("최댓값은 {}보다 큽니다.".format(guess_num))
                    else:
                        print("최댓값은 {}보다 작습니다.".format(guess_num))
                #둘 다 찾았다면 힌트없이 마무리
                else:
                    print("최대,최솟값을 모두 찾았습니다. 별도의 힌트가 없습니다.")

            #만약 추측숫자가 뽑은 숫자 중 있다면
            else:
                if(guess_num == n_list[0]):
                    print("숫자를 맞추셨습니다! {}는 최솟값입니다.".format(n_list[0]))
                elif(guess_num == n_list[1]):
                    print("숫자를 맞추셨습니다! {}는 중간값입니다.".format(n_list[1]))
                else:
                    print("숫자를 맞추셨습니다! {}는 최댓값입니다.".format(n_list[2]))
            
            #만약 guess_list에 최소,중간,최댓값이 전부 확인됐다면
            if(guess_list[n_list[0]] == True and guess_list[n_list[1]] == True and guess_list[n_list[2]] == True):
                #게임 종료 문구 출력
                print("게임 종료")
                print("{}번 시도만에 예측 성공".format(count))
                break
                
guess_numbers()