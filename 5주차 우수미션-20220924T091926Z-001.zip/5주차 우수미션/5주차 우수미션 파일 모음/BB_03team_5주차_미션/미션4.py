
#입력받은 월,일,요일을 각각 month,day,DofW로 입력한다. (DofW : Day of Week 약자)
def after_100(month,day,DofW):
    # 마지막 결과 출력을 위해 초기값을 저장해둔다
    M,D,DW = month,day,DofW

    #100일 까지 남은 일수를 D_day로 둔다
    D_day = 99
    #월별 일수를 리스트로 저장. 첫 인덱스는 0 이므로 0으로 채워둔다
    month_li = [0,31,28,31,30,31,30,31,31,30,31,30,31]
    #요일을 리스트로 저장
    DofW_li = ["월","화","수","목","금","토","일"]

    #남는 일수(D_day)가 다음 달을 넘기지 않을때까지 반복. 한 번 반복당 다음 달 1일이 된다.
    while(D_day > month_li[month]):

        # 다음달 1일까지 남은 일수를 date에 저장
        date = month_li[month]-day+1

        # 다음달 1일로 넘어가는 과정이므로 남은 일수(D_day)에서 date를 뺀다. 
        D_day -= date

        #현재 요일의 인덱스를 DofW_index 저장해서
        DofW_index = DofW_li.index(DofW)

        #DofW를 다음달 1일의 요일로 바꾼다.
        #현재 인덱스에 남은 일수를 더해서 7로 나눈 나머지가 요일이 된다.
        #예를 들어 현재 인덱스가 2(수), 다음달 1일까지 8일이 남았다면, 현재 인덱스에 8을 더해서 7로 나눈 나머지는 3(목) 이 된다.
        DofW = DofW_li[(DofW_index+date)%7]
        
        #다음 달이 되어야하므로 현재 달에 1을 더하고
        month +=1
        #일수는 1로 만든다
        day = 1

    #while문을 탈출했다면 다음 달로 넘어가지 않는것이므로 1일인 상태이므로 남은 일수 D_day를 더한다.
    day += D_day

    #위와 같은 방법으로 요일을 찾아낸다
    DofW_index = DofW_li.index(DofW)
    DofW = DofW_li[(DofW_index+D_day)%7]
    
    print(f"{M}월 {D}일 {DW}요일로부터 100일 뒤는 {month}월 {day}일 {DofW}요일")


after_100(8,11,"목")

