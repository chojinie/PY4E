def after_100():
    week = ["월","화","수","목","금","토","일"] #입력받은 요일 비교 리스트
    mon_31 = [1,3,5,7,8,10,12] #31일까지 있는 달
    mon_30 = [4,6,9,11] # 30일까지 있는 달
    month = int(input("오늘은 몇월인가요?"))
    day = int(input("오늘은 몇일인가요?"))
    day_week = input("오늘은 무슨 요일인가요?")
    after_mon = month # 100일 이후 달 계산 위하여
    after_day = day # 100일 이후 일 계산 위하여
    a = week.index(day_week[0]) #입력받은 요일을 찾음
    a = a+1 # 100일 이후 요일 지정
    n = 1
    while n < 100: # 100일 카운트 시작
        if after_mon in mon_31:  #31일 있는 달인지 확인
            if after_day < 32:
                after_day = after_day + 1 #요일 체크
                n = n + 1
            else:
                after_mon = after_mon + 1 # 날짜가 지나면 다음달로 변경
                after_day = 2 # 날짜가 하루 지나서 1이 아닌 2
                n = n + 1

        elif after_mon in mon_30: #30일 있는 달인지 확인
            if after_day < 31:
                after_day = after_day + 1 #요일 체크
                n = n + 1
            else:
                after_mon = after_mon + 1
                after_day = 2
                n = n + 1
        else:
            if after_day < 29: # 2월달은 28일까지
                after_day = after_day + 1
                n = n + 1
            else:
                after_mon = after_mon + 1
                after_day = 2
                n = n + 1



    print(month,"월 ",day,"일 ",day_week,"부터 100일 뒤는  ",after_mon,"월 ",after_day,"일 ",week[a],"요일",sep = "")

after_100()
