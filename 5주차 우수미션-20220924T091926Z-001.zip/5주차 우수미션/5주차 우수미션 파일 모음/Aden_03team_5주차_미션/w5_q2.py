s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315"]

a = [3,2,4,2,5,2,4,3,1,2]

def grader(s,a):
    total = list()
    rank = list()
    name = list()
    b = [1,2,3,4,5]
    add = 0
    for i in s:
        score = list()
        chek = 0
        answer = i[3:]
        while chek < 10:
            if int(a[chek]) == int(answer[chek]):
                score.append(10) # 문제 맞출때마다 10점
            else:
                score.append(0)
            chek = chek + 1
        name.append(i[:2])
        total.append(sum(score)) #총 합계
        rank.append(sum(score)) # 합계점수로 순위 결정
    rank.sort(reverse=True)
    for i in total:
        count = 0
        while count < 5:
            if rank[count] == i:
                b[count] = name[add] #순위에 맞는 이름 정해줌
            count = count + 1
        add = add + 1
    for i in range(5):
        print("학생:",b[i],"  점수:",rank[i],"점  ",i+1,"등",sep = "")
grader(s,a)
