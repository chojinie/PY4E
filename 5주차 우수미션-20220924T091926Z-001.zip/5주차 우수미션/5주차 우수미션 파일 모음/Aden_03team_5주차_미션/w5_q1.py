import random

numbers = [i for i in range(1,31+1)]
player = random.randrange(0,2)

def user(array):
    global player
    while True:
        num = int(input('1~3의 숫자를 입력해주세요.'))
        if 1 <= num <=3 and num <= len(numbers):
            break
        print('다시 입력해주세요')
    for i in range(num):
        print('플레이어 :', array[0])
        del array[0]
    player = 1

def computer(array):
    global player
    num = random.randrange(1, 4)
    if len(numbers) <= 3:
        num = len(numbers) - 1
        if (num==0):
            num = 1

    for i in range(num):
        print('컴퓨터 :',array[0])
        del array[0]
    player = 0

while  0 < len(numbers):
    if player == 0:
        user(numbers)
    else:
        computer(numbers)

if player == 0:
    print('플레이어의 승리 !')
else:
    print('컴퓨터의 승리 !')
