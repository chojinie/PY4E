import random
def guess_numbers():
    n = 1
    score = 0 # 숫자를 맞추면 점수를 주는거로 현재까지 몇개의 숫자를 맞췄는지 비교하기 위하여 변수지정
    com_number = list()
    miss_number = list()
    miss_number.append(101) # 공백으로 하면 비교가 안되서  숫자 넣어줌
    hint_min = 100 # 힌트 주기 위하여
    hint_max = 0
    val = ["최솟값","중간값","최댓값"]
    for i in range(3):
        number = random.randint(0,100)
        com_number.append(number)
    while com_number[0] == com_number[1] or com_number[1] == com_number[2] or com_number[2] == com_number[0]: # 중복되는 숫자 확인
        for i in range(3):
            number = random.randint(0,100)
            com_number[i] = number

    com_number.sort()
    while score < 3: # 3숫자를 맞추면 3점이기에 맞출때까지 반복
        print(n,"차 시도",sep = "")
        ans = input("숫자를 예측해보세요:")

        for a in miss_number:
            if a == int(ans):
                print("이미 예측에 사용된 숫자입니다")
                n = n - 1 #이미 예측에 사용된 숫자는 횟수 미포함
        if int(com_number[0]) <= int(ans):
            if int(hint_min) >= int(ans):
                hint_min = ans # 오답중에서 최솟값보다 큰거를 찾아서 힌트 줌(최솟값은 9보다 작습니다 이런식으로)
        if int(com_number[2]) >= int(ans):
            if int(hint_max) <= int(ans):
                hint_max = ans # 오답중에서 최댓값보다 작은거를 찾아서 힌트 줌(최댓값은 70보다 큽니다 이런식으로)
        miss_number.append(int(ans))
        miss_number.sort()
        if int(ans) == int(com_number[0]):
            print("숫자를 맞추셨습니다! ",ans,"는 최솟값입니다",sep = "")
            val[0] = 0
            score = score + 1
        elif int(ans) == int(com_number[1]):
            print("숫자를 맞추셨습니다! ",ans,"는 중간값입니다",sep = "")
            val[1] = 1
            score = score + 1
        elif int(ans) == int(com_number[2]):
            print("숫자를 맞추셨습니다! ",ans,"는 최댓값입니다",sep = "")
            val[2] = 2
            score = score + 1
        elif n == 5 or n == 10:
            print(ans,"는 없습니다")
            if score == 0:
                print("최솟값은",hint_min,"보다 작습니다",sep = "")
            elif score == 1:
                if val[0] == 0:
                    print("최댓값은",hint_max,"보다 큽니다",sep = "")

                elif val[1] == 1:
                    print("최솟값은",hint_min,"보다 작습니다",sep = "")

                elif val[2] == 2:
                    print("최솟값은",hint_min,"보다 작습니다",sep = "")

            elif score == 2:
                if val[0] == 0 and val[1] == 1:
                    print("최댓값은",hint_max,"보다 큽니다",sep = "")
                elif val[1] == 1 and val[2] == 2:
                    print("최솟값은",hint_min,"보다 작습니다",sep = "")
                else:
                    print("중간값은",hint_min,"보다 크고",hint_max,"보다 작습니다",sep = "")

        else:
            print(ans,"는 없습니다")

        n = n + 1
    print("게임종료")
    print(n,"번 시도만에 예측 성공",sep = "")


guess_numbers()
