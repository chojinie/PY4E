def after_100(month, day, dow):
    origin = {"월": month, "일": day, "요일": dow}
    dows = ["일", "월", "화", "수", "목", "금", "토"]
    doms = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    month -= 1  # 인덱스를 활용하기 위해 0월~11월로 논리상 약속
    leftDays = day + 100-1  # 현재까지 지난 날짜들을 남은 날짜로 더함 오늘부터 1일 이므로 실제로는 오늘 날짜에 99일이 더해짐
    while(True):  # 남은 일자가 소진 될 때 까지 무한반복
        if (leftDays > doms[month]):  # 남은 일 수 > 이번달 일 수 인 경우
            leftDays -= doms[month]  # 남은 일 수에서 이번달 일 수를 뺀다.
            month = (month+1) % 12  # 달을 다음달로 변경, 나머지 연산을 활용하여 13월이 되는것을 방지
        else:  # 남은 일 수 <= 이번달 일 수
            day = leftDays  # 남은 일 수를 현재 일 수로 변경
            month += 1  # 달을 다시 1월~12월로 처리되도록 논리상 변경
            break  # 무한반복문 종료

    # 오늘부터 1일 이므로 실제로는 99를 더해야함.
    print(
        f"{origin['월']}월 {origin['일']}일 {origin['요일']}요일부터 100일 뒤는 {month}월 {day}일 {dows[(dows.index(dow)+100-1)%7]}요일")


after_100(6, 21, "월")
