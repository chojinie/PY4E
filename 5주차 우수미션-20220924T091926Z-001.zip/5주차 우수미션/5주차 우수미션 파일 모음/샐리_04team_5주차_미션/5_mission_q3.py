import random


def guess_numbers():
    numbers = [] # 정답 숫자를 기록할 변수를 빈 리스트로 초기화
    while (True): # 조건 만족시 까지 무한반복
        number = random.randint(0, 100) # 0~100 까지의 숫자를 하나 고름
        if(number in numbers): # 이미 생성된 숫자인 경우 패스
            continue
        numbers.append(number) # 숫자를 리스트에 추가
        if(len(numbers) == 3): # 추가된 숫자의 개수가 3개인 경우 반복문 종료
            break
    numbers.sort() # 오름차순으로 리스트를 정렬하여 최솟값,중간값,최대값 순으로 위치하게 함

    inputs = [] # 입력 숫자를 기록할 변수를 빈 리스트로 초기화
    correct = 0 # 정답 횟수를 기록할 변수를 0으로 초기화
    tried = 0 # 시도 횟수를 기록할 변수를 0으로 초기화
    while(True):
        tried += 1 # 시도횟수 증가
        print(f"\n{tried}차 시도") # 시도횟수 출력
        try: # 올바른 숫자를 입력할 때 까지 try-except로 처리
            num = int(input("숫자를 예측해보세요: ")) # 숫자를 입력받음과 동시에 int형변환
            if (not (0 <= num <= 100)): # 지정된 범위 외의 숫자인 경우 오류
                raise Exception("input error")
            if (num in inputs): # 이미 사용된 숫자인 경우
                print("이미 예측에 사용된 숫자입니다") # 문구 출력
                tried -= 1 # 시도 횟수 감소
                continue # for문 반복
            inputs.append(num) # 입력했던 숫자 목록에 추가
        except: # 숫자가 아닌 값 or 범위 외의 수 입력시 오류 메시지 출력 및 for문 반복
            print("잘못 입력하셨습니다")
            continue
        temp = 0 # 오답 횟수를 기록할 변수를 0으로 초기화
        for i in range(0, 3): # 정답 숫자 리스트를 모두 탐색
            if (numbers[i] == num): # 입력한 숫자가 정답 숫자 목록에 있을 경우
                print(
                    f"숫자를 맞추셨습니다! {numbers[i]}는 {'최솟값' if i==0 else ('중간값' if i == 1 else '최댓값')}입니다") # 문구와 함께 중간/최대/최솟값 여부출력
                numbers[i] = -1  # 맞춘 숫자를 목록에서 논리상 제거
                correct += 1 # 정답시 정답 횟수 변수를 증가
                break # 생성된 정답 숫자 목록 탐색 종료
            else:
                temp += 1 # 오류시 오답 횟수 변수를 증가

        if (correct == 3): # 모든 숫자를 맞추었을 때, 시도횟수와 문구 출력
            print(f"게임종료\n{tried}시도 만에 예측 성공")
            break

        if (temp == 3): # 생성된 정답 숫자 목록 모두와 일치하지 않는다면
            print(f"{num}는 없습니다.") # 오답 문구 출력
            if (tried == 5 or tried == 10): # 시도 횟수가 5회와, 10회라면 힌트문구 출력
                if (num < numbers[0]): 
                    print(f"{num}은 최솟값 보다 작습니다")
                elif (numbers[0] < num <= numbers[1]):
                    print(f"{num}은 최솟값과 중간값 사이에 있습니다.")
                elif (numbers[1] < num <= numbers[2]):
                    print(f"{num}은 중간값과 최댓값 사이에 있습니다.")
                elif (numbers[2] < num):
                    print(f"{num}은 최댓값 보다 큽니다.")


guess_numbers()
