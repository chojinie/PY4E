def grader(s, a):
    result = [] # 결과값 반환하기 위한 변수 생성
    for student in s:
        score = 0
        student = student.split(',') # 입력받은 학생의 정보를 ','로 분류

        for i in range(0, len(student[1])): # 입력받은 학생의 정보 중 입력 답안과 정답을 비교
            if (a[i] == int(student[1][i])): # 입력답안의 int형 변수와 정답을 비교 후 정답이면,
                score += 10 # 점수에 10을 추가
        result.append(str(score) + "," + student[0]) # 결과 변수에 "점수,이름"꼴로 데이터 추가
    result.sort(reverse=True) # 점수가 클수록 앞으로 가도록 리스트 정렬
    return result # 결과 변수 반환


# 학생 답
s = ["김갑,3242524215", "이을,3242524223",
     "박병,2242554131", "최정,4245242315", "정무,3242524315"]

# 정답지
a = [3, 2, 4, 2, 5, 2, 4, 3, 1, 2]
grade = grader(s, a) # 함수 호출
for i in range(0, len(grade)):
    grade[i] = grade[i].split(',')
    print(f"학생: {grade[i][1]} 점수: {grade[i][0]}점 {i+1}등")
