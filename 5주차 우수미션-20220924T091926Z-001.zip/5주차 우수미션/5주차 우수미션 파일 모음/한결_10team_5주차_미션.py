# Q1
"""
import random

CONS_LIMIT_NUM = 31
gFirstGame = random.randint(0,1)
gNumList = list()

# 현재 최대 값 구하는 함수(마지막 숫자)
def getMax() : return (1 if len(gNumList) <= 0 else max(gNumList))

def computerTurn() :
    global gNumList
    if(len(gNumList) == 0) : print("컴퓨터인 내가 먼저 게임을 시작할게!!");
    print("현재숫자:", str(getMax()) )

    # 컴퓨터가 이기기위한 방법 처리
    if getMax() == 28 : computerInput = 2
    elif getMax() in (29,30) : computerInput = 1
    else : computerInput = random.randint(1,3)

    computerList = list(range(len(gNumList)+1,len(gNumList)+computerInput+1))
    gNumList = gNumList + computerList

    # 출력
    print("컴퓨터:",computerList)
    print("현재숫자:", str(getMax()),end="\n\n")
    if getMax() == CONS_LIMIT_NUM : print("나의 승리!!")

    return 1

def myTrun() :
    global gNumList
    try :
        myInput = input("My trun - 숫자를 입력하세요(종료:quit): ")
        if myInput == "quit" : return CONS_LIMIT_NUM

        myList = list(map(int,myInput.split()))

        # 사용자가 잘못 입력한 경우에 대한 처리
        if not 0 < len(myList) <= 3 :
            # 게임 룰에 어긋나는 개수 입력에 대한 체크(ex : 1,2,3,4,5)
            raise
        for i in range(0, len(myList)) :
            # 순차적 입력에 대한 체크(ex : 1,2,5)
            if not myList[i] == len(gNumList)+1+i :
                raise
        if CONS_LIMIT_NUM - getMax() < len(myList) :
            # 31보다 큰수가 나올경우에 대한 체크(ex : 현재 29일경우 -> 30,31,32 를 입력 할 경우)
            raise

        gNumList = gNumList + myList

        if getMax() == CONS_LIMIT_NUM : print("컴퓨터 승리!!")
    except :
        print("값을 잘못 입력하였습니다. 다시 입력해주세요.")
        return 0

    return 1

commands = [computerTurn,myTrun]

print("베스킨라빈스써리원 게임",end="\n--------------------------------\n")
while(getMax() < CONS_LIMIT_NUM and gFirstGame < CONS_LIMIT_NUM) :
    # 게임을 컴퓨터가 먼저 시작할지, 내가 먼저시작할지에 대한 처리
    action = commands[gFirstGame%2]
    gFirstGame+=action()
"""

# Q2

# 학생 답
"""
s = ["김갑,3242524215",
"이을,3242524223",
"박병,2242554131",
"최정,4245242315",
"정무,3242524315",
"석호1,123456789",
"석호2,!234567891",
"정무2,3242524315",
"박병2,2242554131"]

# 정답지
a = [3,2,4,2,5,2,4,3,1,2]

def grader(s, a) :

    # 이름과 답을 분리하기
    name = ""
    answer = ""
    nameList = ""
    scoreList = ""
    point = 100 / len(a)

    for i in range(0, len(s)) :
        
        comma = s[i].index(",")
        name  = s[i][0:comma]
        answer = s[i][comma+1:len(s[i])]

        # 학생의 제출한 답이 이상한 경우 다시 재출하여 채점하기 위해 Error 처리
        # 마지막 등수에는 포함 안시킴
        # 학생이 제출한 정답의 개수와 정답지의 개수가 같은지 확인하기
        if len(a) != len(answer) :
            print(name, "학생 정답 수와 정답의 개수가 다릅니다!")
            continue

        # 학생이 제출한 정답이 숫자인지 확인하기
        try :
            answer = int(answer)
        except :
            print(name, "학생의 정답이 숫자가 아닙니다!")
            continue

        nameList = nameList + name + " "

        answer = str(answer)
        
        # 학생의 정답과 정답지를 비교하기

        score = 0

        for i in range(0,len(a)) :
            if answer[i] == str(a[i]) :
                score = score + point

        scoreList = scoreList + str(score) + " "

    nameList = nameList.split()
    scoreList = scoreList.split()

    pointCheck = 100
    place = 0

    while pointCheck > -1 :

        # 동점자 처리 위한 변수
        sameCheck = 0

        for i in range(0, len(scoreList)) :

            if str(pointCheck) == str(scoreList[i]) :

                print("학생 :", nameList[i], "점수 :", scoreList[i], "등수 :", place+1, "등")
                sameCheck = sameCheck + 1
        
        pointCheck = pointCheck - point
        place = place + sameCheck

grader(s, a)
"""

# Q3
"""
import random

gNumbers = None
def makeNumbers() :
    numbers = list()
    while(len(numbers) < 3) :
        number = random.randint(0, 100)
        if number in numbers : continue
        numbers.append(number)

    numbers.sort()
    return numbers

def guessCheck(number,guessCount) :
        min = gNumbers[0] - number
        mid = gNumbers[1] - number
        max = gNumbers[2] - number

        rangeComment = ["최솟값","중간값","최댓값"]
        if abs(mid) > abs(min) < abs(max)  : valueList = [0,min]
        elif abs(min) > abs(mid) < abs(max)  : valueList = [1,mid]
        else : valueList = [2,max]

        if valueList[1] == 0 : 
            print("숫자를 맞추셨습니다.!",str(number)+"는",rangeComment[valueList[0]] + "입니다")
            return 1
        elif valueList[1] != 0 and guessCount in (5,10) :
            print(rangeComment[valueList[0]]+"은",str(number),"작습니다" if valueList[1] < 0 else "큽니다.")       
            return 0     
        else :
            print(str(number)+"는 없습니다.")            
            return 0

def guessNumbers() :
    okCount = 0
    guessCount = 1
    guessHistory = list()
    while(True) :
        print(guessCount,"차 시도")

        number = input("숫자를 예측해보세요(종료 : quit) :")
        if number == "quit" : break

        try :
            number = int(number)
            if number in guessHistory : 
                print("이미 예측에 사용한 숫자입니다")
                continue

            okCount += guessCheck(number,guessCount)
            if okCount == 3 :
                print("게임종료")
                print(guessCount,"번 시도만에 예측 성공")
                return

            guessHistory.append(number)
            guessCount+=1
        except :
            print("입력값이 잘못 되었습니다.")
            continue

    print("게임종료")

gNumbers = makeNumbers()
print("3개의 랜덤값:",gNumbers)
guessNumbers()
"""

# Q4
### 새로운 달의 마지막 날이 100일 기념일을 지나치는지 확인하여 계산합니다.
"""
def after_100(mm,dd,day):
    d = [31,28,31,30,31,30,31,31,30,31,30,31]
    week =["월","화","수","목","금","토","일"]
    
    if day == "일": the_day = "월"
    else : the_day = week[week.index(day)+1]
    

    month_index = mm-1
    count = d[month_index] - dd + 1
    
    try:
        if type(mm) == int and  0 < mm < 13 and type(dd) ==int and 0 < dd <= d[month_index] and day in week:
            for i in range(4):
                month_index += 1
                if month_index > 11:
                    month_index -= 12
                count = count + d[month_index]
                if count < 100:
                    continue
                elif count == 100:
                    d_month = month_index + 1
                    d_day = d[month_index] 
                    break
                elif count > 100:
                    d_month = month_index + 1
                    d_day = d[month_index] - (count-100)
                    break
            
            print(str(mm)+"월 "+str(dd)+"일 "+day+"요일부터 100일 뒤는 "+str(d_month)+"월 "+str(d_day)+"일 "+the_day+"요일")
        else: raise
    except:
        print("인수 오류")
        
after_100(6,21,"화")
"""