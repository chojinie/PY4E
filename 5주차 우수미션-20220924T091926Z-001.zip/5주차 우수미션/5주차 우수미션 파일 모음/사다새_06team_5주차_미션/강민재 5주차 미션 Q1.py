import random

num = 0

#31 외치기 전까지 반복
#입력이 잘못 되었을 때 num이 올라가지 않도록 하기 위해 for가 아닌 while을 사용
while num < 31:
    my = input("My turn - 숫자를 입력하세요: ")
    myList = my.split()

    # 숫자인지 아닌지 검사
    try:
        for i in myList:
            int(i)
    except:
        print("\n숫자가 아닌 값이 입력되었습니다.")
        continue

    # 1~3회 외치기 검사
    if (len(myList) == 0):
        print("\n입력되지 않았습니다.")
        continue
    elif (len(myList) > 3):
        print("\n3회 까지만 숫자를 입력할 수 있습니다.")
        continue
    elif int(myList[0]) - num != 1:
        print("\n현재숫자보다 1 높은 수를 입력해야합니다.")
        continue
    
    #31 외치면 패배
    elif "31" in myList:
        print("사람 패배!\n컴퓨터 승리!")
        break
    elif (len(myList) == 1):
        num += 1

    # 1씩 증가하지 않게 외치면 다시 입력
    elif (len(myList) > 1):
        determinant = True
        for i in range(1,len(myList)):
            if int(myList[i]) - int(myList[i-1]) != 1:
                print("\n숫자를 1의 간격만큼 입력하지 않았습니다.")
                determinant = False
                break
        if (determinant == True):
            num += len(myList)
        else:
            continue

    #컴퓨터 랜덤 베스킨라빈스 입력
    for _ in range(0,random.randint(1,3)):
        num += 1
        print("컴퓨터 :",num)
        if (num == 31):
            print("컴퓨터 패배!\n사람 승리!")
            break

    print("현재숫자 :", num)
print("게임 종료")