# 학생 답
s = ["김갑,3242524215","이을,3242524223","박병,2242554131","최정,4245242315","정무,3242524315"]

# 정답지
a = [3,2,4,2,5,2,4,3,1,2]

# 점수표
resultScore = []

#채점 / 답안지 : 문자열
def 채점(답안지):
    score = 0
    n = 0
    for i in 답안지:
        if int(i) == a[n]:
            score += 10
        n += 1
    return score

#채점
for i in s:
    답안지 = i.split(",")[1]
    score = 채점(답안지)
    resultScore.append(str(score) + "," + i.split(",")[0])
resultScore.sort(reverse=True)
print(resultScore)

#출력
n = 0
for i in resultScore:
    n += 1
    print("학생:", i.split(",")[1], "점수:", i.split(",")[0], str(n) + "등")