import random

# 컴퓨터 랜덤 숫자 3개 담을 리스트
randomList = []
for _ in range(0,3):
    randomList.append(random.randint(0,100))
randomList.sort()

print(randomList)

#몇 차 시도인지 확인하는 변수
tryInput = 1

#숫자를 맞출 때마다 score +1, score == 3이 되면 while 구문 중단
score = 0

#이미 예측한 숫자 중복 방지 검사용 리스트
guessList = []

#이미 예측한 숫자를 입력했을 때 tryInput 값이 올라가지 않도록 하기 위해 for가 아닌 while 구문 사용
while (tryInput <= 10) & (score < 3):
    print(str(tryInput) + "차 시도")
    입력 = input("숫자를 예측해보세요 : ")

    #숫자인지 아닌지 검사
    try:
        입력 = int(입력)
    except:
        print("\n숫자가 아닌 값이 입력되었습니다.")
        continue

    #이미 예측했다면 다시입력
    if 입력 in guessList:
        print("\n이미 예측에 사용한 숫자입니다")
        continue
    
    #예측한 적이 없는 숫자라면 아래코드 실행 & 추후 중복 예측 방지를 위한 메서드
    guessList.append(입력)

    #숫자 정답유무 확인
    if 입력 in randomList:
        print("\n숫자를 맞추셨습니다!" , end = " ")
        #정답을 맞췄으므로 score +1, 14번째 줄 참고
        score += 1
        if (입력 == randomList[0]):
            print(str(입력) + "은(는) 최솟값입니다.")
        elif (입력 == randomList[1]):
            print(str(입력) + "은(는) 중간값입니다.")
        else:
            print(str(입력) + "은(는) 최댓값입니다.")
    else:
        print("\n" + str(입력) + "은(는) 없습니다", end = " ")
        #5회차 이후부터는 힌트 제공
        if (tryInput >= 5):
            if 입력 < randomList[0]:
                print("최솟값은 " + str(입력) + "보다 큽니다.")
            elif 입력 > randomList[2]:
                print("최댓값은 " + str(입력) + "보다 작습니다.")
            elif 입력 > randomList[1]:
                print(str(입력) + "은(는) 중간값보다 크고 최댓값보다 작습니다.")
            else:
                print(str(입력) + "은(는) 최솟값보다 크고 중간값 보다 작습니다.")

    #차수 증가
    tryInput += 1

print("\n게임종료")
if (score >= 3):
    print(str(tryInput) + "번 시도만에 예측 성공")